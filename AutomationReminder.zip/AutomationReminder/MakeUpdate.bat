@echo off
REM Double-click: packs this AutomationReminder folder into ONE update .cmd in
REM your Downloads folder. Copy that file to another PC and double-click it there.
title AutomationReminder - make update file
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0MakeUpdate.ps1"
echo.
pause
