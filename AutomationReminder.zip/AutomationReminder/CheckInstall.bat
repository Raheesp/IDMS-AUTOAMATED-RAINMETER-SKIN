@echo off
REM Double-click: checks this PC is really running the current AutomationReminder
REM (right folder, every file current, Python, tasks) and refreshes Rainmeter.
title AutomationReminder - install check
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0CheckInstall.ps1"
