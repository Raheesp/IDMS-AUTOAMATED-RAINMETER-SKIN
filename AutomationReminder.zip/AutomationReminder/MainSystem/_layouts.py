"""Generates every MAIN AUTOMATION SYSTEM layout (.ini) plus Picker.inc.

    python _layouts.py

One .ini per design in @Resources\\Designs (CompactIni= there names the file).
All layouts run MainSystem.lua; each is just a choice of which optional meters
to show and where (see the meter list at the top of MainSystem.lua). Don't
hand-edit the .ini files - change the LAYOUTS below and re-run this.
"""
import os

HERE = os.path.dirname(os.path.abspath(__file__))
F = "Segoe UI"
THEMES = [
    ("Sunset", "255,150,90,255", "255,255,255,70"), ("Midnight", "80,140,245,255", "255,255,255,70"),
    ("Glass", "215,222,235,255", "255,255,255,70"), ("Aurora", "168,130,255,255", "255,255,255,70"),
    ("Mono", "152,157,164,255", "255,255,255,70"), ("Ivory", "245,242,235,255", "30,32,38,90"),
    ("Ember", "235,64,52,255", "255,255,255,70"), ("Emerald", "70,200,150,255", "255,255,255,70"),
]
TOGGLE = "[!ToggleMeterGroup Themes][!Redraw]"


# ---------------------------------------------------------------- builders ---
def S(name, text="", x=0, y=0, size=9, weight=400, color="#Text#,255", align="LeftCenter", font=F, **kw):
    """String meter."""
    d = dict(Meter="String", Text=text, X=x, Y=y, StringAlign=align, FontFace=font,
             FontSize=size, FontWeight=weight, FontColor=color, AntiAlias=1)
    d.update(kw)
    return name, d


def SH(name, shape, x=0, y=0, **kw):
    """Shape meter."""
    d = dict(Meter="Shape", X=x, Y=y, Shape=shape)
    d.update(kw)
    return name, d


def card(w, h, r, fill="LinearGradient CardGrad", stroke="StrokeWidth 1 | Stroke Color #Stroke#", extra=None):
    d = dict(Meter="Shape", Shape=f"Rectangle 0.5,0.5,{w - 1},{h - 1},{r} | Fill {fill} | {stroke}",
             CardGrad="90 | #CardTop# ; 0.0 | #CardBot# ; 1.0", LeftMouseUpAction=TOGGLE,
             ToolTipText="MAIN AUTOMATION SYSTEM")
    if extra:
        d.update(extra)
    return "MeterCard", d


def bar(x, y, w, h=2, r=1, track="#Faint#", grad="0 | #Accent#,255 ; 0.0 | #AccentB#,255 ; 1.0"):
    return [SH("MeterBarTrack", f"Rectangle 0,0,{w},{h},{r} | Fill Color {track} | StrokeWidth 0", x, y),
            ("MeterBar", dict(Meter="Shape", X=x, Y=y, Shape="Rectangle 0,0,0,0 | StrokeWidth 0", BarGrad=grad))]


def brand(x, y, text="MAIN AUTOMATION SYSTEM", size=6.5, color="#Dim#,230", align="LeftCenter", font=F):
    return S("MeterBrand", text, x, y, size, 700, color, align, font, InlineSetting="CharacterSpacing | 0.6 | 0.6")


# ----------------------------------------------------------------- layouts ---
# name: (file, W, H, extra variables, meters)
LAYOUTS = {}

# 01 Hairline (also Classic) - MainSystem.ini
LAYOUTS["Hairline"] = ("MainSystem.ini", 500, 34, dict(MidY=17, BarW=480, BarH=2, BarR=1, LabelNext="NEXT"), [
    card(500, 34, 10),
    SH("MeterGloss", "Rectangle 1,1,498,14,9 | Fill LinearGradient GlossGrad | StrokeWidth 0", GlossGrad="90 | #GlossA# ; 0.0 | #GlossB# ; 1.0"),
    S("MeterBrandMain", "MAIN AUTOMATION SYSTEM", 14, 17, 7, 700, "#Text#,215", InlineSetting="CharacterSpacing | 0.6 | 0.6"),
    SH("MeterDivider", "Rectangle 0,0,1,16 | Fill Color #Faint# | StrokeWidth 0", "11R", 9),
    SH("MeterDot", "Ellipse 4,4,3.5 | Fill Color #Accent#,255 | StrokeWidth 0", "11R", 13),
    S("MeterLabel", "NEXT", "7R", 17, 7, 700, "#Accent#,255", InlineSetting="CharacterSpacing | 0.5 | 0.5"),
    S("MeterName", "Loading schedule...", "6R", 17, 10, 600, W=180, H=18, ClipString=1),
    S("MeterNameProbe", "", 0, 0, 10, 600, "0,0,0,0", "Left", ClipString=2, ClipStringW=480, ClipStringH=18),
    SH("MeterFailBg", "Rectangle 0,0,0,0 | StrokeWidth 0", 0, 0, Hidden=1),
    S("MeterFail", "", 0, 17, 6.5, 700, "255,148,134,255", Hidden=1, Padding="6,2,6,2"),
    S("MeterCountdown", "", 486, 17, 12, 300, "#Accent#,255", "RightCenter"),
] + bar(10, 31, 480))

# 02 Capsule
LAYOUTS["Capsule"] = ("Capsule.ini", 300, 42, dict(RingC=13, RingR=10, RingSW=3, LabelNext="next up", LabelRun="running now", LabelSync="waiting for sync", FailFmt="%d failed"), [
    card(300, 42, 20.5, stroke="StrokeWidth 1 | Stroke Color 255,255,255,70"),
    SH("MeterRingTrack", "Ellipse 13,13,10 | Fill Color 0,0,0,0 | StrokeWidth 3 | Stroke Color 255,255,255,40", 8, 8),
    SH("MeterArc", "Rectangle 0,0,0,0 | StrokeWidth 0", 8, 8),
    S("MeterName", "Loading...", 44, 14, 9.5, 600, W=150, H=16, ClipString=1),
    S("MeterLabel", "next up", 44, 29, 7, 400, "#Dim#,255"),
    S("MeterFail", "", "6R", 29, 7, 700, "255,160,150,255"),
    S("MeterCountdown", "", 286, 21, 11, 600, "#Accent#,255", "RightCenter"),
])

# 03 Ticker
LAYOUTS["Ticker"] = ("Ticker.ini", 280, 64, dict(BarW=254, BarH=2, BarR=1, LabelRun="LIVE"), [
    card(280, 64, 12),
    S("MeterLabel", "NEXT", 13, 16, 7, 700, "#Accent#,255", InlineSetting="CharacterSpacing | 0.5 | 0.5"),
    S("MeterName", "Loading...", "7R", 16, 10.5, 600, W=130, H=18, ClipString=1),
    S("MeterCountdown", "", 267, 16, 11, 300, "#Accent#,255", "RightCenter"),
] + bar(13, 29, 254) + [
    S("MeterThenLbl", "THEN", 13, 46, 6.5, 700, "#Dim#,230", InlineSetting="CharacterSpacing | 0.5 | 0.5"),
    S("MeterTicker", "", 50, 46, 8.5, 400, "#Text#,210", W=160, H=15, ClipString=1),
    S("MeterFail", "", 267, 46, 6.5, 700, "255,120,110,255", "RightCenter"),
    brand(140, 58, "MAIN AUTOMATION SYSTEM", 5.5, "#Dim#,150", "CenterCenter"),
])

# 04 Ring
LAYOUTS["Ring"] = ("Ring.ini", 150, 150, dict(RingC=75, RingR=67, RingSW=5, LabelNext="NEXT UP"), [
    ("MeterCard", dict(Meter="Shape", Shape="Ellipse 75,75,74.5 | Fill LinearGradient CardGrad | StrokeWidth 1 | Stroke Color #Stroke#",
                       CardGrad="90 | #CardTop# ; 0.0 | #CardBot# ; 1.0", LeftMouseUpAction=TOGGLE)),
    SH("MeterRingTrack", "Ellipse 75,75,67 | Fill Color 0,0,0,0 | StrokeWidth 5 | Stroke Color 255,255,255,22"),
    SH("MeterArc", "Rectangle 0,0,0,0 | StrokeWidth 0"),
    brand(75, 30, "MAIN SYSTEM", 5.5, "#Dim#,200", "CenterCenter"),
    S("MeterLabel", "NEXT UP", 75, 45, 6.5, 700, "#Accent#,255", "CenterCenter"),
    S("MeterClock", "--:--", 75, 70, 23, 300, "#Accent#,255", "CenterCenter"),
    S("MeterName", "Loading...", 75, 97, 8.5, 600, "#Text#,230", "CenterCenter", W=96, H=15, ClipString=1),
    S("MeterFail", "", 75, 116, 6.5, 700, "255,140,130,255", "CenterCenter"),
])

# 05 Queue
up_rows = []
for i in range(1, 4):
    y = 94 + (i - 1) * 22
    up_rows += [SH(f"MeterUpDot{i}", "Ellipse 4,4,3.5 | Fill Color #CardBot# | StrokeWidth 1 | Stroke Color #AccentB#,255", 14, y - 4),
                S(f"MeterUpT{i}", "", 28, y, 7.5, 700, "#AccentB#,255"),
                S(f"MeterUpN{i}", "", 80, y, 7.5, 400, "#Text#,210", W=116, H=14, ClipString=1)]
LAYOUTS["Queue"] = ("Queue.ini", 210, 178, dict(BarW=182, BarH=3, BarR=1.5, LabelNext="NEXT UP", LabelRun="NOW RUNNING"), [
    card(210, 178, 14),
    S("MeterLabel", "NEXT UP", 14, 15, 7, 700, "#Accent#,255", InlineSetting="CharacterSpacing | 0.5 | 0.5"),
    S("MeterFail", "", 196, 15, 6.5, 700, "255,140,130,255", "RightCenter"),
    S("MeterName", "Loading...", 14, 35, 12.5, 600, W=182, H=22, ClipString=1),
    S("MeterCountdown", "", 14, 57, 15, 300, "#AccentB#,255"),
] + bar(14, 72, 182, 3, 1.5) + [
    SH("MeterQueueLine", "Rectangle 0,0,1,48 | Fill Color #AccentB#,70 | StrokeWidth 0", 18, 96),
] + up_rows + [brand(105, 166, "MAIN AUTOMATION SYSTEM", 5.5, "#Dim#,150", "CenterCenter")])

# 06 Console
C = "Consolas"
LAYOUTS["Console"] = ("Console.ini", 330, 76, dict(LabelNext="eta", LabelRun="run", LabelSync="wait"), [
    card(330, 76, 4, fill="Color #CardBot#", stroke="StrokeWidth 1 | Stroke Color #Accent#,80"),
    S("MeterPrompt", "main@automation:~$ next", 12, 14, 8.5, 400, "#Dim#,255", font=C),
    S("MeterName", "loading...", "6R", 14, 8.5, 700, "#Accent#,255", font=C, W=120, H=16, ClipString=1),
    S("MeterLabel", "eta", 24, 34, 8.5, 400, "#Dim#,255", font=C),
    S("MeterHMS", "--:--:--", 62, 34, 8.5, 700, "#Accent#,255", font=C),
    S("MeterAscii", "", 138, 34, 8.5, 400, "#Accent#,200", font=C),
    S("MeterConsole3", "", 12, 54, 8.5, 400, "#Dim#,255", font=C, W=290, H=16, ClipString=1),
    S("MeterCursor", "_", "0R", 54, 8.5, 700, "#Accent#,255", font=C),
])

# 07 Digital
B = "Bahnschrift"
LAYOUTS["Digital"] = ("Digital.ini", 252, 78, dict(BarW=224, BarH=3, BarR=1.5, LabelNext="NEXT UP"), [
    card(252, 78, 12),
    SH("MeterGloss", "Rectangle 1,1,250,24,11 | Fill LinearGradient GlossGrad | StrokeWidth 0", GlossGrad="90 | #GlossA# ; 0.0 | #GlossB# ; 1.0"),
    S("MeterLabel", "NEXT UP", 14, 17, 7, 700, "#Accent#,255", InlineSetting="CharacterSpacing | 0.5 | 0.5"),
    S("MeterName", "Loading...", 14, 35, 11, 600, W=112, H=18, ClipString=1),
    S("MeterFail", "", 14, 53, 6.5, 700, "255,140,130,255"),
    S("MeterMM", "--", 186, 36, 29, 300, "#Accent#,255", "RightCenter", font=B),
    S("MeterColon", ":", 187, 34, 22, 300, "#Accent#,255", "LeftCenter", font=B),
    S("MeterSS", "--", 199, 40, 17, 300, "#Accent#,200", "LeftCenter", font=B),
] + bar(14, 66, 224, 3, 1.5, grad="0 | #AccentB#,255 ; 0.0 | #Accent#,255 ; 1.0"))

# 08 Floating (no card - shadowed text)
SHD = "Shadow | 0 | 1 | 3 | 0,0,0,170"
LAYOUTS["Floating"] = ("Floating.ini", 300, 58, dict(BarW=300, BarH=1, BarR=0, LabelNext="next up - main automation system",
                                                     LabelRun="running now - main automation system", LabelSync="waiting for the main pc",
                                                     FailFmt="%d failed"), [
    ("MeterCard", dict(Meter="Shape", Shape="Rectangle 0,0,300,58 | Fill Color 0,0,0,1 | StrokeWidth 0", LeftMouseUpAction=TOGGLE)),
    S("MeterLabel", "next up", 0, 8, 7.5, 400, "255,255,255,220", InlineSetting=SHD),
    S("MeterFail", "", "6R", 8, 7.5, 700, "255,180,170,255", InlineSetting=SHD),
    S("MeterName", "Loading...", 0, 30, 16, 300, "255,255,255,255", W=190, H=26, ClipString=1, InlineSetting=SHD),
    S("MeterCountdown", "", 300, 30, 16, 600, "#Accent#,255", "RightCenter", InlineSetting=SHD),
] + bar(0, 52, 300, 1, 0, track="255,255,255,90", grad="0 | 255,255,255,255 ; 0.0 | 255,255,255,255 ; 1.0"))

# 09 Ivory (paper card - fixed light colours, theme accent)
INK = "42,35,32,255"
LAYOUTS["Ivory"] = ("Ivory.ini", 252, 94, dict(BarW=224, BarH=3, BarR=1.5, LabelNext="NEXT UP", LabelRun="NOW RUNNING"), [
    SH("MeterShadow", "Rectangle 2,4,250,90,13 | Fill Color 40,25,10,40 | StrokeWidth 0"),
    card(252, 94, 12, fill="Color 252,249,243,247", stroke="StrokeWidth 1 | Stroke Color 60,40,20,40"),
    S("MeterLabel", "NEXT UP", 14, 16, 7, 700, "#Accent#,255", InlineSetting="CharacterSpacing | 0.5 | 0.5"),
    S("MeterFail", "", 238, 16, 6.5, 700, "179,38,30,255", "RightCenter"),
    S("MeterName", "Loading...", 14, 36, 12, 600, INK, W=140, H=20, ClipString=1),
    S("MeterCountdown", "", 238, 36, 12, 400, "#Accent#,255", "RightCenter"),
] + bar(14, 51, 224, 3, 1.5, track="60,40,20,26", grad="0 | #Accent#,255 ; 0.0 | #Accent#,255 ; 1.0") + [
    S("MeterThen", "", 14, 68, 7.5, 400, "110,98,90,255", W=224, H=14, ClipString=1),
    brand(14, 83, "MAIN AUTOMATION SYSTEM", 5.5, "150,138,128,255"),
])

# 10 Timeline
tl = []
for i in range(1, 5):
    if i == 1:
        tl.append(SH("MeterTk1", "Ellipse 4,4,3.5 | Fill Color #Accent#,255 | StrokeWidth 0", 16, 37))
        tl.append(S("MeterTkL1", "", 16, 50, 6.5, 700, "#Accent#,255", "CenterCenter"))
    else:
        tl.append(SH(f"MeterTk{i}", "Rectangle 0,0,1,9 | Fill Color 255,255,255,110 | StrokeWidth 0", 16, 36))
        tl.append(S(f"MeterTkL{i}", "", 16, 50, 6.5, 400, "#Dim#,255", "CenterCenter"))
LAYOUTS["Timeline"] = ("Timeline.ini", 400, 60, dict(AxisX=16, AxisW=368, LabelNext="in", LabelRun="running", LabelSync="waiting"), [
    card(400, 60, 12),
    SH("MeterDot", "Ellipse 3.5,3.5,3 | Fill Color #Accent#,255 | StrokeWidth 0", 14, 13),
    S("MeterName", "Loading...", 26, 17, 9.5, 600, W=170, H=16, ClipString=1),
    S("MeterLabel", "in", "6R", 17, 8, 400, "#Dim#,255"),
    S("MeterCountdown", "", "4R", 17, 9.5, 700, "#Accent#,255"),
    S("MeterFail", "", 386, 17, 6.5, 700, "255,140,130,255", "RightCenter"),
    SH("MeterAxis", "Rectangle 0,0,368,1 | Fill Color 255,255,255,40 | StrokeWidth 0", 16, 41),
    SH("MeterTkFill", "Rectangle 0,0,0,0 | StrokeWidth 0", 16, 40),
    SH("MeterNow", "Rectangle 0,0,2,11,1 | Fill Color #Text#,255 | StrokeWidth 0", 15, 36),
] + tl)

# 11 Status Block
LAYOUTS["StatusBlock"] = ("StatusBlock.ini", 236, 56, dict(BlkW=56, BlkR=12, LabelNext="NEXT UP"), [
    card(236, 56, 12),
    SH("MeterBlk", "Rectangle 0,0,0,0 | StrokeWidth 0"),
    S("MeterBig", "OK", 28, 24, 15, 700, "#RunColor#,255", "CenterCenter"),
    S("MeterSm", "ALL OK", 28, 42, 5.5, 700, "#RunColor#,230", "CenterCenter", InlineSetting="CharacterSpacing | 0.5 | 0.5"),
    S("MeterLabel", "NEXT UP", 68, 18, 6.5, 700, "#Accent#,255", InlineSetting="CharacterSpacing | 0.5 | 0.5"),
    S("MeterName", "Loading...", 68, 36, 10.5, 600, W=100, H=18, ClipString=1),
    S("MeterCountdown", "", 224, 28, 10, 600, "#Accent#,255", "RightCenter"),
    brand(68, 50, "MAIN SYSTEM", 5, "#Dim#,160"),
])

# 12 Neon
LAYOUTS["Neon"] = ("Neon.ini", 300, 54, dict(LabelNext="NEXT UP"), [
    SH("MeterGlow", "Rectangle 0.5,0.5,299,53,14 | Fill Color 0,0,0,0 | StrokeWidth 6 | Stroke Color #Accent#,35"),
    card(300, 54, 14, fill="Color 12,10,26,170",
         stroke="StrokeWidth 1.5 | Stroke LinearGradient StrokeGrad", extra=dict(StrokeGrad="0 | #Accent#,255 ; 0.0 | #AccentB#,255 ; 1.0")),
    S("MeterLabel", "NEXT UP", 16, 17, 6.5, 700, "#AccentB#,255", InlineSetting="CharacterSpacing | 1 | 1"),
    S("MeterName", "Loading...", 16, 34, 11, 600, "240,238,252,255", W=160, H=18, ClipString=1),
    S("MeterCountdown", "", 284, 24, 15, 300, "#Accent#,255", "RightCenter"),
    S("MeterFail", "", 284, 43, 6.5, 700, "255,160,180,255", "RightCenter"),
])

# 13 Live Tile
LAYOUTS["LiveTile"] = ("LiveTile.ini", 150, 150, dict(TileMode=1, FixedTextColor=1, BarW=150, BarH=4, BarR=0, LabelNext="NEXT UP"), [
    ("MeterCard", dict(Meter="Shape", Shape="Rectangle 0,0,150,150,3 | Fill Color #Accent#,240 | StrokeWidth 0", LeftMouseUpAction=TOGGLE)),
    brand(12, 14, "MAIN SYSTEM", 6, "255,255,255,170"),
    S("MeterLabel", "NEXT UP", 12, 30, 7, 700, "255,255,255,220", InlineSetting="CharacterSpacing | 0.5 | 0.5"),
    S("MeterName", "Loading...", 12, 40, 14, 600, "255,255,255,255", "LeftTop", W=128, H=46, ClipString=1),
    S("MeterFail", "", 12, 98, 7, 700, "255,255,255,255", Padding="5,2,5,2", SolidColor="0,0,0,60"),
    S("MeterCountdown", "", 12, 124, 18, 300, "255,255,255,255"),
] + bar(0, 146, 150, 4, 0, track="0,0,0,55", grad="0 | 255,255,255,220 ; 0.0 | 255,255,255,220 ; 1.0"))

# 14 Taskbar Chip
LAYOUTS["TaskbarChip"] = ("TaskbarChip.ini", 196, 28, dict(DotR=3, CdStyle="short"), [
    card(196, 28, 8, stroke="StrokeWidth 1 | Stroke Color 255,255,255,26"),
    SH("MeterDot", "Ellipse 3.5,3.5,3 | Fill Color #Accent#,255 | StrokeWidth 0", 10, 10),
    S("MeterName", "Loading...", 22, 14, 8.5, 600, W=96, H=16, ClipString=1),
    SH("MeterFailBg", "Ellipse 8,8,8 | Fill Color 229,72,59,255 | StrokeWidth 0", 124, 6),
    S("MeterFailN", "", 132, 14, 7, 700, "255,255,255,255", "CenterCenter"),
    S("MeterCountdown", "", 186, 14, 8.5, 600, "#Accent#,255", "RightCenter"),
])

# 15 Mini Dash
segs = [SH(f"MeterSeg{i}", "Rectangle 0,0,20,4,1 | Fill Color 255,255,255,22 | StrokeWidth 0", 14 + (i - 1) * 23, 56) for i in range(1, 13)]
cols = []
for i, x in enumerate((14, 106, 198), 1):
    cols += [S(f"MeterUpT{i}", "", x, 84, 7, 700, "#Accent#,255"), S(f"MeterUpN{i}", "", x, 100, 7.5, 400, "#Text#,200", W=86, H=14, ClipString=1)]
LAYOUTS["MiniDash"] = ("MiniDash.ini", 300, 126, dict(SegN=12, SegW=20, SegH=4, LabelNext="NEXT UP", FailFmt="%d FAILED"), [
    card(300, 126, 14, stroke="StrokeWidth 1 | Stroke Color 255,255,255,22"),
    brand(14, 17, "MAIN AUTOMATION SYSTEM", 6.5, "#Dim#,230"),
    S("MeterFail", "", 214, 17, 6.5, 700, "255,140,130,255", "RightCenter"),
    S("MeterLabel", "NEXT UP", 286, 17, 7, 700, "#Accent#,255", "RightCenter"),
    S("MeterName", "Loading...", 14, 38, 12, 600, W=180, H=20, ClipString=1),
    S("MeterCountdown", "", 286, 38, 13, 300, "#Accent#,255", "RightCenter"),
] + segs + [SH("MeterUpLine", "Rectangle 0,0,272,1 | Fill Color 255,255,255,18 | StrokeWidth 0", 14, 70)] + cols)


# ------------------------------------------------------------------ writer ---
def header(key, fname, w, h, extra):
    ctx = ["[Rainmeter]", "Update=1000", "Group=AutomationReminder", "AccurateText=1", "DynamicWindowSize=1",
           "MiddleMouseUpAction=[!Refresh]", "OnRefreshAction=[!HideMeterGroup Themes]",
           "ContextTitle=Next design (#DesignNext#)",
           'ContextAction=[!WriteKeyValue Variables Design "#DesignNext#" "#@#Settings.inc"][!WriteKeyValue Variables Theme "#DesignNextTheme#" "#@#Settings.inc"]#RefreshAll#',
           "ContextTitle2=Previous design (#DesignPrev#)",
           'ContextAction2=[!WriteKeyValue Variables Design "#DesignPrev#" "#@#Settings.inc"][!WriteKeyValue Variables Theme "#DesignPrevTheme#" "#@#Settings.inc"]#RefreshAll#',
           "ContextTitle3=Preview all designs...", 'ContextAction3=["#DesignGallery#"]']
    for i, (t, _, _) in enumerate(THEMES, 4):
        ctx += [f"ContextTitle{i}=Theme: {t}", f'ContextAction{i}=[!WriteKeyValue Variables Theme "{t}" "#@#Settings.inc"]#RefreshAll#']
    ctx += ["ContextTitle13=Use this design's colours (#DesignTheme#)",
            'ContextAction13=[!WriteKeyValue Variables Theme "#DesignTheme#" "#@#Settings.inc"]#RefreshAll#',
            "ContextTitle12=Theme: Custom (edit in Notepad)",
            'ContextAction12=["notepad.exe" "#@#Themes\\Custom.inc"][!WriteKeyValue Variables Theme "Custom" "#@#Settings.inc"]#RefreshAll#']
    v = ["[Variables]", "; defaults - Settings.inc (per PC) overrides both",
         "Theme=Sunset", "Design=Classic",
         "@IncludeSettings=#@#Settings.inc", "@IncludeTheme=#@#Themes\\#Theme#.inc",
         "Font=Segoe UI", "@IncludeDesign=#@#Designs\\#Design#.inc", "@IncludeCommon=#@#Common.inc",
         f"W={w}", f"H={h}", f"PickY={h + 6}"] + [f"{k}={val}" for k, val in extra.items()] + \
        ["; THEME + DESIGN picker (hidden until the widget is clicked)", "@IncludePicker=#CURRENTPATH#Picker.inc"]
    return ([f"; =============================================================================",
             f";  MAIN AUTOMATION SYSTEM - {key} layout ({w}x{h})",
             ";  GENERATED by _layouts.py - edit that and re-run, don't hand-edit this file.",
             ";  View-only: shows the MAIN automation PC's schedule (synced _taskdata.txt).",
             ";  Click the widget for THEME + DESIGN; right-click for the same options.",
             ";  Engine: MainSystem.lua (switches to the active design's layout on load).",
             "; ============================================================================="]
            + ctx + ["", "[Metadata]", "Name=Main Automation System", "Author=Rahees",
                     f"Information=View-only {key} layout of the main automation PC's live schedule.",
                     "Version=2.0", "License=Personal use", ""] + v +
            ["", "[MScript]", "Measure=Script", "ScriptFile=#CURRENTPATH#MainSystem.lua", ""])


def meter_lines(name, d):
    out = [f"[{name}]"]
    for k, val in d.items():
        out.append(f"{k}={val}")
    return out + [""]


def picker():
    L = ["; THEME + DESIGN picker shared by every layout (GENERATED by _layouts.py).",
         "; Sits at Y=#PickY# (just under the widget); hidden until the widget is clicked.",
         "; Dot X values must match THEME_X in MainSystem.lua.", ""]
    L += meter_lines("MeterPickBG", dict(Meter="Shape", Group="Themes",
                     Shape="Rectangle 0.5,(#PickY#+0.5),352,52,9 | Fill LinearGradient PickGrad | StrokeWidth 1 | Stroke Color #Stroke#",
                     PickGrad="90 | #CardTop# ; 0.0 | #CardBot# ; 1.0"))
    lab = dict(Meter="String", Group="Themes", StringAlign="LeftCenter", FontFace=F, FontSize=7, FontWeight=700,
               FontColor="#Dim#,230", AntiAlias=1, InlineSetting="CharacterSpacing | 0.6 | 0.6")
    L += meter_lines("MeterPickThemeLbl", dict(lab, Text="THEME", X=13, Y="(#PickY#+13)"))
    for i, (t, fill, stroke) in enumerate(THEMES):
        L += meter_lines(f"MeterTheme{t}", dict(Meter="Shape", Group="Themes", X=72 + i * 18, Y="(#PickY#+8)",
                         Shape=f"Ellipse 5,5,5 | Fill Color {fill} | StrokeWidth 1 | Stroke Color {stroke}",
                         LeftMouseUpAction=f'[!WriteKeyValue Variables Theme "{t}" "#@#Settings.inc"]#RefreshAll#',
                         ToolTipText=f"Theme: {t} (changes every skin)"))
    L += meter_lines("MeterThemeCustom", dict(Meter="Shape", Group="Themes", X=216, Y="(#PickY#+8)",
                     Shape="Ellipse 5,5,5 | Fill Color 255,255,255,30 | StrokeWidth 1.5 | Stroke Color 255,255,255,150 | StrokeDashes 2,1.5",
                     LeftMouseUpAction='["notepad.exe" "#@#Themes\\Custom.inc"][!WriteKeyValue Variables Theme "Custom" "#@#Settings.inc"]#RefreshAll#',
                     ToolTipText="Theme: Custom - your own colours (opens Custom.inc in Notepad)"))
    L += meter_lines("MeterThemeRing", dict(Meter="Shape", Group="Themes", X=-100, Y="(#PickY#+8)",
                     Shape="Ellipse 5,5,7 | Fill Color 0,0,0,0 | StrokeWidth 2 | Stroke Color #Accent#,235"))
    L += meter_lines("MeterThemeName", dict(lab, Text="#Theme#", X=240, Y="(#PickY#+13)", StringCase="Upper", FontColor="#Text#,210"))
    L += meter_lines("MeterPickDesignLbl", dict(lab, Text="DESIGN", X=13, Y="(#PickY#+38)"))
    arrow = dict(Meter="String", Group="Themes", StringAlign="LeftCenter", FontFace=F, FontSize=10, FontWeight=700,
                 FontColor="#Accent#,235", AntiAlias=1)
    L += meter_lines("MeterDesignPrev", dict(arrow, Text="<", X=70, Y="(#PickY#+37)",
                     LeftMouseUpAction='[!WriteKeyValue Variables Design "#DesignPrev#" "#@#Settings.inc"][!WriteKeyValue Variables Theme "#DesignPrevTheme#" "#@#Settings.inc"]#RefreshAll#',
                     ToolTipText="Previous design (#DesignPrev#)"))
    L += meter_lines("MeterDesignName", dict(lab, Text="#DesignNum#  #DesignLabel#", X="7R", Y="(#PickY#+38)", FontColor="#Accent#,255",
                     LeftMouseUpAction='[!WriteKeyValue Variables Design "#DesignNext#" "#@#Settings.inc"][!WriteKeyValue Variables Theme "#DesignNextTheme#" "#@#Settings.inc"]#RefreshAll#',
                     ToolTipText="#DesignLabel# - #DesignInfo##CRLF#Click for the next design. Changes every AutomationReminder skin."))
    L += meter_lines("MeterDesignNext", dict(arrow, Text=">", X="7R", Y="(#PickY#+37)",
                     LeftMouseUpAction='[!WriteKeyValue Variables Design "#DesignNext#" "#@#Settings.inc"][!WriteKeyValue Variables Theme "#DesignNextTheme#" "#@#Settings.inc"]#RefreshAll#',
                     ToolTipText="Next design (#DesignNext#)"))
    L += meter_lines("MeterThemeMatch", dict(lab, Text="MATCH", X=340, Y="(#PickY#+13)", StringAlign="RightCenter", FontColor="#Accent#,230",
                     LeftMouseUpAction='[!WriteKeyValue Variables Theme "#DesignTheme#" "#@#Settings.inc"]#RefreshAll#',
                     ToolTipText="Put back this design's own colours (#DesignTheme#)"))
    L += meter_lines("MeterDesignAll", dict(lab, Text="ALL", X=340, Y="(#PickY#+38)", StringAlign="RightCenter",
                     LeftMouseUpAction='["#DesignGallery#"]', ToolTipText="Preview every design in your browser"))
    return L


def write(path, lines):
    with open(path, "w", encoding="utf-8", newline="\r\n") as f:
        f.write("\n".join(lines) + "\n")


for key, (fname, w, h, extra, meters) in LAYOUTS.items():
    lines = header(key, fname, w, h, extra)
    for name, d in meters:
        lines += meter_lines(name, d)
    write(os.path.join(HERE, fname), lines)
    print(f"{fname:18} {key:12} {w}x{h}  {len(meters)} meters")
write(os.path.join(HERE, "Picker.inc"), picker())
print("Picker.inc")
