-- ============================================================================
--  AutomationTasks.lua  -  engine for the AutomationReminder skin (v3, live)
-- ----------------------------------------------------------------------------
--  PRIMARY  : reads _taskdata.txt, written every minute by RefreshTasks.ps1,
--             which queries the real Windows Task Scheduler. Fully dynamic -
--             add / edit / disable a task in Task Scheduler and the widget
--             follows automatically, no editing here.
--
--  FALLBACK : if _taskdata.txt is missing or empty (e.g. this skin is running
--             on a machine that does NOT have the \Uipath Automation\ tasks),
--             it falls back to the static schedule in FALLBACK below so the
--             widget still shows something sensible instead of going blank.
-- ============================================================================

local RUN_WINDOW  = 150     -- seconds after a start time a task reads as RUNNING
local IMMINENT    = 300     -- seconds before a run when the countdown turns amber
local BAR_WIDTH   = 150     -- must match the mini progress track width in the .ini
local REFRESH_SEC = 60      -- how often to re-query Task Scheduler
local PANEL_ROWS  = 28      -- schedule row METERS defined in the .ini (the pool)
local VISIBLE_SCHED = 18    -- schedule rows visible at once (the scroll viewport)
local HIST_ROWS   = 14      -- run-history row METERS in the .ini (the pool)
local VISIBLE_HIST = 14     -- history rows visible at once (its scroll viewport)
local SCROLL_STEP = 3       -- rows moved per mouse-wheel notch
local SCROLL_TRACK_Y = 144  -- schedule scrollbar geometry (matches .ini rows)
local SCROLL_TRACK_H = 320
local HIST_TRACK_Y  = 144   -- history scrollbar geometry
local HIST_TRACK_H  = 252

-- Theme colours - filled from the ACTIVE theme's variables in Initialize().
-- The literals here are only a fallback if a variable is ever missing.
local ACCENT  = "255,186,110"     -- idle / next-up
local RUNC    = "122,214,178"     -- running now
local SOONC   = "255,120,80"      -- imminent (< 5 min)
local PSTROKE = "255,224,196,32"  -- dashboard border
local ROWTEXT = "236,228,219,225" -- dashboard row text
local FAINT   = "255,240,225,20"  -- hairline dividers
local FAILC   = "255,95,95"       -- failed task / run (red, same across themes)

-- swatch X positions in the dashboard header (must match the .ini MeterTheme*)
local THEME_X = { Sunset=800, Midnight=815, Glass=830, Aurora=845, Mono=860, Ivory=875, Ember=890, Emerald=905 }

-- Fallback schedule (used only when the live feed is unavailable) ------------
local MONSAT = { [1]=false, [2]=true, [3]=true, [4]=true, [5]=true, [6]=true, [7]=true }
local FALLBACK = {
  { time="01:00", name="DMS Pending Booking Mail" },
  { time="04:00", name="DMS Data Mail" },
  { time="05:45", name="PSF Customer Complaints" },
  { time="05:55", name="IDMS Back Office Data" },
  { time="08:40", name="SOS EBR (Once)" },
  { time="08:55", name="DSE Report + Mail" },
  { time="09:45", name="SOS Follow-Up (Morning)", days=MONSAT },
  { time="09:55", name="DMS Stock Mail" },
  { time="10:03", name="SOS BDE Workflow" },
  { time="10:22", name="SOS EBR Refresh" },
  { time="10:27", name="SOS Commitment" },
  { time="11:27", name="SOS Commitment" },
  { time="11:38", name="Stock IBND Booking", days=MONSAT },
  { time="12:03", name="SOS BDE Workflow" },
  { time="12:22", name="SOS EBR Refresh" },
  { time="12:40", name="ABP Sales" },
  { time="13:30", name="DMS Pending Booking Mail" },
  { time="14:03", name="SOS BDE Workflow" },
  { time="14:22", name="SOS EBR Refresh" },
  { time="15:10", name="MarutiBI Power BI Refresh", domMin=5 },
  { time="15:45", name="Edge Close" },
  { time="16:03", name="SOS BDE Workflow" },
  { time="16:22", name="SOS EBR Refresh" },
  { time="17:45", name="SOS Follow-Up (Evening)", days=MONSAT },
  { time="18:03", name="SOS BDE Workflow" },
  { time="18:22", name="SOS EBR Refresh" },
  { time="23:00", name="Restart" },
  { time="23:30", name="SOS BDE Night Run" },
}

local dataFile, histFile, tick = nil, nil, 0
local scroll  = 0  -- schedule scroll offset (rows), driven by the mouse wheel
local hscroll = 0  -- run-history scroll offset (rows)

-- ---------------------------------------------------------------- helpers ---

-- Domain acronyms that should stay upper-case in labels. Add to this set if
-- you introduce a new automation whose short-form gets title-cased wrongly.
local ACRONYMS = {
  DMS=true, IDMS=true, SOS=true, ABP=true, PSF=true, DSE=true, BDE=true,
  EBR=true, IBND=true, BI=true, RTO=true, DSE=true, SO=true, NEXA=true,
}

-- Auto-name any task, however it is spelled in Task Scheduler:
--   "DMS.DATA.MAIL"      -> "DMS Data Mail"
--   "SOS_EBR-ONCE"       -> "SOS EBR Once"
--   "MarutiBI powerbi"   -> "Maruti BI Powerbi"
--   "sos_ebr-hourly (v2)"-> "SOS EBR Hourly V2"
-- Any special characters are stripped, camelCase is split, then each word is
-- kept upper-case if it's a known acronym or title-cased otherwise.
local function prettify(raw)
  local s = raw:gsub("[^%w]+", " ")            -- special chars / _ -> spaces
  s = s:gsub("(%l)(%u)", "%1 %2")              -- camelCase: MarutiBI -> Maruti BI
  s = s:gsub("%s+", " "):gsub("^%s+", ""):gsub("%s+$", "")
  if s == "" then return raw end               -- name was all symbols - keep raw
  local out = {}
  for word in s:gmatch("%S+") do
    local up = word:upper()
    if ACRONYMS[up] or #word <= 2 then
      out[#out + 1] = up                       -- keep DMS, IDMS, IBND, SOS, BI...
    else
      out[#out + 1] = word:sub(1, 1):upper() .. word:sub(2):lower()
    end
  end
  return table.concat(out, " ")
end

local function fmtCountdown(sec, prefix)
  local h = math.floor(sec / 3600)
  local m = math.floor((sec % 3600) / 60)
  local s = sec % 60
  if h > 0 then return string.format("%s%dh %02dm %02ds", prefix, h, m, s) end
  if m > 0 then return string.format("%s%dm %02ds", prefix, m, s) end
  return string.format("%s%ds", prefix, s)
end

-- compact "time until" for the expanded panel: 2d 3h / 4h 05m / 12m / 30s
local function fmtDiff(sec)
  if sec < 0 then sec = 0 end
  local d = math.floor(sec / 86400)
  local h = math.floor((sec % 86400) / 3600)
  local m = math.floor((sec % 3600) / 60)
  if d > 0 then return string.format("%dd %dh", d, h) end
  if h > 0 then return string.format("%dh %02dm", h, m) end
  if m > 0 then return string.format("%dm", m) end
  return string.format("%ds", sec % 60)
end

-- how long a run took: running / 45s / 2m 05s / 1h 03m
local function fmtDur(sec)
  if sec < 0 then return "running" end
  if sec < 60 then return sec .. "s" end
  local h = math.floor(sec / 3600)
  local m = math.floor((sec % 3600) / 60)
  if h > 0 then return string.format("%dh %02dm", h, m) end
  return string.format("%dm %02ds", m, sec % 60)
end

local function fmtClock(tt)
  return (os.date("%I:%M %p", tt):gsub("^0", ""))
end

local function fmtWhen(tt, now)
  if os.date("%j%Y", tt) == os.date("%j%Y", now) then return fmtClock(tt) end
  return os.date("%a ", tt) .. fmtClock(tt)
end

local function sameDay(a, b)
  return os.date("%j%Y", a) == os.date("%j%Y", b)
end

local function setOpt(meter, opt, val) SKIN:Bang('!SetOption', meter, opt, val) end

-- ---------------------------------------------------- data source: LIVE -----

-- Task Scheduler "last result" codes that are NOT failures (informational).
-- 267009 (running) is handled separately via isRun.
local NEUTRAL_RESULT = {
  [267008] = true,  -- ready, not yet run this cycle
  [267010] = true,  -- disabled
  [267011] = true,  -- has never run
  [267012] = true,  -- no more scheduled runs
  [267014] = true,  -- last run terminated by user
}

local function readLive(now)
  local f = io.open(dataFile, "r")
  if not f then return nil end
  local queue, prev, running, runningNow = {}, nil, {}, {}
  local count, failCount, failNames = 0, 0, {}
  for line in f:lines() do
    local nextE, lastE, result, state, name =
      line:match("^(%-?%d+)|(%-?%d+)|(%-?%d+)|([^|]*)|(.+)$")
    if nextE then
      count = count + 1
      nextE, lastE, result = tonumber(nextE), tonumber(lastE), tonumber(result)
      local label = prettify(name)
      local since  = now - lastE
      local isRun  = (state == "Running") or (lastE > 0 and since >= 0 and since < RUN_WINDOW)
      local failed = (not isRun) and result ~= 0 and not NEUTRAL_RESULT[result]
      if failed then failCount = failCount + 1; failNames[#failNames + 1] = label end
      -- only FUTURE runs belong in the queue; a stale/past NextRunTime (e.g. a
      -- task mid-run) must not sort to the top and hijack the "next" hero.
      if nextE > now then
        table.insert(queue, { t = nextE, name = label, last = lastE, running = isRun, failed = failed })
      end
      if lastE > 0 and (not prev or lastE > prev) then prev = lastE end
      if isRun then
        local found = false
        for _, r in ipairs(running) do if r == label then found = true end end
        if not found then table.insert(running, label) end
        -- Confirmed real bug this fixes: a task whose NextRunTime is stale/
        -- past while it's actively running (Task Scheduler doesn't
        -- recalculate the next occurrence until the current run finishes)
        -- was excluded from `queue` by the check above and so never showed
        -- up anywhere in the dashboard's task list at all - it just
        -- vanished for the whole duration of the run, making it look like
        -- "running" was never displayed until the task was already done
        -- and got a fresh future NextRunTime. Tracked here independently
        -- of `queue` so it can be rendered as its own pinned "RUNNING NOW"
        -- row without touching the hero/next-3-preview logic, which
        -- deliberately never shows a running task (see "hero ALWAYS tracks
        -- the next task" below - that's a different, already-fixed bug and
        -- this must not reopen it).
        table.insert(runningNow, { name = label, since = since })
      end
    end
  end
  f:close()
  if count == 0 then return nil end        -- file present but no tasks -> fall back
  table.sort(queue, function(a, b) return a.t < b.t end)
  table.sort(runningNow, function(a, b) return a.since < b.since end)
  return { queue = queue, prev = prev, running = running, runningNow = runningNow, failCount = failCount, failNames = failNames }
end

-- ------------------------------------------------ data source: FALLBACK -----

local function allowedOn(task, tt)
  local d = os.date("*t", tt)
  if task.days and not task.days[d.wday] then return false end
  if task.domMin and d.day < task.domMin then return false end
  return true
end

local function occ(task, off)
  local d = os.date("*t")
  return os.time{ year=d.year, month=d.month, day=d.day + off, hour=task.h, min=task.m, sec=0 }
end

local function readFallback(now)
  local queue, prev, running = {}, nil, {}
  for _, t in ipairs(FALLBACK) do
    for off = 0, 8 do
      local tt = occ(t, off)
      if tt > now and allowedOn(t, tt) then queue[#queue + 1] = { t = tt, name = t.name, last = 0, running = false, failed = false }; break end
    end
    for off = 0, -8, -1 do
      local tt = occ(t, off)
      if tt <= now and allowedOn(t, tt) then
        if not prev or tt > prev then prev = tt end
        if now - tt < RUN_WINDOW then running[#running + 1] = t.name end
        break
      end
    end
  end
  table.sort(queue, function(a, b) return a.t < b.t end)
  -- No real "Running" state exists in fallback mode (no Task Scheduler data
  -- at all, just a guessed static schedule) - runningNow stays empty here;
  -- `running` above already carries the same "started recently" heuristic
  -- this mode has always used for the pulsing dot.
  return { queue = queue, prev = prev, running = running, runningNow = {}, failCount = 0, failNames = {} }
end

-- ------------------------------------------------ data source: HISTORY ------
-- Reads _taskhist.txt (start|durationSec|result|name, newest first) written by
-- the PowerShell reader from the Task Scheduler operational log. Returns the
-- recent run list (with a failed flag). Empty if task history is off.
local function readHist()
  local list, lastDur = {}, {}
  local f = io.open(histFile, "r")
  if not f then return list, lastDur end
  for line in f:lines() do
    local s, dur, result, name = line:match("^(%-?%d+)|(%-?%d+)|(%-?%d+)|(.+)$")
    if s then
      s, dur, result = tonumber(s), tonumber(dur), tonumber(result)
      local label = prettify(name)
      list[#list + 1] = { t = s, dur = dur, name = label, failed = (result ~= 0), result = result }
      if lastDur[label] == nil and dur >= 0 then lastDur[label] = dur end
    end
  end
  f:close()
  return list, lastDur
end

-- ------------------------------------------------------------------ hooks ---

local function themeVar(name, fallback)
  local v = SKIN:GetVariable(name)
  if v == nil or v == '' then return fallback end
  return v
end

-- Whether THIS machine is the one actually running the real \Uipath Automation\
-- tasks (and should keep re-querying its own Task Scheduler every minute), or
-- a teammate's machine that just wants to VIEW the origin machine's live feed
-- (synced in via Syncthing/similar) without ever overwriting it. Defaults to
-- true (today's behavior, unchanged) unless IsSource=0 is set in the machine's
-- OWN @Resources\Settings.inc - which is per-machine and never synced (see
-- .stignore), so this is a one-line, no-conflict opt-out on viewer machines.
local isSource = true

function Initialize()
  -- Read the live feed from the MACHINE-LOCAL folder the PowerShell writes to
  -- (%LOCALAPPDATA%\AutomationReminder\), so nothing runtime-generated lives in
  -- the synced skin folder. Fall back to the skin folder if the var is missing.
  local cp = SKIN:GetVariable('CURRENTPATH')
  local la = os.getenv('LOCALAPPDATA')
  local base = la and (la .. '\\AutomationReminder\\') or cp
  dataFile = base .. '_taskdata.txt'
  histFile = base .. '_taskhist.txt'
  for _, t in ipairs(FALLBACK) do
    t.h = tonumber(t.time:sub(1, 2)); t.m = tonumber(t.time:sub(4, 5))
  end

  -- pull the active theme's colours (re-read on every !Refresh) --------------
  ACCENT  = themeVar('Accent', ACCENT)
  RUNC    = themeVar('RunColor', RUNC)
  SOONC   = themeVar('SoonColor', SOONC)
  PSTROKE = themeVar('PanelStroke', PSTROKE)
  ROWTEXT = themeVar('RowText', ROWTEXT)
  FAINT   = themeVar('Faint', FAINT)

  -- move the selection ring under the active swatch --------------------------
  -- Custom isn't a fixed-color dot (it's the "+ CUSTOM" text link), so there's
  -- no swatch position to ring - park it off-screen instead of drawing a
  -- circle around text, which would look like a rendering glitch.
  local th = themeVar('Theme', 'Sunset')
  if th == 'Custom' then
    setOpt('MeterThemeRing', 'X', '-100')
  else
    setOpt('MeterThemeRing', 'X', tostring(THEME_X[th] or THEME_X.Sunset))
  end

  isSource = themeVar('IsSource', '1') ~= '0'
  if isSource then
    SKIN:Bang('!CommandMeasure', 'MeasureShell', 'Run')   -- first live query on load
  end
end

function Update()
  tick = tick + 1
  local now = os.time()

  if isSource and tick % REFRESH_SEC == 0 then
    SKIN:Bang('!CommandMeasure', 'MeasureShell', 'Run')  -- re-query Task Scheduler
  end

  local d = readLive(now) or readFallback(now)
  local queue, prev, running, runningNow = d.queue, d.prev, d.running, d.runningNow or {}
  local failCount = d.failCount or 0

  -- health line under the brand: red failure count, so problems are visible
  -- even when the dashboard is collapsed.
  if failCount > 0 then
    setOpt('MeterSubtitle', 'Text', failCount .. (failCount == 1 and ' TASK FAILED' or ' TASKS FAILED'))
    setOpt('MeterSubtitle', 'FontColor', FAILC .. ',255')
  else
    setOpt('MeterSubtitle', 'Text', 'TASK SCHEDULER')
    setOpt('MeterSubtitle', 'FontColor', '#Dim#,220')
  end

  if #queue == 0 then
    setOpt('MeterNextName', 'Text', 'No upcoming tasks')
    setOpt('MeterCountdown', 'Text', '')
    return 1
  end

  local nxt       = queue[1]
  local remaining = nxt.t - now
  local isRunning = #running > 0
  local soon      = remaining < IMMINENT
  local accent    = soon and SOONC or ACCENT

  if #runningNow > 0 then
    -- User-requested behavior (a deliberate change from the "hero never
    -- shows a running task" rule above the old NEXT UP code had): while a
    -- task is actively running, the hero switches to NOW RUNNING with that
    -- task's name and how long it's been going, then automatically reverts
    -- to normal NEXT UP the moment nothing is running anymore - this whole
    -- block is skipped and the plain NEXT UP path below runs instead, no
    -- separate "revert" logic needed since it's recomputed fresh every tick.
    local rn = runningNow[1]
    setOpt('MeterNextLabel', 'Text', 'NOW RUNNING')
    setOpt('MeterNextLabel', 'FontColor', RUNC .. ',255')
    setOpt('MeterNextName',  'Text', rn.name)
    setOpt('MeterCountdown', 'Text', fmtDiff(rn.since) .. ' so far')
    setOpt('MeterCountdown', 'FontColor', RUNC .. ',255')
  else
    -- hero ALWAYS tracks the next task, so the name and countdown never
    -- disagree. (A task that just fired only pulses the dot unless it's
    -- caught by the branch above; it no longer hijacks the hero otherwise.)
    setOpt('MeterNextLabel', 'Text', 'NEXT UP')
    setOpt('MeterNextLabel', 'FontColor', accent .. ',255')
    setOpt('MeterNextName',  'Text', nxt.name)
    setOpt('MeterCountdown', 'Text', fmtCountdown(remaining, ''))
    setOpt('MeterCountdown', 'FontColor', accent .. ',255')
  end

  -- status dot: pulsing green while something runs, solid accent otherwise ---
  local dotColor = isRunning and RUNC or accent
  local dotAlpha = isRunning and math.floor(150 + 100 * math.sin(tick * 0.5)) or 255
  setOpt('MeterStatusDot', 'Shape',
    'Ellipse 4,4,4 | Fill Color ' .. dotColor .. ',' .. dotAlpha .. ' | StrokeWidth 0')

  -- mini progress bar between previous run and next run ----------------------
  local frac = 0
  if prev and nxt.t > prev then
    frac = (now - prev) / (nxt.t - prev)
    frac = frac < 0 and 0 or (frac > 1 and 1 or frac)
  end
  local w = math.floor(frac * BAR_WIDTH)
  if w < 3 then
    setOpt('MeterBarFill', 'Shape', 'Rectangle 0,0,0,0 | StrokeWidth 0')
  else
    setOpt('MeterBarFill', 'Shape',
      'Rectangle 0,0,' .. w .. ',4,2 | Fill LinearGradient FillGrad | StrokeWidth 0')
  end

  -- inline upcoming (three rows after the hero) : compact clock, no day prefix
  for i = 1, 3 do
    local q = queue[i + 1]
    setOpt('MeterUpT' .. i, 'Text', q and fmtClock(q.t) or '')
    setOpt('MeterUpN' .. i, 'Text', q and q.name or '')
  end

  -- ======================= DASHBOARD (dropdown) ===========================
  local hist = readHist()   -- recent runs + durations for the RUN HISTORY column
  local n = #queue

  -- Currently-running tasks are pinned at the top of the visible list (not
  -- part of the scrollable/counted queue - see readLive()'s runningNow
  -- comment for why they need to be tracked separately from `queue`).
  -- Capped at VISIBLE_SCHED as a defensive bound - if somehow more tasks
  -- are running at once than there are visible rows, the rest just don't
  -- get a pinned row rather than overflowing the meter pool.
  local runCount = #runningNow
  if runCount > VISIBLE_SCHED then runCount = VISIBLE_SCHED end
  local visibleForQueue = VISIBLE_SCHED - runCount

  -- clamp the scroll offset now that we know how many tasks there are --------
  local maxoff = n - visibleForQueue
  if maxoff < 0 then maxoff = 0 end
  if scroll > maxoff then scroll = maxoff end
  if scroll < 0 then scroll = 0 end

  -- stats computed over the WHOLE queue (not just the visible window) --------
  local leftToday, bigGap, bigAfter, bigAt = 0, 0, nil, nil
  for i = 1, n do
    local q = queue[i]
    if sameDay(q.t, now) then leftToday = leftToday + 1 end
    local nq = queue[i + 1]
    if nq and (q.t - now) < 86400 then
      local g = nq.t - q.t
      if g > bigGap then bigGap, bigAfter, bigAt = g, q.name, q.t end
    end
  end
  -- 24h health from the run history (completed OK vs failed) -----------------
  local okDay, failDay = 0, 0
  for _, h in ipairs(hist) do
    if (now - h.t) < 86400 then
      if h.failed then failDay = failDay + 1
      elseif h.dur >= 0 then okDay = okDay + 1 end
    end
  end
  local stats = n .. ' tasks    /    ' .. leftToday .. ' left today'
  if bigAfter then
    stats = stats .. '    /    largest free gap ' .. fmtDiff(bigGap) ..
            ' after ' .. bigAfter .. ' (' .. fmtClock(bigAt) .. ')'
  end
  if okDay + failDay > 0 then
    stats = stats .. '    /    24h: ' .. okDay .. ' ok, ' .. failDay .. ' failed'
  end
  setOpt('MeterPanelStats', 'Text', stats)

  -- left: pinned RUNNING NOW rows first, then the scrolled window of
  -- remaining queue rows -------------------------------------------------
  for r = 1, PANEL_ROWS do
    if r <= runCount then
      local rn = runningNow[r]
      setOpt('MeterAllN' .. r, 'Text', rn.name)
      setOpt('MeterAllN' .. r, 'FontColor', RUNC .. ',255')
      setOpt('MeterAllT' .. r, 'Text', 'RUNNING NOW')
      setOpt('MeterAllD' .. r, 'Text', fmtDiff(rn.since) .. ' so far')
      setOpt('MeterAllG' .. r, 'Text', '')
    else
      local qr = r - runCount
      local q = (qr <= visibleForQueue) and queue[scroll + qr] or nil
      if q then
        setOpt('MeterAllN' .. r, 'Text', q.name)
        setOpt('MeterAllN' .. r, 'FontColor',
          q.failed and (FAILC .. ',255') or (q.running and (RUNC .. ',255') or ROWTEXT))
        setOpt('MeterAllT' .. r, 'Text', fmtWhen(q.t, now))
        setOpt('MeterAllD' .. r, 'Text', fmtDiff(q.t - now))
        local nq = queue[scroll + qr + 1]
        setOpt('MeterAllG' .. r, 'Text', nq and fmtDiff(nq.t - q.t) or '')
      else
        setOpt('MeterAllN' .. r, 'Text', '')
        setOpt('MeterAllT' .. r, 'Text', '')
        setOpt('MeterAllD' .. r, 'Text', '')
        setOpt('MeterAllG' .. r, 'Text', '')
      end
    end
  end

  -- scrollbar + "showing X-Y of N" footer (queue portion only - the pinned
  -- RUNNING NOW rows above aren't part of this pagination) -------------------
  if n > visibleForQueue then
    local first, last = scroll + 1, scroll + visibleForQueue
    if last > n then last = n end
    setOpt('MeterScrollInfo', 'Text', 'showing ' .. first .. '-' .. last .. ' of ' .. n .. '    (scroll for more)')
    local thumbH = math.floor(SCROLL_TRACK_H * visibleForQueue / n)
    if thumbH < 20 then thumbH = 20 end
    local ty = SCROLL_TRACK_Y + math.floor((SCROLL_TRACK_H - thumbH) * (maxoff > 0 and scroll / maxoff or 0))
    setOpt('MeterScrollTrack', 'Shape',
      'Rectangle 607,' .. SCROLL_TRACK_Y .. ',2,' .. SCROLL_TRACK_H .. ',1 | Fill Color ' .. FAINT .. ' | StrokeWidth 0')
    setOpt('MeterScrollThumb', 'Shape',
      'Rectangle 606,' .. ty .. ',4,' .. thumbH .. ',2 | Fill Color ' .. ACCENT .. ',160 | StrokeWidth 0')
  else
    setOpt('MeterScrollInfo', 'Text', n .. ' tasks')
    setOpt('MeterScrollTrack', 'Shape', 'Rectangle 0,0,0,0 | StrokeWidth 0')
    setOpt('MeterScrollThumb', 'Shape', 'Rectangle 0,0,0,0 | StrokeWidth 0')
  end

  -- right: run history feed (independently scrollable) -----------------------
  local hn = #hist
  local hmax = hn - VISIBLE_HIST
  if hmax < 0 then hmax = 0 end
  if hscroll > hmax then hscroll = hmax end
  if hscroll < 0 then hscroll = 0 end
  for j = 1, HIST_ROWS do
    local h = (j <= VISIBLE_HIST) and hist[hscroll + j] or nil
    if h then
      local hcolor = h.failed and (FAILC .. ',255') or (h.dur < 0 and (RUNC .. ',255') or ROWTEXT)
      setOpt('MeterHT' .. j, 'Text', fmtWhen(h.t, now))
      setOpt('MeterHN' .. j, 'Text', h.name)
      setOpt('MeterHN' .. j, 'FontColor', hcolor)
      setOpt('MeterHD' .. j, 'Text', h.failed and 'FAIL' or fmtDur(h.dur))
      setOpt('MeterHD' .. j, 'FontColor', h.failed and (FAILC .. ',255') or ('#Dim#,235'))
    else
      setOpt('MeterHT' .. j, 'Text', '')
      setOpt('MeterHN' .. j, 'Text', '')
      setOpt('MeterHD' .. j, 'Text', '')
    end
  end
  if hn == 0 then
    setOpt('MeterHN1', 'Text', 'History off - turn on "All Tasks History" in Task Scheduler')
  end

  -- history scrollbar + "showing X-Y of N" footer ----------------------------
  if hn > VISIBLE_HIST then
    local f, l = hscroll + 1, hscroll + VISIBLE_HIST
    if l > hn then l = hn end
    setOpt('MeterHistInfo', 'Text', 'showing ' .. f .. '-' .. l .. ' of ' .. hn)
    local th = math.floor(HIST_TRACK_H * VISIBLE_HIST / hn)
    if th < 20 then th = 20 end
    local ty = HIST_TRACK_Y + math.floor((HIST_TRACK_H - th) * (hmax > 0 and hscroll / hmax or 0))
    setOpt('MeterHistTrack', 'Shape',
      'Rectangle 927,' .. HIST_TRACK_Y .. ',2,' .. HIST_TRACK_H .. ',1 | Fill Color ' .. FAINT .. ' | StrokeWidth 0')
    setOpt('MeterHistThumb', 'Shape',
      'Rectangle 926,' .. ty .. ',4,' .. th .. ',2 | Fill Color ' .. ACCENT .. ',160 | StrokeWidth 0')
  else
    setOpt('MeterHistInfo', 'Text', '')
    setOpt('MeterHistTrack', 'Shape', 'Rectangle 0,0,0,0 | StrokeWidth 0')
    setOpt('MeterHistThumb', 'Shape', 'Rectangle 0,0,0,0 | StrokeWidth 0')
  end

  return remaining > 0 and remaining or 1
end

-- Called by the panel's mouse-wheel bangs (!CommandMeasure MScript "Scroll(1)").
-- Update() re-clamps against the live task count on the next tick / redraw.
function Scroll(dir)
  scroll = scroll + dir * SCROLL_STEP
  if scroll < 0 then scroll = 0 end
end

-- Same, for the RUN HISTORY column (right half of the panel).
function ScrollH(dir)
  hscroll = hscroll + dir * SCROLL_STEP
  if hscroll < 0 then hscroll = 0 end
end
