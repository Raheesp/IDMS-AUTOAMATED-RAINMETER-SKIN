# ============================================================================
#  UpdateLauncher.ps1  -  the PowerShell half of AutomationReminder-Update-*.cmd
# ----------------------------------------------------------------------------
#  NOT run from here. MakeUpdate.ps1 copies it into the update .cmd, next to an
#  INFO section and a base64 zip of the whole skin folder. On the PC it's run
#  on, it:
#    1. finds the folder Rainmeter really loads skins from (Documents can live
#       in OneDrive) - offers to install Rainmeter via winget if it's missing;
#    2. zips a backup of the current AutomationReminder folder to
#       %LOCALAPPDATA%\AutomationReminder\backups\ (last 5 kept);
#    3. copies the new files over it, KEEPING that PC's @Resources\Settings.inc
#       (theme, design, IsSource) and its PythonExe= line in Downloads.ini;
#    4. runs Downloads\Setup.ps1 only when it's needed (first install, Python
#       or packages missing, scheduled tasks missing / pointing elsewhere),
#       otherwise just runs CheckInstall.ps1 (which also refreshes Rainmeter).
#  Nothing is deleted from the skin folder - files only get added or replaced.
#  Keep this file ASCII-only, and never start a line with ":::UPD:".
# ============================================================================

$ErrorActionPreference = 'Continue'
$ProgressPreference = 'SilentlyContinue'
Add-Type -AssemblyName System.IO.Compression.FileSystem
$selfText = [IO.File]::ReadAllText($env:AR_UPDATE_SELF)

function Say($m, $c = 'Gray') { Write-Host $m -ForegroundColor $c }
function Get-Section([string]$name) {
    $m = [regex]::Match($selfText, "(?ms)^:::UPD:" + $name + ":::\r?\n(.*?)(?=^:::UPD:|\z)")
    if ($m.Success) { return $m.Groups[1].Value } else { return $null }
}
function Stop-Update($msg) { Say ""; Say $msg 'Red'; exit 1 }

$info = @{}
foreach ($l in ((Get-Section 'INFO') -split "\r?\n")) { if ($l -match '^([^=]+)=(.*)$') { $info[$matches[1]] = $matches[2] } }
$zipB64 = Get-Section 'ZIP'
if (-not $zipB64) { Stop-Update "This update file is damaged. Make it again with MakeUpdate.bat." }

Say "=====================================================================" 'DarkCyan'
Say "  AUTOMATIONREMINDER UPDATE" 'Cyan'
Say "=====================================================================" 'DarkCyan'
Say "  Built:  $($info['built']) on $($info['from'])"
Say "  Files:  $($info['files'])"
Say ""

# --- 1. Rainmeter + the folder it loads skins from ------------------------------
Say "[1/4] Finding Rainmeter's skin folder..." 'Cyan'
$rmExe = (Get-Process Rainmeter -ErrorAction SilentlyContinue | Select-Object -First 1).Path
if (-not $rmExe) { foreach ($c in "$env:ProgramFiles\Rainmeter\Rainmeter.exe", "${env:ProgramFiles(x86)}\Rainmeter\Rainmeter.exe") { if (Test-Path $c) { $rmExe = $c } } }
if (-not $rmExe) {
    Say "      Rainmeter is not installed on this PC." 'Yellow'
    if (Get-Command winget -ErrorAction SilentlyContinue) {
        $a = Read-Host "      Install Rainmeter now with winget? [Y/n]"
        if ($a -notmatch '^[Nn]') {
            winget install -e --id Rainmeter.Rainmeter --silent --accept-source-agreements --accept-package-agreements | Out-Host
            foreach ($c in "$env:ProgramFiles\Rainmeter\Rainmeter.exe", "${env:ProgramFiles(x86)}\Rainmeter\Rainmeter.exe") { if (Test-Path $c) { $rmExe = $c } }
            if ($rmExe) { Start-Process $rmExe; Start-Sleep -Seconds 5 }
        }
    }
    if (-not $rmExe) { Stop-Update "Install Rainmeter 4.5 or newer from https://www.rainmeter.net, start it once, then run this update again." }
}
$rmIni = Join-Path $env:APPDATA 'Rainmeter\Rainmeter.ini'
$skinPath = $null
if (Test-Path $rmIni) {
    $sp = Select-String $rmIni -Pattern '^SkinPath=(.+)$' | Select-Object -First 1
    if ($sp) { $skinPath = $sp.Matches[0].Groups[1].Value.Trim() }
}
if (-not $skinPath) { $skinPath = Join-Path ([Environment]::GetFolderPath('MyDocuments')) 'Rainmeter\Skins' }
$target = Join-Path $skinPath.TrimEnd('\') 'AutomationReminder'
# testing only: AR_UPDATE_TARGET installs somewhere else and skips Setup + skin loading
$testRun = [bool]$env:AR_UPDATE_TARGET
if ($testRun) { $target = $env:AR_UPDATE_TARGET; Say "      TEST RUN - installing into $target" 'Yellow' }
$firstInstall = -not (Test-Path (Join-Path $target 'AutomationReminder.ini'))
Say "      $target" 'DarkGray'
Say ("      " + $(if ($firstInstall) { 'Not installed yet here - this is a first install.' } else { 'Existing install found - updating it.' })) 'DarkGray'

# --- 2. backup -----------------------------------------------------------------------
$appDir = Join-Path $env:LOCALAPPDATA 'AutomationReminder'
$oldPythonLine = $null
if (-not $firstInstall) {
    Say "[2/4] Backing up the current version..." 'Cyan'
    $bk = Join-Path $appDir 'backups'
    New-Item -ItemType Directory -Force -Path $bk | Out-Null
    $bkZip = Join-Path $bk ("skin_" + (Get-Date -Format 'yyyyMMdd_HHmmss') + ".zip")
    try {
        [IO.Compression.ZipFile]::CreateFromDirectory($target, $bkZip)
        Say "      $bkZip" 'DarkGray'
    } catch { Say "      Backup skipped: $($_.Exception.Message)" 'Yellow' }
    Get-ChildItem $bk -Filter 'skin_*.zip' | Sort-Object LastWriteTime -Descending | Select-Object -Skip 5 | Remove-Item -Force -ErrorAction SilentlyContinue
    $dlIni = Join-Path $target 'Downloads\Downloads.ini'
    if (Test-Path $dlIni) { $oldPythonLine = (Select-String $dlIni -Pattern '^PythonExe=.+$' | Select-Object -First 1).Line }
} else {
    Say "[2/4] Nothing to back up (first install)." 'Cyan'
}

# --- 3. install the new files ----------------------------------------------------------
Say "[3/4] Installing the new version..." 'Cyan'
$tmp = Join-Path $env:TEMP ("ar_update_" + [guid]::NewGuid().ToString('N').Substring(0, 8))
New-Item -ItemType Directory -Force -Path $tmp | Out-Null
$zip = Join-Path $tmp 'payload.zip'
[IO.File]::WriteAllBytes($zip, [Convert]::FromBase64String(($zipB64 -replace '\s', '')))
$ex = Join-Path $tmp 'x'
try { [IO.Compression.ZipFile]::ExtractToDirectory($zip, $ex) } catch { Stop-Update "Could not unpack the update: $($_.Exception.Message)" }
$src = Join-Path $ex 'AutomationReminder'
New-Item -ItemType Directory -Force -Path $target | Out-Null
$keepSettings = Test-Path (Join-Path $target '@Resources\Settings.inc')
$xf = @('CheckInstall_report.txt')
if ($keepSettings) { $xf += 'Settings.inc' }
if (Test-Path (Join-Path $target '@Resources\Themes\Custom.inc')) { $xf += 'Custom.inc' }   # that PC's own custom colours
robocopy $src $target /E /XF $xf /R:2 /W:2 /NFL /NDL /NJH /NJS /NP | Out-Null
$rc = $LASTEXITCODE
Remove-Item $tmp -Recurse -Force -ErrorAction SilentlyContinue
if ($rc -ge 8) { Stop-Update "Copying the new files failed (robocopy code $rc). Close anything that has these files open and run the update again." }
if (-not $keepSettings) {
    $def = @('; Persisted user settings for the Automation Reminder skin (per PC, never synced).',
             '[Variables]', 'Theme=Sunset', 'IsSource=1', 'Design=Classic')
    [IO.File]::WriteAllLines((Join-Path $target '@Resources\Settings.inc'), $def, (New-Object Text.UTF8Encoding($true)))
}
if ($oldPythonLine) {
    # keep THIS PC's Python path (Setup wrote it); the update carries the builder's
    $dlIni = Join-Path $target 'Downloads\Downloads.ini'
    $bom = ([IO.File]::ReadAllBytes($dlIni)[0] -eq 0xEF)
    $t = [IO.File]::ReadAllText($dlIni)
    $t = [regex]::Replace($t, '(?m)^PythonExe=.*$', $oldPythonLine.Replace('$', '$$'))
    [IO.File]::WriteAllText($dlIni, $t, (New-Object Text.UTF8Encoding($bom)))
}
Say ("      Done" + $(if ($keepSettings) { " - this PC's theme / design / settings were kept." } else { "." })) 'Green'

# --- 4. setup only if needed, then check + refresh ---------------------------------------
Say "[4/4] Checking Python, the download tools and scheduled tasks..." 'Cyan'
$needSetup = @()
if ($firstInstall) { $needSetup += 'first install' }
$pyw = $null
$l = Select-String (Join-Path $target 'Downloads\Downloads.ini') -Pattern '^PythonExe=(.+)$' | Select-Object -First 1
if ($l) { $pyw = $l.Matches[0].Groups[1].Value.Trim() }
if (-not $pyw -or -not (Test-Path $pyw)) { $needSetup += 'Python not found' }
else {
    & (Join-Path (Split-Path $pyw) 'python.exe') -c "import playwright, pandas, openpyxl" 2>$null
    if ($LASTEXITCODE -ne 0) { $needSetup += 'download tools missing' }
}
foreach ($t in 'AM DataDownloader', 'AM IdmsAvailabilityScan') {
    $st = Get-ScheduledTask -TaskName $t -ErrorAction SilentlyContinue
    if (-not $st) { $needSetup += "$t not registered" }
    elseif ($st.Actions[0].Arguments -notlike "*$target*") { $needSetup += "$t points to another folder" }
}
if ($testRun) {
    Say ("      TEST RUN - would run: " + $(if ($needSetup) { 'Setup (' + ($needSetup -join ', ') + ')' } else { 'CheckInstall only' })) 'Yellow'
    exit 0
}
if ($needSetup) {
    Say ("      Running Setup (" + ($needSetup -join ', ') + ")...") 'Yellow'
    & (Join-Path $target 'Downloads\Setup.ps1')
} else {
    Say "      All good - no Setup needed." 'Green'
    & (Join-Path $target 'CheckInstall.ps1') -NoPause -NoPrompt
}

if ($firstInstall -and $rmExe) {
    # load the skins that make sense for this PC
    $isSource = (Select-String (Join-Path $target '@Resources\Settings.inc') -Pattern '^IsSource=0' -Quiet) -eq $false
    & $rmExe '!RefreshApp'; Start-Sleep -Seconds 3
    if ($isSource) {
        & $rmExe '!ActivateConfig' 'AutomationReminder' 'AutomationReminder.ini'
        & $rmExe '!ActivateConfig' 'AutomationReminder\Downloads' 'Downloads.ini'
        & $rmExe '!ActivateConfig' 'AutomationReminder\NetWatch' 'NetWatch.ini'
    } else {
        & $rmExe '!ActivateConfig' 'AutomationReminder\MainSystem' 'MainSystem.ini'
    }
    Say "      Skins loaded - drag them where you like." 'Green'
}
Say ""
# the install check (run by Setup or directly above) wrote its verdict here
$problems = 0
$rep = Join-Path $target 'CheckInstall_report.txt'
if (Test-Path $rep) {
    $m = Select-String $rep -Pattern 'RESULT: (\d+) problem' | Select-Object -Last 1
    if ($m) { $problems = [int]$m.Matches[0].Groups[1].Value }
}
if ($problems -gt 0) {
    Say "UPDATE INSTALLED, but the check found $problems problem(s) - see above, or send $rep." 'Yellow'
    exit 3
}
Say "UPDATE FINISHED." 'Green'
Say "Change the look any time: right-click the AUTOMATION or PORTAL DATA bar -> Next design / Theme." 'DarkGray'
exit 0
