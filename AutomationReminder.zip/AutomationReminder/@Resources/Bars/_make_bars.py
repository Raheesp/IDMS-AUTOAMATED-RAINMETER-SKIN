"""Generates the always-visible bar of every skin for every DESIGN:

    @Resources\\Bars\\Main\\<Design>.inc     AUTOMATION bar   (<= 960 x 56)
    @Resources\\Bars\\Portal\\<Design>.inc   PORTAL DATA bar  (<= 700 x 44)
    @Resources\\Bars\\Net\\<Design>.inc      NETWATCH card    (X 5..225, Y <= 51)

    python _make_bars.py

Classic is NOT generated here: Main/Portal Classic.inc are the original bars
(hand-maintained) and Net Classic.inc is written by NetWatch\\_layout.py.

Rules every bar follows so the engines and dropdowns keep working:
  * the meter NAMES the engine fills are always present (hidden if a design
    doesn't show them) - see REQ_* below;
  * bars shorter than the slot are BOTTOM-aligned, so the dropdown still opens
    just under them (main panel Y=62, IDMS panel Y=48, NetWatch panel Y=56);
  * clicks keep their jobs: main card -> Task Scheduler, ALL TASKS -> dashboard,
    RUN NOW / UPDATE PASSWORD / IDMS, NetWatch card -> details, right-click ->
    Windows network settings.
Optional pieces (ring, digits, segments, ticker, timeline, tile, status block,
count bars/rings, latency) are filled by @Resources\\Widgets.lua and the engines.
"""
import os

HERE = os.path.dirname(os.path.abspath(__file__))
F = "#Font#"                  # the design's typeface (Designs\\<Name>.inc)
DIG = "Bahnschrift"           # condensed digits (ships with Windows 10/11)
MONO = "Consolas"
TXT, DIM, ACC, ACB = "#Text#,255", "#Dim#,230", "#Accent#,255", "#AccentB#,255"
RED = "255,120,110,255"
SHD = "Shadow | 0 | 1 | 3 | 0,0,0,180"


# ------------------------------------------------------------------ helpers ---
def S(name, text, x, y, size, weight=400, color=TXT, align="LeftCenter", font=F, **kw):
    d = dict(Meter="String", Text=text, X=x, Y=y, StringAlign=align, FontFace=font, FontSize=size,
             FontWeight=weight, FontColor=color, AntiAlias=1)
    d.update(kw)
    return name, d


def SH(name, shape, x=0, y=0, **kw):
    d = dict(Meter="Shape", X=x, Y=y, Shape=shape)
    d.update(kw)
    return name, d


def H(name, kind="String"):
    """A required meter this design doesn't show."""
    if kind == "Shape":
        d = dict(Meter="Shape", Shape="Rectangle 0,0,0,0 | StrokeWidth 0", Hidden=1)
        if name == "MeterBarFill":   # the engine still draws it with this gradient
            d["FillGrad"] = "0 | #Accent#,255 ; 0.0 | #AccentB#,255 ; 1.0"
        return name, d
    return name, dict(Meter="String", Text="", X=0, Y=0, FontFace=F, FontSize=7, Hidden=1)


def cardfill(x, y, w, h, r=None, fill="LinearGradient CardGrad", stroke="StrokeWidth #CardStrokeW# | Stroke Color #CardStrokeC#"):
    rr = r if r is not None else f"(#CardR# > {h // 2} ? {h // 2} : #CardR#)"
    return f"Rectangle {x + 0.5},{y + 0.5},{w - 1},{h - 1},{rr} | Fill {fill} | {stroke}"


GRAD = "90 | #DCardTop# ; 0.0 | #DCardBot# ; 1.0"
LS = "CharacterSpacing | 0.6 | 0.6"

# click jobs ------------------------------------------------------------------
MAIN_CARD = dict(LeftMouseUpAction='["taskschd.msc"]', ToolTipText="Open Task Scheduler#CRLF#Middle-click to refresh")
EXPAND = dict(LeftMouseUpAction="[!ToggleMeterGroup Panel][!UpdateMeterGroup Panel][!Redraw]",
              ToolTipText="Open the schedule dashboard (gaps, last run, history)")
RUN = dict(LeftMouseUpAction='[!CommandMeasure MeasureDownload "Run"][!SetOption MeterStatus Text "Starting..."][!UpdateMeter MeterStatus][!Redraw]',
           ToolTipText="Log in and download Booking / Docket / Enquiry now")
PASS = dict(ToolTipText="Opens creds.txt (line 1 = username, line 2 = password). Save, then RUN NOW.")
IDMS = dict(LeftMouseUpAction='[!ToggleMeterGroup IdmsPanel][!ToggleMeasureGroup IdmsPanel][!CommandMeasure MScriptIdms "Opened()"][!UpdateMeterGroup IdmsPanel][!Redraw]',
            ToolTipText="Pick any of the 33 IDMS reports, a date range, and download them in one go")
NET_CARD = dict(LeftMouseUpAction="[!ToggleMeterGroup Panel][!UpdateMeterGroup Panel][!Redraw]",
                RightMouseUpAction='["ms-settings:network"]', ToolTipText="Checking connection...")

REQ_MAIN = ["MeterCard", "MeterTitle", "MeterSubtitle", "MeterStatusDot", "MeterNextLabel", "MeterNextName",
            "MeterCountdown", "MeterBarFill", "MeterUpT1", "MeterUpN1", "MeterUpT2", "MeterUpN2",
            "MeterUpT3", "MeterUpN3", "MeterExpandBtn"]
REQ_PORTAL = ["MeterCard", "MeterTitle", "MeterStatus", "MeterLblBooking", "MeterCntBooking", "MeterLblDocket",
              "MeterCntDocket", "MeterLblEnquiry", "MeterCntEnquiry", "MeterBanner", "MeterBtnRun",
              "MeterBtnPass", "MeterBtnIdms"]
REQ_NET = ["MeterCard", "MeterOrbOuter", "MeterOrbGlowB", "MeterOrbGlowA", "MeterOrbRing", "MeterOrbRing2",
           "MeterOrbDot", "MeterOrbDot2", "MeterOrbCore", "MeterState", "MeterStatusLbl", "MeterGraph",
           "MeterTime", "MeterPwrPip", "MeterChevron"]
SHAPES = {"MeterCard", "MeterStatusDot", "MeterBarFill", "MeterPwrPip", "MeterChevron", "MeterOrbOuter",
          "MeterOrbGlowB", "MeterOrbGlowA", "MeterOrbDot", "MeterOrbDot2", "MeterOrbCore"}


def bar(x, y, w, h=3, r=1.5, track="#Faint#"):
    """Main-bar progress: track + the engine-filled MeterBarFill."""
    return [SH("MeterBarTrack", f"Rectangle 0,0,{w},{h},{r} | Fill Color {track} | StrokeWidth 0", x, y),
            ("MeterBarFill", dict(Meter="Shape", X=x, Y=y, Shape="Rectangle 0,0,0,0 | StrokeWidth 0",
                                  FillGrad="0 | #Accent#,255 ; 0.0 | #AccentB#,255 ; 1.0"))]


def orb(mode, cx, cy):
    """The NetWatch orb at (cx, cy). mode: full | core | none."""
    hide_ring = mode != "full"
    hide_all = mode == "none"
    ring = dict(Meter="Roundline", MeasureName="MeasureFull", DynamicVariables=1, Solid=1, AntiAlias=1)
    m = [
        SH("MeterOrbOuter", f"Ellipse {cx},{cy},17 | Fill Color 255,255,255,7 | StrokeWidth 1 | Stroke Color 255,255,255,20", **({"Hidden": 1} if hide_ring else {})),
        SH("MeterOrbGlowB", f"Ellipse {cx},{cy},8.8 | Fill Color 34,222,124,14", **({"Hidden": 1} if hide_all else {})),
        SH("MeterOrbGlowA", f"Ellipse {cx},{cy},7.2 | Fill Color 34,222,124,30", **({"Hidden": 1} if hide_all else {})),
        ("MeterOrbRing", dict(ring, X=cx - 15, Y=cy - 15, W=30, H=30, StartAngle=4.4506, RotationAngle=5.1487,
                              LineStart=12.2, LineLength=13.8, LineColor="34,222,124,255", **({"Hidden": 1} if hide_ring else {}))),
        ("MeterOrbRing2", dict(ring, X=cx - 11, Y=cy - 11, W=22, H=22, StartAngle=1.2, RotationAngle=2.4435,
                               LineStart=8.3, LineLength=9.7, LineColor="34,222,124,150", **({"Hidden": 1} if hide_ring else {}))),
        SH("MeterOrbDot", f"Ellipse {cx},{cy - 13},2 | Fill Color 200,255,225,255", **({"Hidden": 1} if hide_ring else {})),
        SH("MeterOrbDot2", f"Ellipse {cx},{cy - 9},1.5 | Fill Color 200,255,225,190", **({"Hidden": 1} if hide_ring else {})),
        SH("MeterOrbCore", f"Ellipse {cx},{cy},6.5 | Fill Color 45,232,130,255", **({"Hidden": 1} if hide_all else {})),
    ]
    return m


def graph(x, y, w, h, color="34,222,124,255", width=1.2):
    return ("MeterGraph", dict(Meter="Line", MeasureName="MeasureGraph", UpdateDivider=20, X=x, Y=y, W=w, H=h,
                               LineCount=1, LineWidth=width, LineColor=color, AutoScale=0, HorizontalLines=0,
                               Solid=0, GraphStart="Right", AntiAlias=1))


def chevron(x, y, color="#Text#,200"):
    return SH("MeterChevron", f"Line {x},{y},{x + 4},{y + 5} | StrokeWidth 1.2 | Stroke Color {color} | StrokeStartCap Round | StrokeEndCap Round",
              Shape2=f"Line {x + 4},{y + 5},{x + 9},{y} | StrokeWidth 1.2 | Stroke Color {color} | StrokeStartCap Round | StrokeEndCap Round")


PIP = SH("MeterPwrPip", "Rectangle 0,0,0,0 | StrokeWidth 0")

# ================================================================ DESIGNS ===
# Each returns dict(main=(vars, meters), portal=(vars, meters), net=(vars, meters)).
D = {}


# ---------------------------------------------------------------- Hairline ---
def hairline():
    y0, cy = 22, 39
    main = [SH("MeterCard", cardfill(0, y0, 960, 34), CardGrad=GRAD, **MAIN_CARD),
            S("MeterTitle", "AUTOMATION", 16, cy, 8.5, 700, TXT, InlineSetting=LS),
            S("MeterSubtitle", "TASK SCHEDULER", "10R", cy, 6.5, 600, DIM),
            SH("MeterDiv1", "Rectangle 0,0,1,16 | Fill Color #Faint# | StrokeWidth 0", 222, cy - 8),
            SH("MeterStatusDot", "Ellipse 3.5,3.5,3.5 | Fill Color #Accent#,255 | StrokeWidth 0", 236, cy - 4),
            S("MeterNextLabel", "NEXT UP", 250, cy, 7, 700, ACC, InlineSetting=LS),
            S("MeterNextName", "Loading...", "8R", cy, 10.5, 600, W=270, H=18, ClipString=1),
            S("MeterCountdown", "", 628, cy, 13, 300, ACC, "RightCenter"),
            SH("MeterDiv2", "Rectangle 0,0,1,16 | Fill Color #Faint# | StrokeWidth 0", 642, cy - 8),
            S("MeterUpT1", "", 656, cy, 7.5, 700, "#Accent#,200"), S("MeterUpN1", "", "5R", cy, 7.5, 400, "#RowText#", W=62, H=14, ClipString=1),
            S("MeterUpT2", "", 776, cy, 7.5, 700, "#Accent#,200"), S("MeterUpN2", "", "5R", cy, 7.5, 400, "#RowText#", W=62, H=14, ClipString=1),
            H("MeterUpT3"), H("MeterUpN3"),
            S("MeterExpandBtn", "ALL TASKS  v", 948, cy, 7.5, 700, DIM, "RightCenter", **EXPAND)] + bar(12, 52, 936, 2, 1)
    py0, pcy = 14, 29
    portal = [SH("MeterCard", cardfill(0, py0, 700, 30), CardGrad=GRAD),
              S("MeterTitle", "PORTAL DATA", 14, pcy, 8, 700, TXT, InlineSetting=LS),
              S("MeterStatus", "Loading...", "8R", pcy, 6.5, 500, DIM, W=110, H=13, ClipString=1),
              S("MeterLblBooking", "BOOKING", 236, pcy, 6.5, 600, DIM), S("MeterCntBooking", "-", "5R", pcy, 10, 700),
              S("MeterLblDocket", "DOCKET", 344, pcy, 6.5, 600, DIM), S("MeterCntDocket", "-", "5R", pcy, 10, 700),
              S("MeterLblEnquiry", "ENQUIRY", 446, pcy, 6.5, 600, DIM), S("MeterCntEnquiry", "-", "5R", pcy, 10, 700),
              H("MeterBanner"),
              S("MeterBtnRun", "RUN", 566, pcy, 7.5, 700, ACC, **RUN),
              S("MeterBtnPass", "PASSWORD", 600, pcy, 7.5, 700, DIM, **PASS),
              S("MeterBtnIdms", "IDMS v", 692, pcy, 7.5, 700, ACC, "RightCenter", **IDMS)]
    ny0 = 23
    net = [SH("MeterCard", cardfill(5, ny0, 220, 28), CardGrad=GRAD, **NET_CARD)] + orb("core", 20, ny0 + 14) + [
        S("MeterState", "CHECKING", 34, ny0 + 14, 8.5, 700, TXT, InlineSetting=LS),
        H("MeterStatusLbl"), graph(104, ny0 + 6, 58, 16), S("MeterTime", "", 168, ny0 + 14, 6, 500, "#RowText#"),
        PIP, chevron(208, ny0 + 12)]
    return dict(main=(dict(BarW=936, BarH=2, BarR=1, DotR=3.5), main),
                portal=({}, portal), net=(dict(OrbX=20, OrbY=ny0 + 14, PipX=200, PipY=ny0 + 14), net))


D["Hairline"] = hairline


# ----------------------------------------------------------------- Capsule ---
def capsule():
    y0, h = 8, 48
    cy = y0 + 24
    chip = "Fill Color 255,255,255,22 | StrokeWidth 1 | Stroke Color 255,255,255,40"
    main = [SH("MeterCard", cardfill(0, y0, 960, h, 24), CardGrad=GRAD, **MAIN_CARD),
            SH("MeterPillA", f"Rectangle 8,{y0 + 8},196,32,16 | {chip}"),
            SH("MeterStatusDot", "Ellipse 4,4,4 | Fill Color #Accent#,255 | StrokeWidth 0", 20, cy - 4),
            S("MeterTitle", "AUTOMATION", 34, cy - 6, 8, 700, TXT, InlineSetting=LS),
            S("MeterSubtitle", "TASK SCHEDULER", 34, cy + 7, 6.5, 600, DIM),
            S("MeterNextLabel", "NEXT UP", 222, cy - 8, 6.5, 700, ACC, InlineSetting=LS),
            S("MeterNextName", "Loading...", 222, cy + 7, 11, 600, W=240, H=18, ClipString=1),
            SH("MeterPillB", f"Rectangle 474,{y0 + 8},160,32,16 | Fill Color #Accent#,38 | StrokeWidth 1 | Stroke Color #Accent#,90"),
            S("MeterCountdown", "", 554, cy - 2, 11, 600, ACC, "CenterCenter")] + bar(494, cy + 9, 120, 2, 1) + [
            SH("MeterPillC", f"Rectangle 646,{y0 + 8},136,32,16 | {chip}"),
            S("MeterUpT1", "", 660, cy, 7, 700, ACC), S("MeterUpN1", "", "5R", cy, 7.5, 400, "#RowText#", W=62, H=14, ClipString=1),
            SH("MeterPillD", f"Rectangle 788,{y0 + 8},72,32,16 | {chip}"),
            S("MeterUpT2", "", 824, cy, 7, 700, ACC, "CenterCenter"), H("MeterUpN2"), H("MeterUpT3"), H("MeterUpN3"),
            SH("MeterPillE", f"Rectangle 866,{y0 + 8},86,32,16 | Fill Color #Accent#,60 | StrokeWidth 0", **EXPAND),
            S("MeterExpandBtn", "ALL  v", 909, cy, 8, 700, TXT, "CenterCenter", **EXPAND)]
    py0 = 4
    pcy = py0 + 20
    portal = [SH("MeterCard", cardfill(0, py0, 700, 40, 20), CardGrad=GRAD),
              SH("MeterPillA", f"Rectangle 6,{py0 + 5},150,30,15 | {chip}"),
              S("MeterTitle", "PORTAL DATA", 20, pcy - 6, 8, 700, TXT, InlineSetting=LS),
              S("MeterStatus", "Loading...", 20, pcy + 7, 6.5, 500, DIM, W=128, H=12, ClipString=1)]
    for i, (n, lab) in enumerate((("Booking", "BOOKING"), ("Docket", "DOCKET"), ("Enquiry", "ENQUIRY"))):
        x = 164 + i * 124
        portal += [SH(f"MeterPill{n}", f"Rectangle {x},{py0 + 5},116,30,15 | Fill Color #Accent#,30 | StrokeWidth 1 | Stroke Color #Accent#,70"),
                   S(f"MeterLbl{n}", lab, x + 12, pcy, 6.5, 600, DIM), S(f"MeterCnt{n}", "-", x + 104, pcy, 11, 700, TXT, "RightCenter")]
    portal += [H("MeterBanner"),
               SH("MeterPillRun", f"Rectangle 528,{py0 + 5},60,30,15 | Fill Color #Accent#,70 | StrokeWidth 0", **RUN),
               S("MeterBtnRun", "RUN", 558, pcy, 8, 700, TXT, "CenterCenter", **RUN),
               S("MeterBtnPass", "PASSWORD", 596, pcy, 7, 700, DIM, **PASS),
               S("MeterBtnIdms", "IDMS v", 692, pcy, 7.5, 700, ACC, "RightCenter", **IDMS)]
    ny0 = 13
    net = [SH("MeterCard", cardfill(5, ny0, 220, 38, 19), CardGrad=GRAD, **NET_CARD),
           SH("MeterOrbDisc", f"Ellipse 24,{ny0 + 19},14 | Fill Color 255,255,255,18 | StrokeWidth 1 | Stroke Color 255,255,255,40")] + \
        orb("core", 24, ny0 + 19) + [
        S("MeterState", "CHECKING", 46, ny0 + 13, 8.5, 700, TXT, InlineSetting=LS),
        S("MeterPing", "", 46, ny0 + 26, 6.5, 600, DIM), H("MeterStatusLbl"),
        graph(112, ny0 + 10, 54, 18), S("MeterTime", "", 172, ny0 + 19, 6, 500, "#RowText#"),
        PIP, chevron(207, ny0 + 17)]
    return dict(main=(dict(BarW=120, BarH=2, BarR=1, DotR=4), main), portal=({}, portal),
                net=(dict(OrbX=24, OrbY=ny0 + 19, PipX=200, PipY=ny0 + 19), net))


D["Capsule"] = capsule


# ------------------------------------------------------------------ Ticker ---
def ticker():
    main = [SH("MeterCard", cardfill(0, 0, 960, 56), CardGrad=GRAD, **MAIN_CARD),
            SH("MeterStatusDot", "Ellipse 3.5,3.5,3.5 | Fill Color #Accent#,255 | StrokeWidth 0", 16, 13),
            S("MeterTitle", "AUTOMATION", 30, 17, 8, 700, TXT, InlineSetting=LS),
            S("MeterNextLabel", "NEXT UP", 150, 17, 7, 700, ACC, InlineSetting=LS),
            S("MeterNextName", "Loading...", "8R", 17, 11, 600, W=440, H=20, ClipString=1),
            S("MeterCountdown", "", 944, 17, 13, 300, ACC, "RightCenter")] + bar(16, 30, 928, 2, 1) + [
            S("MeterThenLbl", "THEN", 16, 44, 6.5, 700, DIM, InlineSetting=LS),
            S("MeterTicker", "", 56, 44, 8.5, 400, "#RowText#", W=440, H=15, ClipString=1),
            S("MeterSubtitle", "TASK SCHEDULER", 520, 44, 6.5, 700, DIM),
            H("MeterUpT1"), H("MeterUpN1"), H("MeterUpT2"), H("MeterUpN2"), H("MeterUpT3"), H("MeterUpN3"),
            S("MeterExpandBtn", "ALL TASKS  v", 944, 44, 7.5, 700, DIM, "RightCenter", **EXPAND)]
    portal = [SH("MeterCard", cardfill(0, 0, 700, 44), CardGrad=GRAD),
              S("MeterTitle", "PORTAL DATA", 14, 12, 8, 700, TXT, InlineSetting=LS),
              S("MeterStatus", "Loading...", "10R", 12, 6.5, 500, DIM, W=200, H=12, ClipString=1),
              S("MeterBtnRun", "RUN NOW", 520, 12, 7.5, 700, ACC, **RUN),
              S("MeterBtnPass", "PASSWORD", 580, 12, 7.5, 700, DIM, **PASS),
              S("MeterBtnIdms", "IDMS v", 690, 12, 7.5, 700, ACC, "RightCenter", **IDMS),
              SH("MeterSep", "Rectangle 14,22,672,1 | Fill Color #Faint# | StrokeWidth 0"),
              S("MeterLblBooking", "BOOKING", 14, 33, 6.5, 600, DIM), S("MeterCntBooking", "-", "6R", 33, 9.5, 700),
              S("MeterLblDocket", "DOCKET", 150, 33, 6.5, 600, DIM), S("MeterCntDocket", "-", "6R", 33, 9.5, 700),
              S("MeterLblEnquiry", "ENQUIRY", 280, 33, 6.5, 600, DIM), S("MeterCntEnquiry", "-", "6R", 33, 9.5, 700),
              S("MeterBanner", "", 420, 33, 6.5, 600, RED, W=270, H=12, ClipString=1)]
    net = [SH("MeterCard", cardfill(5, 5, 220, 46), CardGrad=GRAD, **NET_CARD)] + orb("core", 18, 17) + [
        S("MeterState", "CHECKING", 30, 17, 8.5, 700, TXT, InlineSetting=LS),
        S("MeterPing", "", "8R", 17, 6.5, 600, DIM), H("MeterStatusLbl"),
        S("MeterTime", "", 202, 17, 6, 500, "#RowText#", "RightCenter"),
        graph(12, 28, 206, 17), PIP, chevron(208, 14)]
    return dict(main=(dict(BarW=928, BarH=2, BarR=1, DotR=3.5), main), portal=({}, portal),
                net=(dict(OrbX=18, OrbY=17, PipX=208, PipY=34), net))


D["Ticker"] = ticker


# -------------------------------------------------------------------- Ring ---
def ring():
    main = [SH("MeterCard", cardfill(0, 0, 960, 56), CardGrad=GRAD, **MAIN_CARD),
            SH("MeterRingTrack", "Ellipse 30,28,22 | Fill Color 0,0,0,0 | StrokeWidth 4 | Stroke Color 255,255,255,26"),
            SH("MeterArc", "Rectangle 0,0,0,0 | StrokeWidth 0"),
            S("MeterClock", "--:--", 30, 28, 8.5, 700, ACC, "CenterCenter"),
            S("MeterTitle", "AUTOMATION", 64, 20, 8, 700, TXT, InlineSetting=LS),
            S("MeterSubtitle", "TASK SCHEDULER", 64, 37, 6.5, 600, DIM),
            SH("MeterDiv1", "Rectangle 0,0,1,30 | Fill Color #Faint# | StrokeWidth 0", 196, 13),
            SH("MeterStatusDot", "Ellipse 3.5,3.5,3.5 | Fill Color #Accent#,255 | StrokeWidth 0", 212, 16),
            S("MeterNextLabel", "NEXT UP", 226, 20, 7, 700, ACC, InlineSetting=LS),
            S("MeterNextName", "Loading...", 212, 37, 12, 600, W=330, H=20, ClipString=1),
            S("MeterCountdown", "", 640, 28, 12, 300, ACC, "RightCenter"),
            H("MeterBarFill", "Shape")]
    for i, x in enumerate((690, 766, 842), 1):
        main += [SH(f"MeterUpRing{i}", f"Ellipse {x},28,22 | Fill Color 255,255,255,10 | StrokeWidth 1.5 | Stroke Color #Accent#,110"),
                 S(f"MeterUpT{i}", "", x, 24, 6.5, 700, ACC, "CenterCenter"),
                 S(f"MeterUpN{i}", "", x, 35, 5.5, 400, "#RowText#", "CenterCenter", W=40, H=10, ClipString=1)]
    main += [S("MeterExpandBtn", "ALL  v", 946, 28, 8, 700, DIM, "RightCenter", **EXPAND)]
    portal = [SH("MeterCard", cardfill(0, 0, 700, 44), CardGrad=GRAD),
              S("MeterTitle", "PORTAL DATA", 14, 14, 8, 700, TXT, InlineSetting=LS),
              S("MeterStatus", "Loading...", 14, 30, 6.5, 500, DIM, W=120, H=12, ClipString=1)]
    arcs = {}
    for i, (n, lab) in enumerate((("Booking", "BOOKING"), ("Docket", "DOCKET"), ("Enquiry", "ENQUIRY"))):
        cx = 170 + i * 130
        arcs[f"Arc{n}X"] = cx
        portal += [SH(f"MeterCntTrack{n}", f"Ellipse {cx},22,16 | Fill Color 0,0,0,0 | StrokeWidth 3 | Stroke Color 255,255,255,26"),
                   SH(f"MeterCntArc{n}", "Rectangle 0,0,0,0 | StrokeWidth 0"),
                   S(f"MeterLbl{n}", lab, cx + 24, 15, 6.5, 600, DIM), S(f"MeterCnt{n}", "-", cx + 24, 29, 11, 700)]
    portal += [H("MeterBanner"),
               S("MeterBtnRun", "RUN NOW", 590, 14, 7.5, 700, ACC, **RUN),
               S("MeterBtnPass", "PASSWORD", 590, 30, 7.5, 700, DIM, **PASS),
               S("MeterBtnIdms", "IDMS v", 692, 22, 7.5, 700, ACC, "RightCenter", **IDMS)]
    net = [SH("MeterCard", cardfill(28, 5, 197, 46, 23), CardGrad=GRAD, **NET_CARD),
           SH("MeterRingBadge", "Ellipse 28,28,22.5 | Fill LinearGradient BadgeGrad | StrokeWidth 1.5 | Stroke Color #Accent#,120",
              BadgeGrad=GRAD, **NET_CARD)] + orb("full", 28, 28) + [
        S("MeterState", "CHECKING", 60, 21, 9.5, 700, TXT, InlineSetting=LS),
        S("MeterPing", "", 60, 36, 7, 600, ACC), H("MeterStatusLbl"),
        graph(120, 18, 42, 18), S("MeterTime", "", 168, 28, 6, 500, "#RowText#"),
        PIP, chevron(210, 25)]
    return dict(main=(dict(BarW=10, DotR=3.5, RingCX=30, RingCY=28, RingR=22, RingSW=4), main),
                portal=(dict(ArcY=22, ArcR=16, ArcSW=3, **arcs), portal),
                net=(dict(OrbX=28, OrbY=28, PipX=203, PipY=28), net))


D["Ring"] = ring


# ------------------------------------------------------------------- Queue ---
def queue():
    main = [SH("MeterCard", cardfill(0, 0, 960, 56), CardGrad=GRAD, **MAIN_CARD),
            S("MeterTitle", "AUTOMATION", 16, 16, 8, 700, TXT, InlineSetting=LS),
            S("MeterSubtitle", "TASK SCHEDULER", 16, 40, 6.5, 600, DIM),
            SH("MeterStatusDot", "Ellipse 3.5,3.5,3.5 | Fill Color #Accent#,255 | StrokeWidth 0", 150, 12),
            S("MeterNextLabel", "NEXT UP", 164, 16, 7, 700, ACC, InlineSetting=LS),
            S("MeterNextName", "Loading...", 150, 34, 12, 600, W=250, H=20, ClipString=1),
            S("MeterCountdown", "", 522, 16, 11, 300, ACB, "RightCenter")] + bar(412, 38, 110, 3, 1.5) + [
            SH("MeterQueueLine", "Rectangle 546,19,340,1.5 | Fill Color #AccentB#,90 | StrokeWidth 0")]
    for i, x in enumerate((570, 690, 810), 1):
        main += [SH(f"MeterUpDot{i}", f"Ellipse {x},20,4.5 | Fill Color #CardBot# | StrokeWidth 1.5 | Stroke Color #AccentB#,255"),
                 S(f"MeterUpT{i}", "", x, 34, 7, 700, ACB, "CenterCenter"),
                 S(f"MeterUpN{i}", "", x, 47, 7.5, 400, "#RowText#", "CenterCenter", W=112, H=14, ClipString=1)]
    main += [S("MeterExpandBtn", "ALL  v", 948, 28, 8, 700, DIM, "RightCenter", **EXPAND)]
    portal = [SH("MeterCard", cardfill(0, 0, 700, 44), CardGrad=GRAD),
              S("MeterTitle", "PORTAL DATA", 14, 14, 8, 700, TXT, InlineSetting=LS),
              S("MeterStatus", "Loading...", 14, 31, 6.5, 500, DIM, W=130, H=12, ClipString=1),
              SH("MeterQueueLine", "Rectangle 186,13,330,1.5 | Fill Color #AccentB#,90 | StrokeWidth 0")]
    for i, (n, lab) in enumerate((("Booking", "BOOKING"), ("Docket", "DOCKET"), ("Enquiry", "ENQUIRY"))):
        x = 210 + i * 140
        portal += [SH(f"MeterNode{n}", f"Ellipse {x},14,4.5 | Fill Color #CardBot# | StrokeWidth 1.5 | Stroke Color #AccentB#,255"),
                   S(f"MeterLbl{n}", lab, x + 12, 14, 6.5, 600, DIM), S(f"MeterCnt{n}", "-", x, 32, 11, 700, TXT, "CenterCenter")]
    portal += [H("MeterBanner"),
               S("MeterBtnRun", "RUN NOW", 580, 14, 7.5, 700, ACC, **RUN),
               S("MeterBtnPass", "PASSWORD", 580, 31, 7.5, 700, DIM, **PASS),
               S("MeterBtnIdms", "IDMS v", 692, 22, 7.5, 700, ACC, "RightCenter", **IDMS)]
    net = [SH("MeterCard", cardfill(5, 5, 220, 46), CardGrad=GRAD, **NET_CARD)] + orb("none", 0, 0) + [
        SH("MeterStateDot", "Ellipse 4,4,3.5 | Fill Color #Accent#,255 | StrokeWidth 0", 14, 13),
        S("MeterState", "CHECKING", 28, 17, 8.5, 700, TXT, InlineSetting=LS),
        S("MeterPing", "", 206, 17, 7, 600, ACB, "RightCenter"), H("MeterStatusLbl"),
        SH("MeterNetLine", "Rectangle 18,34,150,1 | Fill Color #AccentB#,80 | StrokeWidth 0"),
        graph(18, 26, 150, 17, "#AccentB#,255"),
        S("MeterTime", "", 206, 36, 6, 500, "#RowText#", "RightCenter"),
        PIP, chevron(210, 32)]
    return dict(main=(dict(BarW=110, BarH=3, BarR=1.5, DotR=3.5), main), portal=({}, portal),
                net=(dict(OrbX=-50, OrbY=-50, PipX=176, PipY=36), net))


D["Queue"] = queue


# ----------------------------------------------------------------- Console ---
def console():
    mono = dict(font=MONO)
    main = [SH("MeterCard", cardfill(0, 0, 960, 56, "#CardR#", fill="Color #DCardBot#"), **MAIN_CARD),
            S("MeterTitle", "main@automation:~$", 12, 12, 8.5, 400, DIM, **mono),
            S("MeterNextLabel", "NEXT UP", "8R", 12, 8.5, 700, ACC, **mono),
            S("MeterNextName", "loading...", "8R", 12, 8.5, 700, TXT, W=360, H=16, ClipString=1, **mono),
            S("MeterEta", "  eta", 12, 28, 8.5, 400, DIM, **mono),
            S("MeterHMS", "--:--:--", 60, 28, 8.5, 700, ACC, **mono),
            S("MeterAscii", "", 140, 28, 8.5, 400, "#Accent#,200", **mono),
            S("MeterCountdown", "", 246, 28, 8.5, 400, DIM, **mono),
            S("MeterConsole3", "", 12, 44, 8.5, 400, DIM, W=560, H=16, ClipString=1, **mono),
            S("MeterCursor", "_", "0R", 44, 8.5, 700, ACC, **mono),
            H("MeterSubtitle"), H("MeterStatusDot", "Shape"), H("MeterBarFill", "Shape"),
            SH("MeterDiv", "Rectangle 0,0,1,40 | Fill Color #Accent#,50 | StrokeWidth 0", 620, 8)]
    for i, y in enumerate((12, 28, 44), 1):
        main += [S(f"MeterUpT{i}", "", 636, y, 8.5, 700, ACC, **mono),
                 S(f"MeterUpN{i}", "", 716, y, 8.5, 400, "#RowText#", W=160, H=16, ClipString=1, **mono)]
    main += [S("MeterExpandBtn", "[all]", 948, 12, 8.5, 700, ACC, "RightCenter", **EXPAND, **mono)]
    portal = [SH("MeterCard", cardfill(0, 0, 700, 44, "#CardR#", fill="Color #DCardBot#")),
              S("MeterTitle", "portal@idms:~$ counts", 12, 13, 8.5, 400, DIM, **mono),
              S("MeterStatus", "loading...", "10R", 13, 8.5, 400, ACC, W=220, H=16, ClipString=1, **mono),
              S("MeterLblBooking", "booking=", 12, 31, 8.5, 400, DIM, **mono), S("MeterCntBooking", "-", "0R", 31, 8.5, 700, ACC, **mono),
              S("MeterLblDocket", "docket=", "14R", 31, 8.5, 400, DIM, **mono), S("MeterCntDocket", "-", "0R", 31, 8.5, 700, ACC, **mono),
              S("MeterLblEnquiry", "enquiry=", "14R", 31, 8.5, 400, DIM, **mono), S("MeterCntEnquiry", "-", "0R", 31, 8.5, 700, ACC, **mono),
              S("MeterBanner", "", 420, 31, 8.5, 400, RED, W=270, H=16, ClipString=1, **mono),
              S("MeterBtnRun", "[run]", 548, 13, 8.5, 700, ACC, **RUN, **mono),
              S("MeterBtnPass", "[passwd]", 590, 13, 8.5, 700, DIM, **PASS, **mono),
              S("MeterBtnIdms", "[idms]", 692, 13, 8.5, 700, ACC, "RightCenter", **IDMS, **mono)]
    net = [SH("MeterCard", cardfill(5, 5, 220, 46, "#CardR#", fill="Color #DCardBot#"), **NET_CARD)] + orb("none", 0, 0) + [
        S("MeterStatusLbl", "net:", 12, 16, 8, 400, DIM, **mono),
        S("MeterState", "CHECKING", "6R", 16, 8, 700, TXT, **mono),
        S("MeterPing", "", "8R", 16, 8, 700, ACC, **mono),
        S("MeterSince", "since", 12, 36, 8, 400, DIM, **mono),
        S("MeterTime", "", "6R", 36, 8, 400, "#RowText#", **mono),
        graph(150, 29, 56, 14, "#Accent#,255", 1.0),
        PIP, S("MeterChevron", "[+]", 222, 16, 8, 700, ACC, "RightCenter", **mono)]
    return dict(main=(dict(BarW=10), main), portal=({}, portal), net=(dict(OrbX=-50, OrbY=-50, PipX=214, PipY=36), net))


D["Console"] = console


# ----------------------------------------------------------------- Digital ---
def digital():
    dg = dict(font=DIG)
    main = [SH("MeterCard", cardfill(0, 0, 960, 56), CardGrad=GRAD, **MAIN_CARD),
            SH("MeterGloss", "Rectangle 1,1,958,20,((#CardR# > 28 ? 28 : #CardR#) - 1) | Fill LinearGradient GlossGrad | StrokeWidth 0",
               GlossGrad="90 | #DGlossA# ; 0.0 | #DGlossB# ; 1.0"),
            S("MeterTitle", "AUTOMATION", 16, 18, 8, 700, TXT, InlineSetting=LS),
            S("MeterSubtitle", "TASK SCHEDULER", 16, 38, 6.5, 600, DIM),
            SH("MeterDiv1", "Rectangle 0,0,1,34 | Fill Color #Faint# | StrokeWidth 0", 150, 11),
            S("MeterMM", "--", 238, 29, 28, 300, ACC, "RightCenter", **dg),
            S("MeterColon", ":", 239, 26, 20, 300, ACC, **dg),
            S("MeterSS", "--", 251, 32, 16, 300, "#Accent#,200", **dg),
            SH("MeterDiv2", "Rectangle 0,0,1,34 | Fill Color #Faint# | StrokeWidth 0", 300, 11),
            SH("MeterStatusDot", "Ellipse 3.5,3.5,3.5 | Fill Color #Accent#,255 | StrokeWidth 0", 316, 14),
            S("MeterNextLabel", "NEXT UP", 330, 18, 7, 700, ACC, InlineSetting=LS),
            S("MeterNextName", "Loading...", 316, 35, 12, 600, W=280, H=20, ClipString=1),
            H("MeterCountdown")] + bar(316, 48, 280, 3, 1.5) + [
            SH("MeterDiv3", "Rectangle 0,0,1,34 | Fill Color #Faint# | StrokeWidth 0", 616, 11)]
    for i, y in enumerate((14, 28, 42), 1):
        main += [S(f"MeterUpT{i}", "", 632, y, 8.5, 400, ACC, **dg),
                 S(f"MeterUpN{i}", "", 694, y, 8, 400, "#RowText#", W=160, H=14, ClipString=1)]
    main += [S("MeterExpandBtn", "ALL  v", 946, 28, 8, 700, DIM, "RightCenter", **EXPAND)]
    portal = [SH("MeterCard", cardfill(0, 0, 700, 44), CardGrad=GRAD),
              S("MeterTitle", "PORTAL DATA", 14, 14, 8, 700, TXT, InlineSetting=LS),
              S("MeterStatus", "Loading...", 14, 31, 6.5, 500, DIM, W=124, H=12, ClipString=1)]
    for i, (n, lab) in enumerate((("Booking", "BOOKING"), ("Docket", "DOCKET"), ("Enquiry", "ENQUIRY"))):
        x = 158 + i * 128
        portal += [S(f"MeterLbl{n}", lab, x, 10, 6.5, 600, DIM),
                   S(f"MeterCnt{n}", "-", x, 28, 18, 300, ACC, **dg)]
    portal += [H("MeterBanner"),
               S("MeterBtnRun", "RUN NOW", 560, 14, 7.5, 700, ACC, **RUN),
               S("MeterBtnPass", "PASSWORD", 560, 31, 7.5, 700, DIM, **PASS),
               S("MeterBtnIdms", "IDMS v", 692, 22, 7.5, 700, ACC, "RightCenter", **IDMS)]
    net = [SH("MeterCard", cardfill(5, 5, 220, 46), CardGrad=GRAD, **NET_CARD)] + orb("none", 0, 0) + [
        SH("MeterStateDot", "Ellipse 4,4,3.5 | Fill Color #Accent#,255 | StrokeWidth 0", 13, 13),
        S("MeterState", "CHECKING", 26, 17, 8, 700, TXT, InlineSetting=LS),
        S("MeterTime", "", 14, 36, 6, 500, "#RowText#"), H("MeterStatusLbl"),
        S("MeterPingNum", "--", 150, 28, 20, 300, ACC, "RightCenter", **dg),
        S("MeterPingUnit", "ms", 153, 34, 7, 400, DIM, **dg),
        graph(170, 18, 34, 20), PIP, chevron(210, 25)]
    return dict(main=(dict(BarW=280, BarH=3, BarR=1.5, DotR=3.5), main), portal=({}, portal),
                net=(dict(OrbX=-50, OrbY=-50, PipX=214, PipY=42), net))


D["Digital"] = digital


# ---------------------------------------------------------------- Floating ---
def floating():
    sh = dict(InlineSetting=SHD)
    white, soft = "255,255,255,255", "255,255,255,215"
    main = [SH("MeterCard", "Rectangle 0,10,960,46 | Fill Color 0,0,0,1 | StrokeWidth 0", **MAIN_CARD),
            S("MeterTitle", "automation", 0, 20, 7.5, 600, soft, InlineSetting=SHD, InlineSetting2=LS),
            S("MeterSubtitle", "task scheduler", "10R", 20, 7.5, 400, soft, **sh),
            S("MeterNextLabel", "NEXT UP", "10R", 20, 7.5, 700, ACC, **sh),
            H("MeterStatusDot", "Shape"),
            S("MeterNextName", "Loading...", 0, 41, 16, 300, white, W=430, H=26, ClipString=1, **sh),
            S("MeterCountdown", "", 444, 41, 16, 600, ACC, **sh)] + bar(0, 54, 600, 1, 0, "255,255,255,80")
    for i, x in enumerate((640, 750, 860), 1):
        main += [S(f"MeterUpT{i}", "", x, 30, 7.5, 700, ACC, **sh),
                 S(f"MeterUpN{i}", "", x, 45, 8, 400, soft, W=100, H=14, ClipString=1, **sh)]
    main += [S("MeterExpandBtn", "all tasks >", 958, 20, 7.5, 700, soft, "RightCenter", **EXPAND, **sh)]
    portal = [SH("MeterCard", "Rectangle 0,4,700,40 | Fill Color 0,0,0,1 | StrokeWidth 0"),
              S("MeterTitle", "portal data", 0, 12, 7.5, 600, soft, **sh),
              S("MeterStatus", "Loading...", "10R", 12, 7, 400, soft, W=160, H=13, ClipString=1, **sh)]
    for i, (n, lab) in enumerate((("Booking", "booking"), ("Docket", "docket"), ("Enquiry", "enquiry"))):
        x = i * 130
        portal += [S(f"MeterLbl{n}", lab, x, 32, 7.5, 400, soft, **sh), S(f"MeterCnt{n}", "-", "6R", 32, 14, 300, white, **sh)]
    portal += [S("MeterBanner", "", 400, 12, 7, 600, "255,170,160,255", W=170, H=13, ClipString=1, **sh),
               S("MeterBtnRun", "run now", 430, 32, 7.5, 700, ACC, **RUN, **sh),
               S("MeterBtnPass", "password", 500, 32, 7.5, 600, soft, **PASS, **sh),
               S("MeterBtnIdms", "idms >", 698, 32, 7.5, 700, soft, "RightCenter", **IDMS, **sh)]
    net = [SH("MeterCard", "Rectangle 5,11,220,40 | Fill Color 0,0,0,1 | StrokeWidth 0", **NET_CARD)] + orb("core", 12, 38) + [
        S("MeterStatusLbl", "internet", 5, 20, 7, 400, soft, **sh),
        S("MeterTime", "", "8R", 20, 7, 400, soft, **sh),
        S("MeterState", "CHECKING", 24, 38, 12, 300, white, **sh),
        S("MeterPing", "", "8R", 38, 8, 600, ACC, **sh),
        graph(160, 30, 50, 16, "255,255,255,230"), PIP, chevron(214, 35, "255,255,255,220")]
    return dict(main=(dict(BarW=600, BarH=1, BarR=0), main), portal=({}, portal),
                net=(dict(OrbX=12, OrbY=38, PipX=154, PipY=38), net))


D["Floating"] = floating


# ------------------------------------------------------------------- Ivory ---
def ivory():
    y0 = 4
    main = [SH("MeterShadow", f"Rectangle 3,{y0 + 4},956,48,12 | Fill Color 40,25,10,45 | StrokeWidth 0"),
            SH("MeterCard", cardfill(0, y0, 958, 50), CardGrad=GRAD, **MAIN_CARD),
            SH("MeterTab", f"Rectangle 0,{y0 + 11},4,28,2 | Fill Color #Accent#,255 | StrokeWidth 0"),
            S("MeterTitle", "AUTOMATION", 18, y0 + 17, 8.5, 700, TXT, InlineSetting=LS),
            S("MeterSubtitle", "TASK SCHEDULER", 18, y0 + 34, 6.5, 600, DIM),
            S("MeterNextLabel", "NEXT UP", 176, y0 + 14, 7, 700, ACC, InlineSetting=LS),
            H("MeterStatusDot", "Shape"),
            S("MeterNextName", "Loading...", 176, y0 + 33, 12.5, 600, W=300, H=20, ClipString=1),
            S("MeterCountdown", "", 500, y0 + 14, 12, 400, ACC)] + bar(500, y0 + 27, 240, 3, 1.5, "#Faint#") + [
            S("MeterThen", "", 500, y0 + 40, 7.5, 400, DIM, W=240, H=14, ClipString=1)]
    for i, y in enumerate((y0 + 12, y0 + 25, y0 + 38), 1):
        main += [S(f"MeterUpT{i}", "", 766, y, 7, 700, ACC), S(f"MeterUpN{i}", "", 824, y, 7.5, 400, "#RowText#", W=86, H=13, ClipString=1)]
    main += [S("MeterExpandBtn", "ALL  v", 948, y0 + 25, 8, 700, DIM, "RightCenter", **EXPAND)]
    portal = [SH("MeterShadow", "Rectangle 3,4,696,40,11 | Fill Color 40,25,10,45 | StrokeWidth 0"),
              SH("MeterCard", cardfill(0, 0, 698, 42), CardGrad=GRAD),
              SH("MeterTab", "Rectangle 0,9,4,24,2 | Fill Color #Accent#,255 | StrokeWidth 0"),
              S("MeterTitle", "PORTAL DATA", 16, 13, 8.5, 700, TXT, InlineSetting=LS),
              S("MeterStatus", "Loading...", 16, 30, 6.5, 500, DIM, W=124, H=12, ClipString=1)]
    for i, (n, lab) in enumerate((("Booking", "BOOKING"), ("Docket", "DOCKET"), ("Enquiry", "ENQUIRY"))):
        x = 160 + i * 110
        portal += [S(f"MeterLbl{n}", lab, x, 11, 6.5, 600, DIM), S(f"MeterCnt{n}", "-", x, 28, 13, 600)]
    portal += [H("MeterBanner"),
               S("MeterBtnRun", "RUN NOW", 510, 13, 7.5, 700, ACC, **RUN),
               S("MeterBtnPass", "PASSWORD", 510, 30, 7.5, 700, DIM, **PASS),
               S("MeterBtnIdms", "IDMS v", 690, 21, 7.5, 700, ACC, "RightCenter", **IDMS)]
    net = [SH("MeterShadow", "Rectangle 8,9,218,44,11 | Fill Color 40,25,10,45 | StrokeWidth 0"),
           SH("MeterCard", cardfill(5, 5, 219, 45), CardGrad=GRAD, **NET_CARD),
           SH("MeterTab", "Rectangle 5,15,4,24,2 | Fill Color #Accent#,255 | StrokeWidth 0")] + orb("core", 26, 28) + [
        S("MeterState", "CHECKING", 42, 21, 9, 700, TXT, InlineSetting=LS),
        S("MeterPing", "", 42, 36, 6.5, 600, DIM), H("MeterStatusLbl"),
        graph(118, 18, 52, 18, "#Accent#,255"), S("MeterTime", "", 176, 28, 6, 500, "#RowText#"),
        PIP, chevron(209, 25, "#Text#,180")]
    return dict(main=(dict(BarW=240, BarH=3, BarR=1.5), main), portal=({}, portal),
                net=(dict(OrbX=26, OrbY=28, PipX=203, PipY=28), net))


D["Ivory"] = ivory


# ---------------------------------------------------------------- Timeline ---
def timeline():
    main = [SH("MeterCard", cardfill(0, 0, 960, 56), CardGrad=GRAD, **MAIN_CARD),
            S("MeterTitle", "AUTOMATION", 16, 16, 8, 700, TXT, InlineSetting=LS),
            S("MeterSubtitle", "TASK SCHEDULER", 16, 40, 6.5, 600, DIM),
            SH("MeterStatusDot", "Ellipse 3.5,3.5,3.5 | Fill Color #Accent#,255 | StrokeWidth 0", 150, 12),
            S("MeterNextName", "Loading...", 164, 16, 10, 600, W=300, H=18, ClipString=1),
            S("MeterNextLabel", "NEXT UP", "8R", 16, 6.5, 700, DIM, InlineSetting=LS),
            S("MeterCountdown", "", "6R", 16, 10, 700, ACC),
            SH("MeterAxis", "Rectangle 0,0,760,1 | Fill Color 255,255,255,40 | StrokeWidth 0", 150, 37),
            SH("MeterTkFill", "Rectangle 0,0,0,0 | StrokeWidth 0", 150, 36),
            SH("MeterNow", "Rectangle 0,0,2,11,1 | Fill Color #Text#,255 | StrokeWidth 0", 149, 32),
            H("MeterBarFill", "Shape"),
            H("MeterUpT1"), H("MeterUpN1"), H("MeterUpT2"), H("MeterUpN2"), H("MeterUpT3"), H("MeterUpN3")]
    for i in range(1, 5):
        if i == 1:
            main += [SH("MeterTk1", "Ellipse 4,4,3.5 | Fill Color #Accent#,255 | StrokeWidth 0", 150, 33),
                     S("MeterTkL1", "", 150, 48, 6.5, 700, ACC, "CenterCenter")]
        else:
            main += [SH(f"MeterTk{i}", "Rectangle 0,0,1,9 | Fill Color 255,255,255,120 | StrokeWidth 0", 150, 32),
                     S(f"MeterTkL{i}", "", 150, 48, 6.5, 400, DIM, "CenterCenter")]
    main += [S("MeterExpandBtn", "ALL  v", 948, 28, 8, 700, DIM, "RightCenter", **EXPAND)]
    portal = [SH("MeterCard", cardfill(0, 0, 700, 44), CardGrad=GRAD),
              S("MeterTitle", "PORTAL DATA", 14, 14, 8, 700, TXT, InlineSetting=LS),
              S("MeterStatus", "Loading...", 14, 31, 6.5, 500, DIM, W=124, H=12, ClipString=1)]
    for i, (n, lab) in enumerate((("Booking", "BOOKING"), ("Docket", "DOCKET"), ("Enquiry", "ENQUIRY"))):
        y = 9 + i * 13
        portal += [S(f"MeterLbl{n}", lab, 156, y, 6, 600, DIM),
                   SH(f"MeterCntTrack{n}", "Rectangle 0,0,240,4,2 | Fill Color 255,255,255,24 | StrokeWidth 0", 206, y - 2),
                   SH(f"MeterCntBar{n}", "Rectangle 0,0,0,0 | StrokeWidth 0", 206, y - 2),
                   S(f"MeterCnt{n}", "-", 454, y, 7.5, 700)]
    portal += [H("MeterBanner"),
               S("MeterBtnRun", "RUN NOW", 560, 14, 7.5, 700, ACC, **RUN),
               S("MeterBtnPass", "PASSWORD", 560, 31, 7.5, 700, DIM, **PASS),
               S("MeterBtnIdms", "IDMS v", 692, 22, 7.5, 700, ACC, "RightCenter", **IDMS)]
    net = [SH("MeterCard", cardfill(5, 5, 220, 46), CardGrad=GRAD, **NET_CARD)] + orb("none", 0, 0) + [
        SH("MeterStateDot", "Ellipse 4,4,3.5 | Fill Color #Accent#,255 | StrokeWidth 0", 13, 10),
        S("MeterState", "CHECKING", 26, 14, 8, 700, TXT, InlineSetting=LS),
        S("MeterPing", "", "8R", 14, 6.5, 600, ACC), H("MeterStatusLbl"),
        S("MeterTime", "", 204, 14, 6, 500, "#RowText#", "RightCenter"),
        SH("MeterAxisN", "Rectangle 14,45,190,1 | Fill Color 255,255,255,40 | StrokeWidth 0"),
        graph(14, 23, 190, 22), PIP, chevron(209, 11)]
    return dict(main=(dict(BarW=10, DotR=3.5, AxisX=150, AxisW=760), main),
                portal=(dict(CntBarW=240, CntBarH=4), portal),
                net=(dict(OrbX=-50, OrbY=-50, PipX=214, PipY=30), net))


D["Timeline"] = timeline


# ------------------------------------------------------------- StatusBlock ---
def statusblock():
    main = [SH("MeterCard", cardfill(0, 0, 960, 56), CardGrad=GRAD, **MAIN_CARD),
            SH("MeterBlk", "Rectangle 0,0,0,0 | StrokeWidth 0"),
            S("MeterBig", "OK", 36, 23, 15, 700, "#RunColor#,255", "CenterCenter"),
            S("MeterSm", "ALL OK", 36, 41, 5.5, 700, "#RunColor#,230", "CenterCenter", InlineSetting=LS),
            S("MeterTitle", "AUTOMATION", 86, 20, 8, 700, TXT, InlineSetting=LS),
            S("MeterSubtitle", "TASK SCHEDULER", 86, 37, 6.5, 600, DIM),
            SH("MeterDiv1", "Rectangle 0,0,1,30 | Fill Color #Faint# | StrokeWidth 0", 226, 13),
            SH("MeterStatusDot", "Ellipse 3.5,3.5,3.5 | Fill Color #Accent#,255 | StrokeWidth 0", 242, 16),
            S("MeterNextLabel", "NEXT UP", 256, 20, 7, 700, ACC, InlineSetting=LS),
            S("MeterNextName", "Loading...", 242, 37, 12, 600, W=330, H=20, ClipString=1),
            S("MeterCountdown", "", 704, 22, 13, 300, ACC, "RightCenter")] + bar(584, 38, 120, 3, 1.5) + [
            SH("MeterDiv2", "Rectangle 0,0,1,30 | Fill Color #Faint# | StrokeWidth 0", 718, 13)]
    for i, y in enumerate((14, 28, 42), 1):
        main += [S(f"MeterUpT{i}", "", 732, y, 7, 700, ACC), S(f"MeterUpN{i}", "", 786, y, 7.5, 400, "#RowText#", W=96, H=13, ClipString=1)]
    main += [S("MeterExpandBtn", "ALL  v", 948, 28, 8, 700, DIM, "RightCenter", **EXPAND)]
    portal = [SH("MeterCard", cardfill(0, 0, 700, 44), CardGrad=GRAD),
              SH("MeterStateBlk", "Rectangle 0,0,0,0 | StrokeWidth 0"),
              S("MeterStateTxt", "--", 28, 22, 9, 700, "255,255,255,255", "CenterCenter"),
              S("MeterTitle", "PORTAL DATA", 68, 14, 8, 700, TXT, InlineSetting=LS),
              S("MeterStatus", "Loading...", 68, 31, 6.5, 500, DIM, W=124, H=12, ClipString=1)]
    for i, (n, lab) in enumerate((("Booking", "BOOKING"), ("Docket", "DOCKET"), ("Enquiry", "ENQUIRY"))):
        x = 210 + i * 108
        portal += [S(f"MeterLbl{n}", lab, x, 12, 6.5, 600, DIM), S(f"MeterCnt{n}", "-", x, 29, 12, 700)]
    portal += [H("MeterBanner"),
               S("MeterBtnRun", "RUN NOW", 546, 14, 7.5, 700, ACC, **RUN),
               S("MeterBtnPass", "PASSWORD", 546, 31, 7.5, 700, DIM, **PASS),
               S("MeterBtnIdms", "IDMS v", 692, 22, 7.5, 700, ACC, "RightCenter", **IDMS)]
    net = [SH("MeterCard", cardfill(5, 5, 220, 46), CardGrad=GRAD, **NET_CARD),
           SH("MeterStateBlk", "Rectangle 0,0,0,0 | StrokeWidth 0")] + orb("none", 0, 0) + [
        S("MeterPingNum", "--", 30, 24, 11, 700, "255,255,255,255", "CenterCenter"),
        S("MeterPingUnit", "ms", 30, 38, 5.5, 700, "255,255,255,220", "CenterCenter"),
        S("MeterState", "CHECKING", 64, 21, 9, 700, TXT, InlineSetting=LS),
        S("MeterStatusLbl", "INTERNET", 64, 36, 5.5, 600, DIM, InlineSetting=LS),
        graph(120, 19, 42, 18), S("MeterTime", "", 168, 28, 6, 500, "#RowText#"),
        PIP, chevron(210, 25)]
    return dict(main=(dict(BarW=120, BarH=3, BarR=1.5, DotR=3.5, BlkW=70, BlkH=55, BlkR=12), main),
                portal=(dict(BlkW=56, BlkH=43, BlkR=10), portal),
                net=(dict(OrbX=-50, OrbY=-50, PipX=203, PipY=28, BlkX=5, BlkY=5, BlkW=50, BlkH=46, BlkR=10), net))


D["StatusBlock"] = statusblock


# -------------------------------------------------------------------- Neon ---
def neon():
    y0 = 4
    glow = "StrokeWidth 1.5 | Stroke LinearGradient StrokeGrad"
    sg = "0 | #Accent#,255 ; 0.0 | #AccentB#,255 ; 1.0"
    main = [SH("MeterGlow", f"Rectangle 0.5,{y0 + 0.5},959,51,14 | Fill Color 0,0,0,0 | StrokeWidth 6 | Stroke Color #Accent#,40"),
            SH("MeterCard", cardfill(0, y0, 960, 52, 14, stroke=glow), CardGrad=GRAD, StrokeGrad=sg, **MAIN_CARD),
            S("MeterTitle", "AUTOMATION", 22, y0 + 18, 7, 700, ACB, InlineSetting="CharacterSpacing | 1.2 | 1.2"),
            S("MeterSubtitle", "TASK SCHEDULER", 22, y0 + 35, 6.5, 600, DIM),
            SH("MeterSep1", "Rectangle 0,0,1.5,32,0.7 | Fill LinearGradient SepGrad | StrokeWidth 0", 170, y0 + 10, SepGrad="90 | #Accent#,0 ; 0.0 | #Accent#,255 ; 0.5 | #Accent#,0 ; 1.0"),
            H("MeterStatusDot", "Shape"),
            S("MeterNextLabel", "NEXT UP", 188, y0 + 16, 6.5, 700, ACB, InlineSetting="CharacterSpacing | 1 | 1"),
            S("MeterNextName", "Loading...", 188, y0 + 34, 12, 600, W=300, H=20, ClipString=1),
            S("MeterCountdown", "", 650, y0 + 22, 17, 300, ACC, "RightCenter")] + bar(510, y0 + 41, 140, 2, 1, "#Accent#,40") + [
            SH("MeterSep2", "Rectangle 0,0,1.5,32,0.7 | Fill LinearGradient SepGrad | StrokeWidth 0", 670, y0 + 10, SepGrad="90 | #Accent#,0 ; 0.0 | #Accent#,255 ; 0.5 | #Accent#,0 ; 1.0")]
    for i, y in enumerate((y0 + 13, y0 + 26, y0 + 39), 1):
        main += [S(f"MeterUpT{i}", "", 688, y, 7, 700, ACB), S(f"MeterUpN{i}", "", 742, y, 7.5, 400, "#RowText#", W=140, H=13, ClipString=1)]
    main += [S("MeterExpandBtn", "ALL  >", 946, y0 + 26, 8, 700, ACC, "RightCenter", **EXPAND)]
    portal = [SH("MeterGlow", "Rectangle 0.5,0.5,699,43,14 | Fill Color 0,0,0,0 | StrokeWidth 6 | Stroke Color #Accent#,40"),
              SH("MeterCard", cardfill(0, 0, 700, 44, 14, stroke=glow), CardGrad=GRAD, StrokeGrad=sg),
              S("MeterTitle", "PORTAL DATA", 18, 14, 7, 700, ACB, InlineSetting="CharacterSpacing | 1.2 | 1.2"),
              S("MeterStatus", "Loading...", 18, 30, 6.5, 500, DIM, W=124, H=12, ClipString=1)]
    for i, (n, lab) in enumerate((("Booking", "BOOKING"), ("Docket", "DOCKET"), ("Enquiry", "ENQUIRY"))):
        x = 162 + i * 118
        portal += [S(f"MeterLbl{n}", lab, x, 12, 6, 700, ACB, InlineSetting="CharacterSpacing | 1 | 1"),
                   S(f"MeterCnt{n}", "-", x, 29, 13, 300, ACC)]
    portal += [H("MeterBanner"),
               S("MeterBtnRun", "RUN", 528, 22, 8, 700, ACC, **RUN),
               S("MeterBtnPass", "PASSWORD", 566, 22, 7.5, 700, DIM, **PASS),
               S("MeterBtnIdms", "IDMS >", 688, 22, 8, 700, ACC, "RightCenter", **IDMS)]
    net = [SH("MeterGlow", "Rectangle 5.5,5.5,219,45,14 | Fill Color 0,0,0,0 | StrokeWidth 6 | Stroke Color #Accent#,40"),
           SH("MeterCard", cardfill(5, 5, 220, 46, 14, stroke=glow), CardGrad=GRAD, StrokeGrad=sg, **NET_CARD)] + orb("full", 29, 28) + [
        S("MeterState", "CHECKING", 52, 21, 9.5, 700, TXT, InlineSetting="CharacterSpacing | 0.8 | 0.8"),
        S("MeterStatusLbl", "STATUS", 53, 36, 5.5, 700, ACB, InlineSetting="CharacterSpacing | 1 | 1"),
        graph(118, 18, 50, 18, "#AccentB#,255"), S("MeterTime", "", 172, 28, 6, 500, "#RowText#"),
        PIP, chevron(209, 25, "#AccentB#,230")]
    return dict(main=(dict(BarW=140, BarH=2, BarR=1), main), portal=({}, portal),
                net=(dict(OrbX=29, OrbY=28, PipX=203, PipY=28), net))


D["Neon"] = neon


# ---------------------------------------------------------------- LiveTile ---
def livetile():
    white, soft = "255,255,255,255", "255,255,255,210"
    main = [SH("MeterCard", "Rectangle 0,0,960,56 | Fill Color 0,0,0,1 | StrokeWidth 0", **MAIN_CARD),
            SH("MeterTile", "Rectangle 0,0,140,56,2 | Fill Color #Accent#,240 | StrokeWidth 0", **MAIN_CARD),
            S("MeterTitle", "AUTOMATION", 10, 12, 6.5, 700, soft, InlineSetting=LS),
            S("MeterNextLabel", "NEXT UP", 10, 26, 7, 700, white, InlineSetting=LS),
            S("MeterCountdown", "", 10, 42, 12, 300, white),
            H("MeterStatusDot", "Shape")] + bar(0, 52, 140, 4, 0, "0,0,0,60") + [
            SH("MeterTileB", "Rectangle 144,0,340,56,2 | Fill Color #DCardBot# | StrokeWidth 0"),
            S("MeterNextName", "Loading...", 156, 22, 13, 600, W=316, H=22, ClipString=1),
            S("MeterSubtitle", "TASK SCHEDULER", 156, 42, 6.5, 700, DIM)]
    for i, x in enumerate((488, 612, 736), 1):
        main += [SH(f"MeterTileU{i}", f"Rectangle {x},0,120,56,2 | Fill Color #DCardTop# | StrokeWidth 0"),
                 S(f"MeterUpT{i}", "", x + 10, 14, 7, 700, ACC),
                 S(f"MeterUpN{i}", "", x + 10, 34, 8.5, 600, TXT, "LeftTop", W=104, H=16, ClipString=1)]
    main += [SH("MeterTileE", "Rectangle 860,0,100,56,2 | Fill Color #Accent#,90 | StrokeWidth 0", **EXPAND),
             S("MeterExpandBtn", "ALL TASKS", 910, 28, 7.5, 700, white, "CenterCenter", **EXPAND)]
    portal = [SH("MeterCard", "Rectangle 0,0,700,44 | Fill Color 0,0,0,1 | StrokeWidth 0"),
              SH("MeterTile", "Rectangle 0,0,120,44,2 | Fill Color #Accent#,240 | StrokeWidth 0"),
              S("MeterTitle", "PORTAL DATA", 9, 13, 7, 700, white, InlineSetting=LS),
              S("MeterStatus", "Loading...", 9, 31, 6.5, 500, soft, W=106, H=12, ClipString=1)]
    for i, (n, lab) in enumerate((("Booking", "BOOKING"), ("Docket", "DOCKET"), ("Enquiry", "ENQUIRY"))):
        x = 124 + i * 124
        portal += [SH(f"MeterTile{n}", f"Rectangle {x},0,120,44,2 | Fill Color #DCardBot# | StrokeWidth 0"),
                   S(f"MeterLbl{n}", lab, x + 9, 11, 6.5, 700, DIM), S(f"MeterCnt{n}", "-", x + 9, 29, 13, 600)]
    portal += [H("MeterBanner"),
               SH("MeterTileRun", "Rectangle 496,0,62,44,2 | Fill Color #Accent#,110 | StrokeWidth 0", **RUN),
               S("MeterBtnRun", "RUN", 527, 22, 8, 700, white, "CenterCenter", **RUN),
               SH("MeterTilePass", "Rectangle 562,0,70,44,2 | Fill Color #DCardTop# | StrokeWidth 0"),
               S("MeterBtnPass", "PASSWORD", 597, 22, 7, 700, TXT, "CenterCenter", **PASS),
               SH("MeterTileIdms", "Rectangle 636,0,64,44,2 | Fill Color #DCardTop# | StrokeWidth 0", **IDMS),
               S("MeterBtnIdms", "IDMS", 668, 22, 8, 700, ACC, "CenterCenter", **IDMS)]
    net = [SH("MeterCard", "Rectangle 5,5,220,46 | Fill Color 0,0,0,1 | StrokeWidth 0", **NET_CARD),
           SH("MeterTile", "Rectangle 5,5,220,46,2 | Fill Color 34,222,124,235 | StrokeWidth 0", **NET_CARD)] + orb("none", 0, 0) + [
        S("MeterStatusLbl", "INTERNET", 14, 16, 6, 700, soft, InlineSetting=LS),
        S("MeterState", "CHECKING", 14, 33, 11, 600, white),
        S("MeterPing", "", 214, 16, 7, 700, white, "RightCenter"),
        graph(130, 26, 60, 18, "255,255,255,230"), S("MeterTime", "", 214, 40, 6, 600, soft, "RightCenter"),
        PIP, SH("MeterChevron", "Rectangle 0,0,0,0 | StrokeWidth 0")]
    return dict(main=(dict(BarW=140, BarH=4, BarR=0, FixedTextColor=1, TileW=140, TileH=56, TileR=2), main),
                portal=(dict(FixedTextColor=1, TileW=120, TileH=44, TileR=2), portal),
                net=(dict(OrbX=-50, OrbY=-50, PipX=180, PipY=16, FixedTextColor=1, TileX=5, TileY=5, TileW=220, TileH=46, TileR=2), net))


D["LiveTile"] = livetile


# ------------------------------------------------------------- TaskbarChip ---
def taskbarchip():
    y0, cy = 28, 42
    main = [SH("MeterCard", cardfill(0, y0, 640, 28), CardGrad=GRAD, **MAIN_CARD),
            SH("MeterStatusDot", "Ellipse 3,3,3 | Fill Color #Accent#,255 | StrokeWidth 0", 11, cy - 3),
            H("MeterTitle"),
            S("MeterNextName", "Loading...", 24, cy, 8.5, 600, W=220, H=16, ClipString=1),
            S("MeterCountdown", "", "8R", cy, 8.5, 600, ACC),
            S("MeterSubtitle", "", 360, cy, 6.5, 700, DIM),
            H("MeterNextLabel"),
            S("MeterThenLbl", "then", 470, cy, 7, 400, DIM),
            S("MeterUpT1", "", "4R", cy, 7, 700, ACC), S("MeterUpN1", "", "4R", cy, 7.5, 400, "#RowText#", W=60, H=14, ClipString=1),
            H("MeterUpT2"), H("MeterUpN2"), H("MeterUpT3"), H("MeterUpN3"),
            S("MeterExpandBtn", "v", 630, cy, 8, 700, DIM, "RightCenter", **EXPAND)] + bar(8, y0 + 25, 624, 1, 0)
    portal = [SH("MeterCard", cardfill(0, 16, 540, 28), CardGrad=GRAD),
              S("MeterTitle", "PORTAL", 10, 30, 7, 700, TXT, InlineSetting=LS),
              S("MeterLblBooking", "B", 62, 30, 7, 700, DIM), S("MeterCntBooking", "-", "4R", 30, 8.5, 700),
              S("MeterLblDocket", "D", "12R", 30, 7, 700, DIM), S("MeterCntDocket", "-", "4R", 30, 8.5, 700),
              S("MeterLblEnquiry", "E", "12R", 30, 7, 700, DIM), S("MeterCntEnquiry", "-", "4R", 30, 8.5, 700),
              S("MeterStatus", "", 262, 30, 6.5, 500, DIM, W=140, H=12, ClipString=1),
              H("MeterBanner"),
              S("MeterBtnRun", "RUN", 414, 30, 7, 700, ACC, **RUN),
              S("MeterBtnPass", "PWD", 446, 30, 7, 700, DIM, **PASS),
              S("MeterBtnIdms", "IDMS v", 532, 30, 7, 700, ACC, "RightCenter", **IDMS)]
    ny0 = 25
    net = [SH("MeterCard", cardfill(5, ny0, 160, 26), CardGrad=GRAD, **NET_CARD)] + orb("none", 0, 0) + [
        SH("MeterStateDot", "Ellipse 4,4,3.5 | Fill Color #Accent#,255 | StrokeWidth 0", 13, ny0 + 9),
        S("MeterState", "CHECKING", 26, ny0 + 13, 7.5, 700, TXT),
        S("MeterPing", "", "6R", ny0 + 13, 7, 600, ACC), H("MeterStatusLbl"), H("MeterTime"),
        graph(118, ny0 + 5, 30, 16), PIP, chevron(152, ny0 + 11)]
    return dict(main=(dict(BarW=624, BarH=1, BarR=0, DotR=3), main), portal=({}, portal),
                net=(dict(OrbX=-50, OrbY=-50, PipX=112, PipY=ny0 + 13), net))


D["TaskbarChip"] = taskbarchip


# ---------------------------------------------------------------- MiniDash ---
def minidash():
    main = [SH("MeterCard", cardfill(0, 0, 960, 56), CardGrad=GRAD, **MAIN_CARD),
            S("MeterTitle", "AUTOMATION", 16, 13, 6.5, 700, DIM, InlineSetting=LS),
            S("MeterSubtitle", "TASK SCHEDULER", "10R", 13, 6.5, 700, DIM),
            S("MeterNextLabel", "NEXT UP", 476, 13, 6.5, 700, ACC, "RightCenter", InlineSetting=LS),
            SH("MeterStatusDot", "Ellipse 3.5,3.5,3.5 | Fill Color #Accent#,255 | StrokeWidth 0", 16, 28),
            S("MeterNextName", "Loading...", 30, 32, 11.5, 600, W=320, H=20, ClipString=1),
            S("MeterCountdown", "", 476, 32, 12, 300, ACC, "RightCenter"),
            H("MeterBarFill", "Shape")]
    main += [SH(f"MeterSeg{i}", "Rectangle 0,0,25,4,1 | Fill Color 255,255,255,24 | StrokeWidth 0", 16 + (i - 1) * 29, 45) for i in range(1, 17)]
    main += [SH("MeterDiv", "Rectangle 0,0,1,40 | Fill Color #Faint# | StrokeWidth 0", 494, 8)]
    for i, x in enumerate((510, 648, 786), 1):
        main += [S(f"MeterUpT{i}", "", x, 18, 7, 700, ACC), S(f"MeterUpN{i}", "", x, 37, 8, 400, "#RowText#", W=128, H=14, ClipString=1)]
    main += [S("MeterExpandBtn", "ALL  v", 946, 28, 8, 700, DIM, "RightCenter", **EXPAND)]
    portal = [SH("MeterCard", cardfill(0, 0, 700, 44), CardGrad=GRAD),
              S("MeterTitle", "PORTAL DATA", 14, 11, 6.5, 700, DIM, InlineSetting=LS),
              S("MeterStatus", "Loading...", "10R", 11, 6.5, 500, DIM, W=180, H=12, ClipString=1),
              S("MeterBtnRun", "RUN NOW", 520, 11, 7, 700, ACC, **RUN),
              S("MeterBtnPass", "PASSWORD", 574, 11, 7, 700, DIM, **PASS),
              S("MeterBtnIdms", "IDMS v", 690, 11, 7, 700, ACC, "RightCenter", **IDMS)]
    for i, (n, lab) in enumerate((("Booking", "BOOKING"), ("Docket", "DOCKET"), ("Enquiry", "ENQUIRY"))):
        x = 14 + i * 160
        portal += [S(f"MeterLbl{n}", lab, x, 28, 6.5, 700, ACC), S(f"MeterCnt{n}", "-", x + 150, 28, 11, 600, TXT, "RightCenter"),
                   SH(f"MeterCntTrack{n}", "Rectangle 0,0,150,3,1.5 | Fill Color 255,255,255,24 | StrokeWidth 0", x, 37),
                   SH(f"MeterCntBar{n}", "Rectangle 0,0,0,0 | StrokeWidth 0", x, 37)]
    portal += [S("MeterBanner", "", 500, 30, 6.5, 600, RED, W=190, H=12, ClipString=1)]
    net = [SH("MeterCard", cardfill(5, 5, 220, 46), CardGrad=GRAD, **NET_CARD)] + orb("none", 0, 0) + [
        S("MeterStatusLbl", "NETWORK", 14, 13, 6, 700, DIM, InlineSetting=LS),
        S("MeterTime", "", 212, 13, 6, 500, "#RowText#", "RightCenter"),
        SH("MeterStateDot", "Ellipse 4,4,3.5 | Fill Color #Accent#,255 | StrokeWidth 0", 13, 28),
        S("MeterState", "CHECKING", 26, 32, 9.5, 700, TXT),
        S("MeterPing", "", 110, 32, 8, 300, ACC),
        graph(150, 24, 60, 17), PIP, SH("MeterChevron", "Rectangle 0,0,0,0 | StrokeWidth 0"),
        SH("MeterNetLine", "Rectangle 14,45,198,1 | Fill Color 255,255,255,18 | StrokeWidth 0")]
    return dict(main=(dict(BarW=10, DotR=3.5, SegN=16, SegW=25, SegH=4), main),
                portal=(dict(CntBarW=150, CntBarH=3), portal),
                net=(dict(OrbX=-50, OrbY=-50, PipX=216, PipY=32), net))


D["MiniDash"] = minidash


# ================================================================== writer ===
def check(name, meters, req):
    have = {n for n, _ in meters}
    missing = [r for r in req if r not in have]
    assert not missing, f"{name}: missing {missing}"
    dup = [n for n in have if sum(1 for m, _ in meters if m == n) > 1]
    assert not dup, f"{name}: duplicate {dup}"


def write(skin, design, variables, meters, req):
    check(f"{skin}/{design}", meters, req)
    L = [f"; {skin} bar - {design} design. GENERATED by @Resources\\Bars\\_make_bars.py",
         "; (edit that and re-run). Loaded via @IncludeBar in [Variables]; its own",
         "; [Variables] block merges into the skin's, the sections after it are the",
         "; bar's meters. Meter NAMES are fixed - the engine fills them by name."]
    L += ["[Variables]"] + [f"{k}={v}" for k, v in variables.items()] + [""]
    for n, d in meters:
        L.append(f"[{n}]")
        L += [f"{k}={v}" for k, v in d.items()]
        L.append("")
    os.makedirs(os.path.join(HERE, skin), exist_ok=True)
    with open(os.path.join(HERE, skin, design + ".inc"), "w", encoding="utf-8", newline="\r\n") as f:
        f.write("\n".join(L) + "\n")


for design, fn in D.items():
    parts = fn()
    write("Main", design, *parts["main"], REQ_MAIN)
    write("Portal", design, *parts["portal"], REQ_PORTAL)
    write("Net", design, *parts["net"], REQ_NET)
    print(f"{design:12} main {len(parts['main'][1]):2}  portal {len(parts['portal'][1]):2}  net {len(parts['net'][1]):2}")
