"""Writes @Resources\\Designs\\<Name>.inc (one per design) and @Resources\\Common.inc.

A DESIGN is the shape/type treatment every skin uses; a THEME is the colours.
Big skins (main bar, PORTAL DATA/IDMS, NetWatch) take Font, corner radius,
border and fill from the design. The compact MAIN AUTOMATION SYSTEM bar also
swaps to the design's own layout file (CompactIni).
"""
import os

RES = r"C:\Users\Dell\Documents\Rainmeter\Skins\AutomationReminder\@Resources"

TH = dict(DCardTop="#CardTop#", DCardBot="#CardBot#", DPanelTop="#PanelTop#", DPanelBot="#PanelBot#")
NOGLOSS = dict(DGlossA="0,0,0,0", DGlossB="0,0,0,0")
GLOSS = dict(DGlossA="#GlossA#", DGlossB="#GlossB#")

# name, compact ini, one-line description, overrides
DESIGNS = [
    ("Classic", "MainSystem.ini", "The original look: rounded glass card with a soft top sheen",
     dict(Font="Segoe UI", CardR=16, PanelR=16, CardStrokeW=1, CardStrokeC="#Stroke#", PanelStrokeW=1, PanelStrokeC="#PanelStroke#", **TH, **GLOSS)),
    ("Hairline", "MainSystem.ini", "Slim and flat - tight corners, no sheen, thin progress line",
     dict(Font="Segoe UI", CardR=10, PanelR=10, CardStrokeW=1, CardStrokeC="#Stroke#", PanelStrokeW=1, PanelStrokeC="#PanelStroke#", **TH, **NOGLOSS)),
    ("Capsule", "Capsule.ini", "Pill-shaped bars with a light glass edge",
     dict(Font="Segoe UI", CardR=99, PanelR=22, CardStrokeW=1, CardStrokeC="255,255,255,70", PanelStrokeW=1, PanelStrokeC="255,255,255,50", **TH, **GLOSS)),
    ("Ticker", "Ticker.ini", "Next task on top, the queue rotating underneath",
     dict(Font="Segoe UI", CardR=12, PanelR=12, CardStrokeW=1, CardStrokeC="#Stroke#", PanelStrokeW=1, PanelStrokeC="#PanelStroke#", **TH, **NOGLOSS)),
    ("Ring", "Ring.ini", "Round timer - the ring fills as the next run gets closer",
     dict(Font="Segoe UI", CardR=20, PanelR=18, CardStrokeW=1.5, CardStrokeC="#Accent#,90", PanelStrokeW=1.5, PanelStrokeC="#Accent#,60", **TH, **GLOSS)),
    ("Queue", "Queue.ini", "Narrow card with the queue as a vertical timeline",
     dict(Font="Segoe UI", CardR=14, PanelR=14, CardStrokeW=1, CardStrokeC="#Stroke#", PanelStrokeW=1, PanelStrokeC="#PanelStroke#", **TH, **NOGLOSS)),
    ("Console", "Console.ini", "Terminal readout in Consolas, square corners",
     dict(Font="Consolas", CardR=4, PanelR=4, CardStrokeW=1, CardStrokeC="#Accent#,80", PanelStrokeW=1, PanelStrokeC="#Accent#,60",
          DCardTop="#CardBot#", DCardBot="#CardBot#", DPanelTop="#PanelBot#", DPanelBot="#PanelBot#", **NOGLOSS)),
    ("Digital", "Digital.ini", "Big condensed clock digits in Bahnschrift",
     dict(Font="Bahnschrift", CardR=12, PanelR=12, CardStrokeW=1, CardStrokeC="#Stroke#", PanelStrokeW=1, PanelStrokeC="#PanelStroke#", **TH, **GLOSS)),
    ("Floating", "Floating.ini", "Almost no card - text floats on the wallpaper",
     dict(Font="Segoe UI", CardR=12, PanelR=14, CardStrokeW=0, CardStrokeC="0,0,0,0", PanelStrokeW=0, PanelStrokeC="0,0,0,0",
          DCardTop="0,0,0,50", DCardBot="0,0,0,85", DPanelTop="0,0,0,150", DPanelBot="0,0,0,180", **NOGLOSS)),
    ("Ivory", "Ivory.ini", "Paper card with a firm edge - pair it with the Ivory theme",
     dict(Font="Segoe UI", CardR=12, PanelR=12, CardStrokeW=1.5, CardStrokeC="#Stroke#", PanelStrokeW=1.5, PanelStrokeC="#PanelStroke#", **TH, **NOGLOSS)),
    ("Timeline", "Timeline.ini", "Upcoming tasks placed to scale on a time axis",
     dict(Font="Segoe UI", CardR=12, PanelR=12, CardStrokeW=1, CardStrokeC="#Accent#,70", PanelStrokeW=1, PanelStrokeC="#Accent#,50", **TH, **NOGLOSS)),
    ("StatusBlock", "StatusBlock.ini", "Health first - a solid block shows failures at a glance",
     dict(Font="Segoe UI", CardR=12, PanelR=12, CardStrokeW=1, CardStrokeC="#Stroke#", PanelStrokeW=1, PanelStrokeC="#PanelStroke#", **TH, **NOGLOSS)),
    ("Neon", "Neon.ini", "Glowing accent outline over a dark see-through fill",
     dict(Font="Segoe UI", CardR=14, PanelR=16, CardStrokeW=1.5, CardStrokeC="#Accent#,230", PanelStrokeW=1.5, PanelStrokeC="#Accent#,200",
          DCardTop="12,10,26,160", DCardBot="12,10,26,200", DPanelTop="12,10,26,215", DPanelBot="12,10,26,235", **NOGLOSS)),
    ("LiveTile", "LiveTile.ini", "Flat Windows-tile style with square corners",
     dict(Font="Segoe UI", CardR=3, PanelR=3, CardStrokeW=0, CardStrokeC="0,0,0,0", PanelStrokeW=0, PanelStrokeC="0,0,0,0",
          DCardTop="#CardBot#", DCardBot="#CardBot#", DPanelTop="#PanelBot#", DPanelBot="#PanelBot#", **NOGLOSS)),
    ("TaskbarChip", "TaskbarChip.ini", "The smallest - a chip that sits just above the taskbar",
     dict(Font="Segoe UI", CardR=8, PanelR=10, CardStrokeW=1, CardStrokeC="255,255,255,26", PanelStrokeW=1, PanelStrokeC="255,255,255,22", **TH, **NOGLOSS)),
    ("MiniDash", "MiniDash.ini", "Everything packed into a small graphite block",
     dict(Font="Segoe UI", CardR=14, PanelR=14, CardStrokeW=1, CardStrokeC="255,255,255,22", PanelStrokeW=1, PanelStrokeC="255,255,255,18", **TH, **NOGLOSS)),
]

LABEL = {"StatusBlock": "Status Block", "LiveTile": "Live Tile", "TaskbarChip": "Taskbar Chip", "MiniDash": "Mini Dash"}

# ---------------------------------------------------------------------------
# EXACT palettes from the design gallery (Designs.html). Picking a design also
# switches THEME to its palette; the THEME dots can still change it afterwards,
# and MATCH puts the design's own palette back. Classic/Hairline/StatusBlock use
# the existing Ember theme, which already matches the gallery exactly.
# Dim/Text/Accent*/Run/Soon are R,G,B (skins append their own alpha).
PAL_KEYS = ["Accent", "AccentB", "RunColor", "SoonColor", "Text", "Dim", "Faint", "RowText", "Stroke",
            "CardTop", "CardBot", "GlossA", "GlossB", "PanelTop", "PanelBot", "PanelStroke"]
PALETTES = {
    "Pearl":    ("Capsule - frosted white glass, peach accent",
                 ["255,217,174", "255,236,214", "159,240,192", "255,190,150", "255,255,255", "235,228,240", "255,255,255,26", "250,248,252,235", "255,255,255,72",
                  "255,255,255,36", "255,255,255,36", "255,255,255,30", "255,255,255,0", "44,36,62,215", "30,26,44,230", "255,255,255,50"]),
    "Navy":     ("Ticker - deep navy, sky-blue accent",
                 ["90,169,255", "127,224,255", "94,224,168", "255,170,90", "230,238,252", "125,141,176", "255,255,255,20", "185,198,226,230", "120,170,255,51",
                  "18,28,50,230", "8,12,24,240", "140,180,255,20", "140,180,255,0", "16,25,46,240", "8,12,24,246", "120,170,255,40"]),
    "Violet":   ("Ring - violet to teal",
                 ["168,130,255", "90,220,210", "90,220,180", "255,150,120", "236,234,248", "170,165,200", "255,255,255,20", "220,218,240,225", "190,170,255,46",
                  "28,22,48,235", "14,11,26,242", "200,190,255,22", "200,190,255,0", "26,21,45,240", "14,11,26,246", "190,170,255,36"]),
    "Jade":     ("Queue - deep jade green",
                 ["52,195,143", "168,230,197", "127,227,255", "255,170,90", "230,244,236", "150,185,170", "255,255,255,20", "199,220,209,230", "120,220,170,46",
                  "14,38,30,230", "6,20,16,240", "140,230,190,18", "140,230,190,0", "12,34,27,240", "6,20,16,246", "120,220,170,36"]),
    "Amber":    ("Console - amber phosphor on black",
                 ["255,176,0", "255,204,102", "255,212,102", "255,122,92", "201,154,69", "138,106,46", "255,176,0,24", "214,170,90,235", "255,176,0,56",
                  "14,10,4,240", "14,10,4,240", "255,176,0,0", "255,176,0,0", "14,10,4,244", "10,7,3,248", "255,176,0,50"]),
    "Dusk":     ("Digital - sunset gold and coral",
                 ["255,179,71", "255,122,89", "126,224,160", "255,122,89", "251,238,224", "200,170,150", "255,230,210,20", "240,225,210,225", "255,190,120,51",
                  "46,30,22,225", "24,15,10,237", "255,200,150,22", "255,200,150,0", "44,29,21,240", "22,14,9,246", "255,190,120,36"]),
    "Snow":     ("Floating - white text over the wallpaper",
                 ["255,255,255", "215,215,220", "182,245,207", "255,200,150", "255,255,255", "225,225,230", "255,255,255,40", "250,250,252,240", "255,255,255,40",
                  "0,0,0,50", "0,0,0,85", "255,255,255,0", "255,255,255,0", "0,0,0,150", "0,0,0,180", "255,255,255,30"]),
    "Paper":    ("Ivory - warm paper, brick-red accent",
                 ["200,65,47", "176,120,60", "47,143,91", "214,120,40", "42,35,32", "122,108,98", "60,40,20,26", "62,52,48,235", "60,40,20,31",
                  "252,249,243,245", "246,241,232,245", "255,255,255,40", "255,255,255,0", "250,247,240,248", "244,238,228,250", "60,40,20,36"]),
    "Cyan":     ("Timeline - night blue, cyan accent",
                 ["79,209,255", "150,230,255", "94,224,168", "255,170,90", "228,238,250", "142,163,194", "255,255,255,20", "200,215,235,230", "100,180,255,46",
                  "14,24,42,230", "6,12,24,240", "120,190,255,18", "120,190,255,0", "12,22,40,240", "6,12,24,246", "100,180,255,36"]),
    "Neon":     ("Neon - violet/teal glow on dark glass",
                 ["168,130,255", "90,220,210", "90,220,180", "255,160,180", "240,238,252", "175,170,210", "255,255,255,20", "225,222,245,230", "168,130,255,90",
                  "12,10,26,184", "12,10,26,200", "0,0,0,0", "0,0,0,0", "12,10,26,215", "12,10,26,235", "168,130,255,70"]),
    "Crimson":  ("Live Tile - flat crimson",
                 ["198,47,40", "255,160,140", "46,143,87", "255,170,90", "250,240,238", "200,160,155", "255,255,255,20", "240,225,222,225", "255,110,100,40",
                  "40,12,12,230", "22,6,6,240", "255,140,130,20", "255,140,130,0", "38,11,11,240", "20,6,6,246", "255,110,100,32"]),
    "Slate":    ("Taskbar Chip - dark slate, orange accent",
                 ["255,138,92", "255,180,140", "110,205,140", "255,190,90", "241,241,244", "165,165,175", "255,255,255,20", "225,225,232,225", "255,255,255,26",
                  "30,30,36,224", "30,30,36,224", "255,255,255,14", "255,255,255,0", "30,30,36,238", "24,24,30,244", "255,255,255,22"]),
    "Graphite": ("Mini Dash - graphite, orange accent",
                 ["255,122,69", "255,170,120", "94,224,168", "255,190,90", "236,238,242", "138,144,155", "255,255,255,20", "185,190,200,235", "255,255,255,20",
                  "32,35,41,235", "18,20,24,242", "255,255,255,12", "255,255,255,0", "30,33,39,240", "18,20,24,246", "255,255,255,18"]),
}
DESIGN_THEME = {"Classic": "Ember", "Hairline": "Ember", "Capsule": "Pearl", "Ticker": "Navy", "Ring": "Violet",
                "Queue": "Jade", "Console": "Amber", "Digital": "Dusk", "Floating": "Snow", "Ivory": "Paper",
                "Timeline": "Cyan", "StatusBlock": "Ember", "Neon": "Neon", "LiveTile": "Crimson",
                "TaskbarChip": "Slate", "MiniDash": "Graphite"}

for pname, (desc, vals) in PALETTES.items():
    assert len(vals) == len(PAL_KEYS), pname
    body = [f"; {pname} - {desc}. Exact colours from the design gallery.",
            "; Generated by Designs\\_make_designs.py (re-running it overwrites this file).", "[Variables]"]
    body += [f"{k}={v}" for k, v in zip(PAL_KEYS, vals)]
    with open(os.path.join(RES, "Themes", pname + ".inc"), "w", encoding="ascii", newline="\r\n") as f:
        f.write("\n".join(body) + "\n")
print("wrote", len(PALETTES), "design palettes")

os.makedirs(os.path.join(RES, "Designs"), exist_ok=True)
n = len(DESIGNS)
for i, (name, ini, info, v) in enumerate(DESIGNS):
    prev_name = DESIGNS[(i - 1) % n][0]
    next_name = DESIGNS[(i + 1) % n][0]
    lines = [
        f"; DESIGN {i:02d} - {LABEL.get(name, name)}: {info}.",
        "; Generated by make_designs.py - the shape/type treatment every skin uses.",
        "; Colours come from the THEME; *Top/*Bot values of #CardTop# etc. mean",
        "; 'use the theme's colour'. CardR is clamped by each skin to half its height.",
        "[Variables]",
        f"Design={name}",
        f"DesignLabel={LABEL.get(name, name).upper()}",
        f"DesignNum={i:02d}",
        f"DesignInfo={info}",
        f"DesignPrev={prev_name}",
        f"DesignNext={next_name}",
        f"CompactIni={ini}",
        f"DesignTheme={DESIGN_THEME[name]}",
        f"DesignPrevTheme={DESIGN_THEME[prev_name]}",
        f"DesignNextTheme={DESIGN_THEME[next_name]}",
    ] + [f"{k}={val}" for k, val in v.items()]
    with open(os.path.join(RES, "Designs", name + ".inc"), "w", encoding="ascii", newline="\r\n") as f:
        f.write("\n".join(lines) + "\n")

common = r"""; Shared by every AutomationReminder skin. Static - never rewritten.
[Variables]
; Refreshes every LOADED skin in the family after a THEME or DESIGN change (all
; four skins declare Group=AutomationReminder in [Rainmeter]; skins that aren't
; loaded on this PC are simply skipped - no log warnings).
RefreshAll=[!RefreshGroup AutomationReminder]
DesignGallery=#@#Designs\Designs.html
"""
with open(os.path.join(RES, "Common.inc"), "w", encoding="ascii", newline="\r\n") as f:
    f.write(common)
print("wrote", n, "designs + Common.inc")
print("order:", " > ".join(d[0] for d in DESIGNS))
