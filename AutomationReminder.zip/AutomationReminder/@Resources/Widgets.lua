-- ============================================================================
--  Widgets.lua  -  optional bar pieces shared by the AutomationReminder engines
-- ----------------------------------------------------------------------------
--  Loaded with dofile() from AutomationTasks.lua (main bar), DownloadEngine.lua
--  (PORTAL DATA) and NetWatchEngine.lua. Each DESIGN's bar file
--  (@Resources\Bars\<Skin>\<Design>.inc) is free to include any of the meters
--  below; the engines only fill the ones that exist, so a design is just a
--  choice of pieces and positions.
--
--    W.set / W.show   !SetOption / !Show|HideMeter, silently skipping meters
--                     the loaded design doesn't have (no log spam)
--    W.arc            ring-progress Shape string (clockwise from 12 o'clock)
--    W.schedule       main-bar extras: ring, big digits, segments, terminal
--                     lines, ticker, timeline, status block, tile colour
-- ============================================================================

local W = {}
local cache = {}

function W.has(m)
  if cache[m] == nil then cache[m] = (SKIN:GetMeter(m) ~= nil) end
  return cache[m]
end
function W.set(m, o, v) if W.has(m) then SKIN:Bang('!SetOption', m, o, v) end end
function W.show(m, on) if W.has(m) then SKIN:Bang(on and '!ShowMeter' or '!HideMeter', m) end end
function W.var(n, fb)
  local v = SKIN:GetVariable(n)
  if v == nil or v == '' then return fb end
  return v
end
function W.num(n, fb) return tonumber(W.var(n, '')) or fb end

function W.arc(frac, color, cx, cy, r, sw)
  local style = ' | StrokeWidth ' .. sw .. ' | Stroke Color ' .. color .. ',255 | StrokeStartCap Round | StrokeEndCap Round | Fill Color 0,0,0,0'
  if frac <= 0.004 then return 'Rectangle 0,0,0,0 | StrokeWidth 0' end
  if frac >= 0.996 then return string.format('Ellipse %.1f,%.1f,%.1f', cx, cy, r) .. style end
  local a = -math.pi / 2 + frac * 2 * math.pi
  return string.format('Arc %.1f,%.1f,%.2f,%.2f,%.1f,%.1f,0,0,%d', cx, cy - r,
    cx + r * math.cos(a), cy + r * math.sin(a), r, r, frac > 0.5 and 1 or 0) .. style
end

local function fmtClock(tt) return (os.date("%I:%M %p", tt):gsub("^0", "")) end
local function fmtShort(tt) return (os.date("%I:%M", tt):gsub("^0", "")) end

-- st = { state='next'|'run'|'sync', secs, frac, color, fails, after={...},
--        queue={...}, tick, now, dim, runc, failc, accent }
function W.schedule(st)
  local color, secs, frac = st.color, math.max(0, st.secs or 0), st.frac or 0

  -- ring gauge ---------------------------------------------------------------
  if W.has('MeterArc') then
    W.set('MeterArc', 'Shape', W.arc(frac, color, W.num('RingCX', 28), W.num('RingCY', 28), W.num('RingR', 22), W.num('RingSW', 4)))
  end

  -- big digits: mm:ss under an hour, then h:mm ---------------------------------
  local a, b, hrs
  if st.state == 'sync' then a, b, hrs = '--', '--', false
  elseif secs >= 3600 then a, b, hrs = tostring(math.floor(secs / 3600)), string.format('%02d', math.floor((secs % 3600) / 60)), true
  else a, b, hrs = string.format('%02d', math.floor(secs / 60)), string.format('%02d', secs % 60), false end
  W.set('MeterClock', 'Text', a .. (hrs and 'h' or ':') .. b)
  W.set('MeterClock', 'FontColor', color .. ',255')
  W.set('MeterMM', 'Text', a)
  W.set('MeterMM', 'FontColor', color .. ',255')
  W.set('MeterSS', 'Text', b)
  W.set('MeterSS', 'FontColor', color .. ',200')
  W.set('MeterColon', 'Text', hrs and 'h' or ':')
  W.set('MeterColon', 'FontColor', color .. ',' .. ((st.tick % 2 == 0 or hrs) and '255' or '60'))

  -- terminal pieces --------------------------------------------------------------
  W.set('MeterHMS', 'Text', st.state == 'sync' and '--:--:--' or
    string.format('%02d:%02d:%02d', math.floor(secs / 3600), math.floor((secs % 3600) / 60), secs % 60))
  local f10 = math.floor(frac * 10 + 0.5)
  W.set('MeterAscii', 'Text', '[' .. string.rep('#', f10) .. string.rep('-', 10 - f10) .. ']')
  W.set('MeterCursor', 'FontColor', color .. ',' .. (st.tick % 2 == 0 and '255' or '0'))
  local t1 = st.after and st.after[1]
  if W.has('MeterConsole3') then
    if st.fails > 0 then
      W.set('MeterConsole3', 'Text', '!! ' .. st.fails .. (st.fails == 1 and ' task' or ' tasks') .. ' failed - open ALL TASKS')
      W.set('MeterConsole3', 'FontColor', st.failc .. ',255')
    else
      W.set('MeterConsole3', 'Text', t1 and ('then ' .. os.date('%H:%M', t1.t) .. ' ' .. t1.name:lower():gsub(' ', '_')) or 'queue empty')
      W.set('MeterConsole3', 'FontColor', st.dim .. ',255')
    end
  end

  -- segments ----------------------------------------------------------------------
  if W.has('MeterSeg1') then
    local n = W.num('SegN', 12)
    local on = math.floor(frac * n + 0.5)
    for i = 1, n do
      W.set('MeterSeg' .. i, 'Shape', 'Rectangle 0,0,' .. W.num('SegW', 20) .. ',' .. W.num('SegH', 4) .. ',1 | Fill Color ' ..
        (i <= on and (color .. ',255') or '255,255,255,24') .. ' | StrokeWidth 0')
    end
  end

  -- status block: failure count, or OK ----------------------------------------------
  if W.has('MeterBlk') then
    local bad = st.fails > 0
    W.set('MeterBlk', 'Shape', 'Rectangle 0.5,' .. W.num('BlkY', 0.5) .. ',' .. W.num('BlkW', 64) .. ',' .. W.num('BlkH', 55) .. ',' .. W.num('BlkR', 12) ..
      ' | Fill Color ' .. (bad and '205,52,42,255' or (st.runc .. ',45')) .. ' | StrokeWidth 0')
    W.set('MeterBig', 'Text', bad and tostring(st.fails) or 'OK')
    W.set('MeterBig', 'FontColor', bad and '255,255,255,255' or (st.runc .. ',255'))
    W.set('MeterSm', 'Text', bad and 'FAILED' or 'ALL OK')
    W.set('MeterSm', 'FontColor', bad and '255,255,255,230' or (st.runc .. ',230'))
  end

  -- queue text: rotating ticker + "then" line ----------------------------------------
  if W.has('MeterTicker') then
    local n = st.after and #st.after or 0
    if n > 0 then
      local q = st.after[(math.floor(st.tick / 3) % n) + 1]
      W.set('MeterTicker', 'Text', fmtClock(q.t) .. '   ' .. q.name)
    else
      W.set('MeterTicker', 'Text', 'Nothing else scheduled')
    end
  end
  W.set('MeterThen', 'Text', t1 and ('Then ' .. t1.name .. ' at ' .. fmtClock(t1.t)) or 'Nothing else scheduled')

  -- timeline: next four runs placed to scale from now ----------------------------------
  if W.has('MeterTk1') then
    local ax, aw = W.num('AxisX', 16), W.num('AxisW', 368)
    local pts = {}
    for i = 1, 4 do if st.queue[i] then pts[#pts + 1] = st.queue[i] end end
    local span = 1800
    if #pts > 0 then span = math.max(1800, pts[#pts].t - st.now + 300) end
    local heroX, lastLblX = ax, -1000
    for i = 1, 4 do
      local q = pts[i]
      if q then
        local x = ax + math.floor((q.t - st.now) / span * aw)
        if i == 1 then heroX = x end
        W.set('MeterTk' .. i, 'X', tostring(x - (i == 1 and 4 or 0)))
        W.set('MeterTkL' .. i, 'X', tostring(x))
        W.set('MeterTkL' .. i, 'Text', fmtShort(q.t))
        W.set('MeterTk' .. i, 'ToolTipText', q.name .. '  ' .. fmtClock(q.t))
        W.show('MeterTk' .. i, true)
        local roomy = (x - lastLblX) >= 30
        W.show('MeterTkL' .. i, roomy)
        if roomy then lastLblX = x end
      else
        W.show('MeterTk' .. i, false); W.show('MeterTkL' .. i, false)
      end
    end
    local fw = math.floor((heroX - ax) * frac)
    W.set('MeterTkFill', 'Shape', fw < 2 and 'Rectangle 0,0,0,0 | StrokeWidth 0' or
      ('Rectangle 0,0,' .. fw .. ',3,1.5 | Fill Color ' .. color .. ',255 | StrokeWidth 0'))
  end

  -- live tile: the state tile takes the state colour -----------------------------------
  if W.has('MeterTile') then
    W.set('MeterTile', 'Shape', 'Rectangle 0,0,' .. W.num('TileW', 140) .. ',' .. W.num('TileH', 56) .. ',' .. W.num('TileR', 2) ..
      ' | Fill Color ' .. (st.state == 'run' and st.runc or (st.state == 'sync' and '70,70,78' or st.accent)) .. ',240 | StrokeWidth 0')
  end
end

return W
