import sys, re, time
sys.path.insert(0, r"e:\ibnd\AutomationReminder\Downloads")
import IdmsDownload as idms

def main():
    user, pw = idms.read_creds()
    from playwright.sync_api import sync_playwright
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=True)
        ctx = browser.new_context(accept_downloads=True)
        page = ctx.new_page()
        page.goto(idms.LOGIN_URL, timeout=30000)
        idms.try_fill(page, idms.SEL_USER, user)
        idms.try_fill(page, idms.SEL_PASS, pw)
        page.click(idms.SEL_LOGIN, timeout=8000)
        page.wait_for_load_state("networkidle", timeout=20000)
        if idms.LOGIN_MARKER in page.url.lower():
            print("LOGIN FAILED, url:", page.url)
            print(page.locator("body").inner_text()[:800])
            return

        cfg = idms.REPORTS["booking"]
        idms.goto_report(page, cfg)
        idms.try_fill(page, cfg["df"], "2015-01-01")
        idms.try_fill(page, cfg["dt"], "2026-07-24")
        idms.click_text(page, cfg["filt"], timeout=6000)
        rows = page.locator("table tbody tr")
        t0 = time.time()
        for _ in range(60):
            page.wait_for_timeout(1000)
            c = rows.count()
            t = rows.first.inner_text()[:40] if c else ""
            if c and "loading" not in t.lower():
                break
        elapsed = time.time() - t0
        print(f"booking wide-range load: {elapsed:.1f}s, rows={rows.count()}")

        # bulk-extract via JS instead of per-row Playwright calls (much faster)
        texts = page.eval_on_selector_all("table tbody tr", "els => els.map(e => e.innerText)")
        dates = []
        pat = re.compile(r"\b(20\d{2}-\d{2}-\d{2})\b")
        for t in texts:
            dates.extend(pat.findall(t))
        if dates:
            print("min date found:", min(dates), " max date found:", max(dates))
        else:
            print("no dates matched in row text")
        browser.close()

if __name__ == "__main__":
    main()
