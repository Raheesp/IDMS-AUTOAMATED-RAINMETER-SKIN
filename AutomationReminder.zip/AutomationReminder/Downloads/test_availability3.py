import sys
sys.path.insert(0, r"e:\ibnd\AutomationReminder\Downloads")
import IdmsDownload as idms

def main():
    user, pw = idms.read_creds()
    from playwright.sync_api import sync_playwright
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=True)
        ctx = browser.new_context(accept_downloads=True)
        page = ctx.new_page()
        page.goto(idms.LOGIN_URL, timeout=30000)
        idms.try_fill(page, idms.SEL_USER, user)
        idms.try_fill(page, idms.SEL_PASS, pw)
        page.click(idms.SEL_LOGIN, timeout=8000)
        page.wait_for_load_state("networkidle", timeout=20000)
        print("post-login url:", page.url)
        if idms.LOGIN_MARKER in page.url.lower():
            print("LOGIN DID NOT SUCCEED - stopping")
            body_text = page.locator("body").inner_text()
            print("page text snippet:", body_text[:1500])
            browser.close()
            return
        cfg = idms.REPORTS["booking"]
        ok = idms.goto_report(page, cfg)
        print("goto_report ok:", ok, "url:", page.url)
        d_from, d_to = idms.month_offset_to_range(0)
        print("range:", d_from, d_to)
        idms.try_fill(page, cfg["df"], d_from)
        idms.try_fill(page, cfg["dt"], d_to)
        val_from = page.eval_on_selector(cfg["df"], "el => el.value")
        val_to = page.eval_on_selector(cfg["dt"], "el => el.value")
        print(f"field values: from={val_from!r} to={val_to!r}")
        try:
            idms.click_text(page, cfg["filt"], timeout=6000)
            print("filter clicked ok")
        except Exception as e:
            print("filter click failed:", e)
        rows = page.locator("table tbody tr")
        for i in range(20):
            page.wait_for_timeout(1000)
            count = rows.count()
            text = rows.first.inner_text()[:80] if count else ""
            print(f"t={i+1}s count={count} text={text!r}")
            if count and "loading" not in text.lower():
                break
        browser.close()

if __name__ == "__main__":
    main()
