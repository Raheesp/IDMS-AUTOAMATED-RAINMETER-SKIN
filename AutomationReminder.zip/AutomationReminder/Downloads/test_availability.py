"""Quick validation of find_earliest_available_month() against reports with
known ground truth (booking and docket_cancellation both confirmed via prior
manual dump testing to start around August 2025). Not part of the shipped
feature - delete after validation."""
import sys, time
sys.path.insert(0, r"e:\ibnd\AutomationReminder\Downloads")
import IdmsDownload as idms

TEST_KEYS = ["booking", "docket_cancellation"]

def main():
    user, pw = idms.read_creds()
    from playwright.sync_api import sync_playwright
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=True)
        ctx = browser.new_context(accept_downloads=True)
        page = ctx.new_page()
        if not idms.do_login(page, user, pw):
            print("LOGIN FAILED, url:", page.url)
            print(page.locator("body").inner_text()[:1000])
            return
        for key in TEST_KEYS:
            cfg = idms.REPORTS[key]
            t0 = time.time()
            earliest, latest = idms.find_data_bounds(page, cfg, key)
            print(f"{key} ({cfg['label']}): {earliest} to {latest}   [{time.time()-t0:.1f}s]")
        browser.close()

if __name__ == "__main__":
    main()
