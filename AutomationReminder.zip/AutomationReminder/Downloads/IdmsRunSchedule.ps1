# ============================================================================
#  IdmsRunSchedule.ps1  -  shared Action target for every per-report IDMS
#  schedule (once / daily / weekly), registered by IdmsScheduleTask.ps1.
# ----------------------------------------------------------------------------
#  Resolves PythonExe fresh from Downloads.ini on EVERY firing instead of
#  baking a literal path into each Scheduled Task at creation time - so if
#  Python is reinstalled/moved, re-running Setup.ps1 (which already rewrites
#  Downloads.ini's PythonExe= line) fixes every existing schedule in one
#  shot, not just future ones.
# ============================================================================

param([Parameter(Mandatory)][string]$ScheduleFile)

$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$ini  = Join-Path $here 'Downloads.ini'
$pyw = $null

if (Test-Path $ini) {
    $line = Get-Content $ini | Where-Object { $_ -match '^PythonExe=' } | Select-Object -First 1
    if ($line) { $pyw = ($line -split '=', 2)[1].Trim() }
}
if (-not $pyw -or -not (Test-Path $pyw)) {
    $cmd = Get-Command pythonw.exe -ErrorAction SilentlyContinue
    if ($cmd) { $pyw = $cmd.Source }
}
if (-not $pyw -or -not (Test-Path $pyw)) {
    $lines = @(
        'status=ERROR',
        "time=$([DateTimeOffset]::UtcNow.ToUnixTimeSeconds())",
        'done=0', 'total=0', 'current=',
        'message=pythonw.exe could not be found - re-run Setup.ps1'
    )
    [IO.File]::WriteAllLines("$ScheduleFile.status.txt", $lines, (New-Object System.Text.UTF8Encoding($false)))
    exit 1
}

& $pyw (Join-Path $here 'IdmsDownload.py') --run-file $ScheduleFile
