import sys
sys.path.insert(0, r"e:\ibnd\AutomationReminder\Downloads")
import IdmsDownload as idms

def main():
    user, pw = idms.read_creds()
    from playwright.sync_api import sync_playwright
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=True)
        ctx = browser.new_context(accept_downloads=True)
        page = ctx.new_page()
        if not idms.do_login(page, user, pw):
            print("LOGIN FAILED")
            return

        results = {}
        for key in ["enquiry", "taxlist"]:
            cfg = idms.REPORTS[key]
            earliest, latest = idms.find_data_bounds(page, cfg, key)
            if earliest is None:
                results[key] = "none"
            else:
                results[key] = f"{earliest} to {latest}"
            print(key, "->", results[key])
        browser.close()

    # merge into idms_availability.txt
    lines = []
    with open(idms.AVAILABILITY_FILE, "r", encoding="utf-8-sig") as f:
        for line in f:
            line = line.rstrip("\n")
            k = line.split("=", 1)[0]
            if k in results:
                lines.append(f"{k}={results[k]}")
            else:
                lines.append(line)
    with open(idms.AVAILABILITY_FILE, "w", encoding="utf-8") as f:
        f.write("\n".join(lines) + "\n")
    print("merged into", idms.AVAILABILITY_FILE)

if __name__ == "__main__":
    main()
