-- ============================================================================
--  IdmsEngine.lua  -  engine for the IDMS dropdown (report picker)
-- ----------------------------------------------------------------------------
--  Fully separate measure/script from DownloadEngine.lua (MScript) - the
--  existing PORTAL DATA bar (RUN NOW / UPDATE PASSWORD / booking-docket-
--  enquiry counts) is untouched. This engine only owns the IdmsPanel group:
--  the report checkbox grid (see REPORT_COUNT below), the date-mode pills,
--  and the DOWNLOAD button.
--
--  Writes %LOCALAPPDATA%\AutomationReminder\idms_selection.txt when DOWNLOAD
--  is clicked, then runs IdmsDownload.py (via MeasureIdmsDownload) and polls
--  idms_status.txt for live progress, same status-file pattern as the main
--  bar. Shares creds.txt / the UPDATE PASSWORD notepad flow already wired in
--  Downloads.ini - login failures surface the same way here.
-- ============================================================================

local REPORTS = {
  {key="pending_booking",      label="Pending Booking Report"},
  {key="booking",               label="Booking Report"},
  {key="registration",          label="Registration Report"},
  {key="docket",                label="Docket Report"},
  {key="stock",                 label="Stock Report"},
  {key="sales",                 label="Sales Report"},
  {key="invoice_pending",       label="Invoice Pending Report"},
  {key="delivery",              label="Delivery Report"},
  {key="ibnd",                  label="IBND Reports"},
  {key="docket_cancellation",   label="Docket Cancellation"},
  {key="idms_data_collection",  label="IDMS Data Collection"},
  {key="enquiry",               label="Enquiry Report"},
  {key="commitment",            label="Commitment Report"},
  {key="docket_commitment",     label="Docket Commitment Report"},
  {key="pdi_work",              label="PDI Work Report"},
  {key="lead_enquiry",          label="Lead Enquiry Report"},
  {key="priority_booking",      label="Priority Booking Report"},
  {key="service_contact",       label="Service Contact Report"},
  {key="lost_enquiry",          label="Lost Enquiry Report"},
  {key="tax_invoice",           label="Tax Invoice"},
  {key="finalplan",             label="Final Plan"},
  {key="taxlist",               label="Tax List Report"},
  {key="cancelled_without_doc", label="Cancelled Without Document"},
  {key="reg_number_status",     label="Reg Number Status"},
  {key="stock_view",            label="Stock View"},
  {key="pending_reg_number",    label="Pending Reg Number"},
  {key="followups_current",     label="Follow Ups - Current"},
  {key="followups_overdue",     label="Follow Ups - Overdue"},
  {key="followups_upcoming",    label="Follow Ups - Upcoming"},
  {key="followups_all",         label="Follow Ups - All 3"},
  {key="crm_enquiry_active",     label="CRM Enquiry - Active"},
  {key="crm_enquiry_lost",       label="CRM Enquiry - Lost"},
}
local REPORT_COUNT = #REPORTS

local ACCENT = "255,186,110"
local DIM    = "182,168,158"
local ROWTEXT= "236,228,219,225"
local OKC    = "122,214,178"
local FAILC  = "255,95,95"

local MONTH_NAMES = {'Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'}

local base = nil
local selectionFile, rangeFile, dumpFromFile, statusFile, downloadsDir = nil, nil, nil, nil, nil
local availabilityFile, availStatusFile = nil, nil
local selected = {}         -- [1..REPORT_COUNT] -> true/false
local mode = "asis"         -- asis | today | month | custom
local dumpMode = false      -- CREATE DUMP toggle: month-by-month year-to-date archive
local combineFiles = true   -- true = merge dump months into one file; false = keep separate
local downloading = false
local downloadStartTime = 0   -- os.time() when downloading was set true - see
                               -- DOWNLOAD_TIMEOUT_SECS below for why this exists
local resultShown = false
local availability = {}     -- [key] -> "YYYY-MM-DD to YYYY-MM-DD" / "none" / "error: ..."
local availChecked = nil    -- date string, or nil if never scanned
local scanning = false
local scanStartTime = 0

-- Every poll* function below used to just return and try again on the very
-- next Update() if its status file wasn't there yet, forever, with no
-- upper bound - confirmed real bug this fixes: IdmsSendEmail.ps1 got
-- killed by MeasureIdmsSendEmailNow's own RunCommand Timeout mid-run (the
-- email had, in that case, actually already sent) and never got the
-- chance to write any status file, and the panel was stuck showing
-- "Sending... opening Outlook..." forever with no way to recover short of
-- restarting the skin. These constants are each a little longer than the
-- matching measure's own Timeout= in Downloads.ini, so if the backend
-- process is ever killed or genuinely hangs, the UI gives up and shows a
-- clear timeout message instead of freezing indefinitely.
local DOWNLOAD_TIMEOUT_SECS = 960      -- MeasureIdmsDownload Timeout=900000
local SCAN_TIMEOUT_SECS = 7260         -- MeasureIdmsAvailScan Timeout=7200000
local SCHEDULE_REG_TIMEOUT_SECS = 45   -- MeasureIdmsScheduleReg Timeout=30000
local EMAIL_SEND_TIMEOUT_SECS = 960    -- MeasureIdmsSendEmailNow Timeout=900000
local EMAIL_REG_TIMEOUT_SECS = 45      -- MeasureIdmsEmailReg Timeout=30000

local schedulesDir, scheduleDraftFile = nil, nil
local pendingRegStatusFile = nil   -- set fresh per schedule-creation attempt
-- Latches the schedule OK/ERROR message on screen past the single tick
-- schedulingRegistration is true for. Confirmed real bug: without this,
-- Render()'s idle hint (guarded only by "not schedulingRegistration")
-- overwrote the just-shown result back to "N reports ready..." on the very
-- next Update() cycle - a real registration error would flash and vanish
-- before it could be read. Mirrors the existing resultShown/downloading
-- pattern already used for the DOWNLOAD status.
local scheduleResultShown = false
local schedulingRegistration = false
local schedulingRegStartTime = 0
local schedulesSummaryFile, schedulesSummaryStatusFile = nil, nil
local viewingSchedules = false
local awaitingScheduleConfirm = false   -- true between "opened Notepad" and
                                         -- the user's explicit CONFIRM click -
                                         -- see PrepareScheduleTask() for why
                                         -- this can't just auto-detect Notepad
                                         -- closing.
local currentPath = nil     -- SKIN:GetVariable('CURRENTPATH'), cached in Initialize() -
                             -- the #CURRENTPATH# ini token doesn't resolve inside a
                             -- Lua string built at runtime, need the real value.

local emailsDir, emailDraftFile = nil, nil
local pendingEmailRegStatusFile = nil
local emailResultShown = false   -- see scheduleResultShown - same latch, same reason
local emailingInProgress = false
local emailingStartTime = 0
local emailingTimeoutSecs = EMAIL_SEND_TIMEOUT_SECS   -- set per-trigger: the
                                                       -- immediate NOW send and
                                                       -- the schedule-registration
                                                       -- path share this same
                                                       -- flag/poll function but
                                                       -- have very different
                                                       -- realistic durations
local emailsSummaryFile, emailsSummaryStatusFile = nil, nil
local viewingEmails = false
local awaitingEmailConfirm = false   -- see awaitingScheduleConfirm - same reason

local deleteDraftFile = nil
local deleteStatusFile = nil   -- shared, not per-attempt - IdmsDeleteTask.ps1 has no
                                -- natural unique-per-job filename the way a newly
                                -- created schedule/email does, so it always writes
                                -- to the same idms_delete_status.txt; cleared before
                                -- every attempt so a stale result is never read.
local deletingInProgress = false
local deleteResultShown = false
local awaitingDeleteConfirm = false   -- see awaitingScheduleConfirm - same reason

local function setOpt(m, o, v) SKIN:Bang('!SetOption', m, o, v) end

local function ensureDirAndRange()
  os.execute('mkdir "' .. base .. '" >nul 2>nul')
  os.execute('mkdir "' .. downloadsDir .. '" >nul 2>nul')
  local f = io.open(rangeFile, 'r')
  if f then f:close() else
    local w = io.open(rangeFile, 'w')
    if w then
      w:write('FROM=' .. os.date('%Y-%m-01') .. '\r\nTO=' .. os.date('%Y-%m-%d') .. '\r\n')
      w:close()
    end
  end
  local df = io.open(dumpFromFile, 'r')
  if df then df:close() else
    local w = io.open(dumpFromFile, 'w')
    if w then
      w:write('FROM=' .. os.date('%Y-01') .. '\r\n')
      w:close()
    end
  end
end

local function ensureSchedulesDir()
  os.execute('mkdir "' .. schedulesDir .. '" >nul 2>nul')
  local f = io.open(scheduleDraftFile, 'r')
  if f then f:close() else
    local w = io.open(scheduleDraftFile, 'w')
    if w then
      w:write(
        '; --- IDMS SCHEDULE TASK -----------------------------------------\r\n' ..
        '; Runs whatever reports are checked in the panel right now, at the\r\n' ..
        '; time below, unattended - even if this panel is closed.\r\n' ..
        ';\r\n' ..
        'NAME=\r\n' ..
        '; Optional. Give this schedule your own name, e.g. NAME=Morning Stock\r\n' ..
        '; Check - shown in the SCHEDULES list and in Task Scheduler. Leave\r\n' ..
        '; blank for an automatic name built from the reports/repeat pattern.\r\n' ..
        '; This only sets what YOU see - schedules always run and are stored\r\n' ..
        '; only on this PC (not synced to other computers), even if the ones\r\n' ..
        '; on other PCs use the exact same name.\r\n' ..
        '\r\n' ..
        'TIME=09:00\r\n' ..
        '; 24-hour HH:MM, e.g. 09:00 or 14:30\r\n' ..
        '\r\n' ..
        'DATE=\r\n' ..
        '; Optional. YYYY-MM-DD, e.g. 2026-08-15. Leave blank to use the next\r\n' ..
        '; occurrence of TIME= (today if still ahead, else tomorrow). For\r\n' ..
        '; REPEAT=monthly, this also sets which day of the month it repeats on.\r\n' ..
        '\r\n' ..
        'PATH=\r\n' ..
        '; Where the file(s) should land. Leave blank to use the normal\r\n' ..
        '; Downloads folder (same place the DOWNLOAD button saves to).\r\n' ..
        '\r\n' ..
        'REPEAT=once\r\n' ..
        '; once     = runs one time only, then removes itself automatically\r\n' ..
        '; daily    = runs every day at TIME=\r\n' ..
        '; weekly   = runs on specific days each week at TIME= (set DAYS= below)\r\n' ..
        '; monthly  = runs every month (or every few months - set MONTHS= below)\r\n' ..
        ';            on the day of month from DATE=, at TIME=\r\n' ..
        '; interval = runs repeatedly all day, every EVERY= minutes, starting\r\n' ..
        ';            at TIME= (set EVERY= below) - e.g. every 2 hours from 9am\r\n' ..
        '\r\n' ..
        'DAYS=\r\n' ..
        '; Only used when REPEAT=weekly. Comma-separated, e.g. Mon,Wed,Fri\r\n' ..
        '; Valid: Mon Tue Wed Thu Fri Sat Sun\r\n' ..
        '\r\n' ..
        'EVERY=\r\n' ..
        '; Only used when REPEAT=interval. Minutes between runs (minimum 5),\r\n' ..
        '; e.g. EVERY=120 for every 2 hours.\r\n' ..
        '\r\n' ..
        'MONTHS=1\r\n' ..
        '; Only used when REPEAT=monthly. Every how many months - 1 = every\r\n' ..
        '; month, 2 = every 2 months, 3 = quarterly, etc. Starts counting from\r\n' ..
        '; DATE= (or today, if DATE= is blank).\r\n' ..
        '\r\n' ..
        'DATEFOLDER=off\r\n' ..
        '; off       = save straight into PATH (default)\r\n' ..
        '; today     = save into a DD-MM-YYYY subfolder for the day this runs,\r\n' ..
        ';             e.g. PATH\\27-07-2026\\ - created fresh every time it\r\n' ..
        ';             runs, so a daily/weekly/interval schedule gets a new\r\n' ..
        ';             folder each day automatically\r\n' ..
        '; yesterday = same, but dated one day back, e.g. PATH\\26-07-2026\\\r\n' ..
        ';             (useful when a schedule runs after midnight for data\r\n' ..
        ';             that belongs to the day before)\r\n'
      )
      w:close()
    end
  end
end

-- Unconditionally (re)writes the blank-default draft template. Split out
-- of ensureEmailsDir() (which only writes when the file is missing, for
-- Initialize()-time seeding) so FinishEmailTask() can also call this
-- directly after a successful send/schedule to reset the draft. Unlike
-- SCHEDULE TASK's draft (where stale leftover TIME/PATH is low-risk - a
-- new schedule ID is always created, so an unnoticed stale value is just a
-- slightly-off local task time, easy to spot in SCHEDULES), a stale EMAIL
-- draft is a real risk: silently re-sending to yesterday's recipient or
-- under yesterday's subject line is an external, visible mistake, not a
-- locally-correctable one. Confirmed live: exactly this happened - a test
-- send's leftover TO/SUBJECT sat in the draft and very nearly went out
-- again unnoticed.
local function writeEmailDraftTemplate()
  local w = io.open(emailDraftFile, 'w')
  if w then
    w:write(
      '; --- IDMS SEND EMAIL -----------------------------------------\r\n' ..
        '; Sends whatever reports are checked in the panel right now as\r\n' ..
        '; email attachments via Outlook - either right now, or on a\r\n' ..
        '; schedule (even if this panel is closed). Uses whatever is\r\n' ..
        '; already in the Downloads folder for each checked report - click\r\n' ..
        '; DOWNLOAD first if you have not already. CREATE DUMP selections\r\n' ..
        '; are not supported here - switch CREATE DUMP off first.\r\n' ..
        ';\r\n' ..
        'TO=\r\n' ..
        '; Required. One or more addresses, comma-separated.\r\n' ..
        '\r\n' ..
        'CC=\r\n' ..
        '; Optional. Comma-separated.\r\n' ..
        '\r\n' ..
        'SUBJECT=\r\n' ..
        '; Optional. Leave blank to use "IDMS DATA". Whatever you type\r\n' ..
        '; here is used exactly as-is - both as the email subject and as\r\n' ..
        '; the title shown inside the email. Nothing is auto-generated\r\n' ..
        '; from the report names.\r\n' ..
        '\r\n' ..
        'BODY=\r\n' ..
        '; Optional message. Leave blank for a plain default line. Use |\r\n' ..
        '; to start a new paragraph, e.g. First paragraph.|Second one.\r\n' ..
        '\r\n' ..
        'TIME=NOW\r\n' ..
        '; NOW = send right away, once, when you click CONFIRM EMAIL.\r\n' ..
        '; Otherwise 24-hour HH:MM to send at a specific time - combine\r\n' ..
        '; with REPEAT= below the same way SCHEDULE TASK does.\r\n' ..
        '\r\n' ..
        'DATE=\r\n' ..
        '; Optional (ignored when TIME=NOW). YYYY-MM-DD, e.g. 2026-08-15.\r\n' ..
        '; Leave blank to use the next occurrence of TIME=. For\r\n' ..
        '; REPEAT=monthly, this also sets the day of the month.\r\n' ..
        '\r\n' ..
        'REPEAT=once\r\n' ..
        '; Ignored when TIME=NOW. once/daily/weekly/monthly/interval -\r\n' ..
        '; exactly like SCHEDULE TASK (see that draft file for the full\r\n' ..
        '; explanation of each mode and its DAYS=/EVERY=/MONTHS= field).\r\n' ..
        '\r\n' ..
        'DAYS=\r\n' ..
        'EVERY=\r\n' ..
        'MONTHS=1\r\n'
    )
    w:close()
  end
end

local function ensureEmailsDir()
  os.execute('mkdir "' .. emailsDir .. '" >nul 2>nul')
  local f = io.open(emailDraftFile, 'r')
  if f then f:close() else writeEmailDraftTemplate() end
end

local function writeDeleteDraftTemplate()
  local w = io.open(deleteDraftFile, 'w')
  if w then
    w:write(
      '; --- IDMS DELETE TASK -----------------------------------------\r\n' ..
      '; Permanently removes one scheduled download or scheduled email -\r\n' ..
      '; unregisters the real Windows Scheduled Task and deletes its saved\r\n' ..
      '; settings. This cannot be undone.\r\n' ..
      ';\r\n' ..
      '; To CHANGE a schedule/email instead of removing it (different time,\r\n' ..
      '; reports, path, or recipients), delete it here, then create a new\r\n' ..
      '; one with SCHEDULE TASK or EMAIL.\r\n' ..
      ';\r\n' ..
      'TASKNAME=\r\n' ..
      '; Required. Paste the EXACT name shown in the SCHEDULES or EMAILS\r\n' ..
      '; summary (e.g. "IDMS Scheduled - Booking Report - Daily 0900 (a1b2c3)").\r\n' ..
      '\r\n' ..
      'TYPE=schedule\r\n' ..
      '; schedule = looks in the SCHEDULES list (\\IDMS Scheduled\\)\r\n' ..
      '; email    = looks in the EMAILS list (\\IDMS Email Scheduled\\)\r\n'
    )
    w:close()
  end
end

local function ensureDeleteDraft()
  local f = io.open(deleteDraftFile, 'r')
  if f then f:close() else writeDeleteDraftTemplate() end
end

-- Some editors (and PowerShell's Set-Content -Encoding UTF8) save a UTF-8
-- BOM at the start of the file - left in place, it silently breaks the
-- first line's "%a+" match below (confirmed real bug: a BOM-saved
-- idms_dump_from.txt made CREATE DUMP silently ignore a custom start month
-- and fall back to January). Strip it if present.
local function stripBOM(s)
  if s:sub(1, 3) == '\239\187\191' then s = s:sub(4) end
  -- Also strip a trailing \r: Rainmeter's bundled Lua does not do CRLF
  -- text-mode translation on Windows, so f:lines() on a \r\n-saved file
  -- (Notepad's default) leaves a literal \r as the last character of every
  -- line. Confirmed real bug: this made "09:00\r" fail the end-anchored
  -- '^(%d%d):(%d%d)$' TIME check with a "Invalid TIME (09:00)" error that
  -- looked valid on screen. Earlier parsers (FROM=, checked=) never hit
  -- this because their patterns aren't $-anchored - but REPEAT=/DAYS=/
  -- DATEFOLDER=/etc exact-string comparisons downstream would have the
  -- same silent-failure problem, so fix it once here for every caller.
  return (s:gsub('\r$', ''))
end

local function readRange()
  local from, to = os.date('%Y-%m-01'), os.date('%Y-%m-%d')
  local f = io.open(rangeFile, 'r')
  if f then
    for line in f:lines() do
      local k, v = stripBOM(line):match('^(%a+)%s*=%s*(.*)$')
      if k == 'FROM' and v and v ~= '' then from = v end
      if k == 'TO' and v and v ~= '' then to = v end
    end
    f:close()
  end
  return from, to
end

-- (year, month) CREATE DUMP starts from, parsed from idms_dump_from.txt
-- (FROM=YYYY-MM). Falls back to January of this year.
local function readDumpStart()
  local year, month = tonumber(os.date('%Y')), 1
  local f = io.open(dumpFromFile, 'r')
  if f then
    for line in f:lines() do
      local k, v = stripBOM(line):match('^(%a+)%s*=%s*(.*)$')
      if k == 'FROM' and v and v ~= '' then
        local y, m = v:match('^(%d+)%-(%d+)')
        if y and m then year, month = tonumber(y), tonumber(m) end
      end
    end
    f:close()
  end
  if not month or month < 1 or month > 12 then month = 1 end
  return year, month
end

local function dumpFromLabel()
  local year, month = readDumpStart()
  return (MONTH_NAMES[month] or 'Jan') .. ' ' .. year
end

-- Parses idms_availability.txt (written by IdmsDownload.py --scan):
-- "checked=YYYY-MM-DD" then one "key=..." line per scannable report.
local function readAvailability()
  availability = {}
  availChecked = nil
  local f = io.open(availabilityFile, 'r')
  if not f then return end
  for line in f:lines() do
    local k, v = stripBOM(line):match('^([^=]+)=(.*)$')
    if k == 'checked' then
      availChecked = v
    elseif k then
      availability[k] = v
    end
  end
  f:close()
end

-- 'YYYY-MM-DD' (optionally '... or earlier') -> '04 Aug 2025 (or earlier)'
local function formatDate(iso)
  if not iso then return iso end
  local core = iso:match('^(.-) or earlier$') or iso
  local y, m, d = core:match('^(%d+)-(%d+)-(%d+)$')
  if not y then return iso end
  local out = string.format('%02d %s %s', tonumber(d), MONTH_NAMES[tonumber(m)] or m, y)
  if iso:match(' or earlier$') then out = out .. ' or earlier' end
  return out
end

-- Tooltip body describing what date range a report actually has data for,
-- shown on hover so you know before you pick dates and download whether
-- your requested range will actually return anything.
local function availTooltip(key)
  local v = availability[key]
  if v == nil then
    if availChecked == nil then
      return 'Data availability: not checked yet - click REFRESH AVAILABILITY below'
    else
      return 'Data availability: not applicable (this report has no date-range filter)'
    end
  end
  if v == 'none' then
    return 'Data availability: no data found for this report'
  end
  if v:match('^error:') then
    return 'Data availability: could not check last time (' .. v .. ')'
  end
  local earliest, latest = v:match('^(.-) to (.+)$')
  if earliest and latest then
    return 'Data available: ' .. formatDate(earliest) .. '  to  ' .. formatDate(latest)
  end
  return 'Data availability: ' .. v
end

function Initialize()
  ACCENT  = SKIN:GetVariable('Accent')  or ACCENT
  DIM     = SKIN:GetVariable('Dim')     or DIM
  ROWTEXT = SKIN:GetVariable('RowText') or ROWTEXT

  local la = os.getenv('LOCALAPPDATA') or SKIN:GetVariable('CURRENTPATH')
  base = la .. '\\AutomationReminder\\'
  selectionFile = base .. 'idms_selection.txt'
  rangeFile     = base .. 'idms_range.txt'
  dumpFromFile  = base .. 'idms_dump_from.txt'
  statusFile    = base .. 'idms_status.txt'
  downloadsDir  = base .. 'idms_downloads'
  availabilityFile  = base .. 'idms_availability.txt'
  availStatusFile   = base .. 'idms_availability_status.txt'
  schedulesDir      = base .. 'schedules\\'
  scheduleDraftFile = base .. 'idms_schedule_draft.txt'
  schedulesSummaryFile       = base .. 'idms_schedules_summary.txt'
  schedulesSummaryStatusFile = base .. 'idms_schedules_summary_status.txt'
  emailsDir      = base .. 'emails\\'
  emailDraftFile = base .. 'idms_email_draft.txt'
  emailsSummaryFile       = base .. 'idms_emails_summary.txt'
  emailsSummaryStatusFile = base .. 'idms_emails_summary_status.txt'
  deleteDraftFile  = base .. 'idms_delete_draft.txt'
  deleteStatusFile = base .. 'idms_delete_status.txt'
  currentPath = SKIN:GetVariable('CURRENTPATH')
  ensureDirAndRange()
  ensureSchedulesDir()
  ensureEmailsDir()
  ensureDeleteDraft()
  readAvailability()

  -- these need the absolute path, so wire them here (same trick the main
  -- bar uses for MeterBtnPass -> creds.txt)
  setOpt('MeterIdmsModeCustom', 'LeftMouseUpAction',
    '[!CommandMeasure MScriptIdms "SetDateMode(\'custom\')"]["notepad.exe" "' .. rangeFile ..
    '"][!CommandMeasure MScriptIdms "Render()"][!UpdateMeterGroup IdmsPanel][!Redraw]')
  setOpt('MeterIdmsDumpFrom', 'LeftMouseUpAction',
    '["notepad.exe" "' .. dumpFromFile ..
    '"][!CommandMeasure MScriptIdms "Render()"][!UpdateMeterGroup IdmsPanel][!Redraw]')
  setOpt('MeterIdmsOpenFolder', 'LeftMouseUpAction', '["explorer.exe" "' .. downloadsDir .. '"]')
  setOpt('MeterIdmsManageSchedulesBtn', 'LeftMouseUpAction',
    '[!CommandMeasure MScriptIdms "ViewSchedules()"]')
  setOpt('MeterIdmsManageEmailsBtn', 'LeftMouseUpAction',
    '[!CommandMeasure MScriptIdms "ViewEmails()"]')

  Render()
end

function Render()
  local count = 0
  for i = 1, REPORT_COUNT do
    local on = selected[i] == true
    if on then count = count + 1 end
    setOpt('MeterIdmsRow' .. i, 'Text', (on and '[x] ' or '[ ] ') .. REPORTS[i].label)
    setOpt('MeterIdmsRow' .. i, 'FontColor', on and (ACCENT .. ',255') or ROWTEXT)
    setOpt('MeterIdmsRow' .. i, 'ToolTipText', REPORTS[i].label .. '\n' .. availTooltip(REPORTS[i].key))
  end

  -- Re-wired on every Render() - see the long comment on PrepareScheduleTask()
  -- for why this is a two-click confirm (open, THEN a separate explicit
  -- confirm click) rather than "open and auto-detect Notepad closing".
  if awaitingScheduleConfirm then
    setOpt('MeterIdmsScheduleBtn', 'Text', 'CONFIRM SCHEDULE')
    setOpt('MeterIdmsScheduleBtn', 'LeftMouseUpAction',
      '[!CommandMeasure MScriptIdms "FinishScheduleTask()"][!UpdateMeterGroup IdmsPanel][!Redraw]')
  elseif count == 0 then
    setOpt('MeterIdmsScheduleBtn', 'Text', 'SCHEDULE TASK')
    setOpt('MeterIdmsScheduleBtn', 'LeftMouseUpAction',
      '[!CommandMeasure MScriptIdms "PrepareScheduleTask()"][!UpdateMeterGroup IdmsPanel][!Redraw]')
  else
    setOpt('MeterIdmsScheduleBtn', 'Text', 'SCHEDULE TASK')
    setOpt('MeterIdmsScheduleBtn', 'LeftMouseUpAction',
      '["notepad.exe" "' .. scheduleDraftFile ..
      '"][!CommandMeasure MScriptIdms "OpenedScheduleDraft()"][!UpdateMeterGroup IdmsPanel][!Redraw]')
  end

  -- Same two-click confirm pattern as SCHEDULE TASK, same reason.
  if awaitingEmailConfirm then
    setOpt('MeterIdmsEmailBtn', 'Text', 'CONFIRM EMAIL')
    setOpt('MeterIdmsEmailBtn', 'LeftMouseUpAction',
      '[!CommandMeasure MScriptIdms "FinishEmailTask()"][!UpdateMeterGroup IdmsPanel][!Redraw]')
  elseif count == 0 or dumpMode then
    setOpt('MeterIdmsEmailBtn', 'Text', 'EMAIL')
    setOpt('MeterIdmsEmailBtn', 'LeftMouseUpAction',
      '[!CommandMeasure MScriptIdms "PrepareEmailTask()"][!UpdateMeterGroup IdmsPanel][!Redraw]')
  else
    setOpt('MeterIdmsEmailBtn', 'Text', 'EMAIL')
    setOpt('MeterIdmsEmailBtn', 'LeftMouseUpAction',
      '["notepad.exe" "' .. emailDraftFile ..
      '"][!CommandMeasure MScriptIdms "OpenedEmailDraft()"][!UpdateMeterGroup IdmsPanel][!Redraw]')
  end

  -- Same two-click confirm pattern - no "0 selected" precondition to guard
  -- here (deletion isn't tied to report selection), so only two states.
  if awaitingDeleteConfirm then
    setOpt('MeterIdmsDeleteBtn', 'Text', 'CONFIRM DELETE')
    setOpt('MeterIdmsDeleteBtn', 'LeftMouseUpAction',
      '[!CommandMeasure MScriptIdms "FinishDeleteTask()"][!UpdateMeterGroup IdmsPanel][!Redraw]')
  else
    setOpt('MeterIdmsDeleteBtn', 'Text', 'DELETE TASK')
    setOpt('MeterIdmsDeleteBtn', 'LeftMouseUpAction',
      '["notepad.exe" "' .. deleteDraftFile ..
      '"][!CommandMeasure MScriptIdms "OpenedDeleteDraft()"][!UpdateMeterGroup IdmsPanel][!Redraw]')
  end

  local pillMeter = {
    asis='MeterIdmsModeAsis', today='MeterIdmsModeToday', month='MeterIdmsModeMonth',
    lastmonth='MeterIdmsModeLastMonth', last2months='MeterIdmsModeLast2Months', custom='MeterIdmsModeCustom',
  }
  for m, meter in pairs(pillMeter) do
    -- while CREATE DUMP is on, the date-range pill is ignored entirely -
    -- show all of them as inactive rather than leaving the last-picked one
    -- lit up like it's still doing something.
    local active = (not dumpMode) and (m == mode)
    setOpt(meter, 'FontColor', active and (ACCENT .. ',255') or (DIM .. (dumpMode and ',110' or ',220')))
  end

  local preview
  if mode == 'today' then
    local d = os.date('%Y-%m-%d')
    preview = 'Will use ' .. d .. ' -> ' .. d
  elseif mode == 'month' then
    preview = 'Will use ' .. os.date('%Y-%m-01') .. ' -> ' .. os.date('%Y-%m-%d')
  elseif mode == 'lastmonth' then
    local firstThis = os.time{year=tonumber(os.date('%Y')), month=tonumber(os.date('%m')), day=1}
    local lastPrev = os.date('*t', firstThis - 86400)
    local firstPrev = os.time{year=lastPrev.year, month=lastPrev.month, day=1}
    preview = 'Will use ' .. os.date('%Y-%m-%d', firstPrev) .. ' -> ' .. os.date('%Y-%m-%d', firstThis - 86400)
  elseif mode == 'last2months' then
    local d = os.date('*t')
    local y, m = d.year, d.month - 2
    while m < 1 do m = m + 12; y = y - 1 end
    preview = 'Will use ' .. string.format('%04d-%02d-01', y, m) .. ' -> ' .. os.date('%Y-%m-%d')
  elseif mode == 'custom' then
    local from, to = readRange()
    preview = 'Will use ' .. from .. ' -> ' .. to .. '  (edit idms_range.txt to change)'
  else
    preview = "Each report's own default view - dates untouched, downloads immediately"
  end
  if dumpMode then
    preview = 'CREATE DUMP is on - downloads ' .. dumpFromLabel() .. ' -> today, month by month (date range above is ignored)'
  end
  setOpt('MeterIdmsRangePreview', 'Text', preview)

  setOpt('MeterIdmsDumpToggle', 'Text', dumpMode and 'CREATE DUMP: ON' or 'CREATE DUMP: OFF')
  setOpt('MeterIdmsDumpToggle', 'FontColor', dumpMode and (ACCENT .. ',255') or (DIM .. ',220'))
  setOpt('MeterIdmsDumpFrom', 'Text', 'DUMP FROM: ' .. dumpFromLabel())
  setOpt('MeterIdmsDumpFrom', 'FontColor', dumpMode and (ACCENT .. ',220') or (DIM .. ',150'))
  local combineActiveColor = dumpMode and (ACCENT .. ',255') or (DIM .. ',150')
  local combineIdleColor = dumpMode and (DIM .. ',220') or (DIM .. ',110')
  setOpt('MeterIdmsCombineOn', 'FontColor', combineFiles and combineActiveColor or combineIdleColor)
  setOpt('MeterIdmsCombineOff', 'FontColor', (not combineFiles) and combineActiveColor or combineIdleColor)

  if not downloading and not resultShown then
    if count == 0 then
      setOpt('MeterIdmsStatus', 'Text', 'No reports selected')
    else
      setOpt('MeterIdmsStatus', 'Text', count .. ' report' .. (count == 1 and '' or 's') .. ' selected - click DOWNLOAD')
    end
    setOpt('MeterIdmsStatus', 'FontColor', DIM .. ',235')
  end

  if not scanning then
    if availChecked then
      setOpt('MeterIdmsAvailStatus', 'Text', 'Data availability checked ' .. availChecked .. ' - hover any report above to see its range')
    else
      setOpt('MeterIdmsAvailStatus', 'Text', 'Data availability not checked yet - click REFRESH AVAILABILITY')
    end
    setOpt('MeterIdmsAvailStatus', 'FontColor', DIM .. ',200')
  end

  if not schedulingRegistration and not viewingSchedules and not scheduleResultShown then
    if count == 0 then
      setOpt('MeterIdmsScheduleStatus', 'Text', 'No reports selected')
    else
      setOpt('MeterIdmsScheduleStatus', 'Text', count .. ' report' .. (count == 1 and '' or 's') .. ' ready - click SCHEDULE TASK to set a time')
    end
    setOpt('MeterIdmsScheduleStatus', 'FontColor', DIM .. ',235')
  end

  if not emailingInProgress and not viewingEmails and not emailResultShown then
    if count == 0 then
      setOpt('MeterIdmsEmailStatus', 'Text', 'No reports selected')
    elseif dumpMode then
      setOpt('MeterIdmsEmailStatus', 'Text', 'EMAIL does not support CREATE DUMP - switch it off to send')
    else
      setOpt('MeterIdmsEmailStatus', 'Text', count .. ' report' .. (count == 1 and '' or 's') .. ' ready - click EMAIL to send')
    end
    setOpt('MeterIdmsEmailStatus', 'FontColor', DIM .. ',235')
  end

  if not deletingInProgress and not deleteResultShown then
    setOpt('MeterIdmsDeleteStatus', 'Text', 'Paste an exact task name from SCHEDULES or EMAILS to delete it')
    setOpt('MeterIdmsDeleteStatus', 'FontColor', DIM .. ',235')
  end
end

function Opened()
  Render()
end

function ToggleReport(i)
  i = tonumber(i)
  selected[i] = not selected[i]
  resultShown = false
  scheduleResultShown = false
  emailResultShown = false
  Render()
end

function SelectAll()
  for i = 1, REPORT_COUNT do selected[i] = true end
  resultShown = false
  scheduleResultShown = false
  emailResultShown = false
  Render()
end

function SelectNone()
  selected = {}
  resultShown = false
  scheduleResultShown = false
  emailResultShown = false
  Render()
end

function SetDateMode(m)
  mode = m
  resultShown = false
  scheduleResultShown = false
  emailResultShown = false
  Render()
end

function ToggleDump()
  dumpMode = not dumpMode
  resultShown = false
  scheduleResultShown = false
  emailResultShown = false
  Render()
end

function SetCombine(v)
  combineFiles = (tostring(v) == '1')
  resultShown = false
  scheduleResultShown = false
  emailResultShown = false
  Render()
end

function StartDownload()
  local list, count = {'mode=' .. mode, 'dump=' .. (dumpMode and '1' or '0'), 'combine=' .. (combineFiles and '1' or '0')}, 0
  for i = 1, REPORT_COUNT do
    if selected[i] then
      list[#list + 1] = 'report=' .. REPORTS[i].key
      count = count + 1
    end
  end
  if count == 0 then
    setOpt('MeterIdmsStatus', 'Text', 'Pick at least one report first')
    setOpt('MeterIdmsStatus', 'FontColor', FAILC .. ',255')
    return
  end
  local f = io.open(selectionFile, 'w')
  if f then
    f:write(table.concat(list, '\r\n') .. '\r\n')
    f:close()
  end
  downloading = true
  downloadStartTime = os.time()
  resultShown = false
  setOpt('MeterIdmsStatus', 'Text', 'Starting - logging in...')
  setOpt('MeterIdmsStatus', 'FontColor', ACCENT .. ',255')
  SKIN:Bang('!CommandMeasure', 'MeasureIdmsDownload', 'Run')
end

local function pollStatus()
  if not downloading and not resultShown then return end
  if downloading and os.time() - downloadStartTime > DOWNLOAD_TIMEOUT_SECS then
    downloading = false
    resultShown = true
    setOpt('MeterIdmsStatus', 'Text', 'Timed out waiting for a result after ' .. DOWNLOAD_TIMEOUT_SECS .. 's - the download may be stuck. Check Task Manager, then try again.')
    setOpt('MeterIdmsStatus', 'FontColor', FAILC .. ',255')
    Render()
    return
  end
  local f = io.open(statusFile, 'r')
  if not f then return end
  local s = {}
  for line in f:lines() do
    local k, v = line:match('^([^=]+)=(.*)$')
    if k then s[k] = v end
  end
  f:close()

  local st = s.status or ''
  if st == 'RUNNING' then
    local done, total, cur, msg = s.done or '0', s.total or '0', s.current or '', s.message or ''
    local txt = 'Downloading ' .. done .. '/' .. total
    if cur ~= '' then txt = txt .. ': ' .. cur end
    if msg ~= '' then txt = txt .. '  (' .. msg .. ')' end
    setOpt('MeterIdmsStatus', 'Text', txt .. '...')
    setOpt('MeterIdmsStatus', 'FontColor', ACCENT .. ',255')
    return
  end

  downloading = false
  resultShown = true
  if st == 'OK' then
    setOpt('MeterIdmsStatus', 'Text', (s.message ~= nil and s.message ~= '') and s.message or 'Done')
    setOpt('MeterIdmsStatus', 'FontColor', OKC .. ',235')
  elseif st == 'AUTH_FAILED' then
    -- Pass through the real message from IdmsDownload.py (same pattern
    -- SCHEDULE/EMAIL already use) instead of a fixed "password may have
    -- changed" guess - confirmed live that AUTH_FAILED is almost always a
    -- transient portal slowdown, not a bad password, and the old fixed
    -- text risked sending someone to "fix" a password that wasn't broken.
    setOpt('MeterIdmsStatus', 'Text', s.message or 'Login failed - try DOWNLOAD again in a moment.')
    setOpt('MeterIdmsStatus', 'FontColor', FAILC .. ',255')
  elseif st == 'NO_CREDS' then
    setOpt('MeterIdmsStatus', 'Text', 'No login saved yet - click UPDATE PASSWORD above, then DOWNLOAD again.')
    setOpt('MeterIdmsStatus', 'FontColor', FAILC .. ',255')
  elseif st == 'UNREACHABLE' then
    setOpt('MeterIdmsStatus', 'Text', 'Portal unreachable - check network / VPN, then try again.')
    setOpt('MeterIdmsStatus', 'FontColor', FAILC .. ',235')
  elseif st == 'NO_SELECTION' then
    setOpt('MeterIdmsStatus', 'Text', 'No reports selected')
    setOpt('MeterIdmsStatus', 'FontColor', DIM .. ',235')
  else
    setOpt('MeterIdmsStatus', 'Text', 'Error: ' .. ((s.message ~= nil and s.message ~= '') and s.message or 'unknown'))
    setOpt('MeterIdmsStatus', 'FontColor', FAILC .. ',255')
  end
end

function RefreshAvailability()
  if scanning then return end
  scanning = true
  scanStartTime = os.time()
  setOpt('MeterIdmsAvailStatus', 'Text', 'Checking data availability - logging in...')
  setOpt('MeterIdmsAvailStatus', 'FontColor', ACCENT .. ',255')
  SKIN:Bang('!CommandMeasure', 'MeasureIdmsAvailScan', 'Run')
end

local function pollAvailStatus()
  if not scanning then return end
  if os.time() - scanStartTime > SCAN_TIMEOUT_SECS then
    scanning = false
    setOpt('MeterIdmsAvailStatus', 'Text', 'Timed out waiting for a result after ' .. SCAN_TIMEOUT_SECS .. 's - the scan may be stuck. Check Task Manager, then try REFRESH AVAILABILITY again.')
    setOpt('MeterIdmsAvailStatus', 'FontColor', FAILC .. ',255')
    Render()
    return
  end
  local f = io.open(availStatusFile, 'r')
  if not f then return end
  local s = {}
  for line in f:lines() do
    local k, v = line:match('^([^=]+)=(.*)$')
    if k then s[k] = v end
  end
  f:close()

  local st = s.status or ''
  if st == 'RUNNING' then
    local done, total, cur = s.done or '0', s.total or '0', s.current or ''
    local txt = 'Checking availability ' .. done .. '/' .. total
    if cur ~= '' then txt = txt .. ': ' .. cur end
    setOpt('MeterIdmsAvailStatus', 'Text', txt .. '...')
    setOpt('MeterIdmsAvailStatus', 'FontColor', ACCENT .. ',255')
    return
  end

  scanning = false
  if st == 'OK' then
    readAvailability()
  elseif st == 'AUTH_FAILED' then
    setOpt('MeterIdmsAvailStatus', 'Text', 'Availability check failed: ' .. (s.message or 'login did not succeed - try again in a moment'))
    setOpt('MeterIdmsAvailStatus', 'FontColor', FAILC .. ',255')
  else
    setOpt('MeterIdmsAvailStatus', 'Text', 'Availability check failed: ' .. ((s.message ~= nil and s.message ~= '') and s.message or st))
    setOpt('MeterIdmsAvailStatus', 'FontColor', FAILC .. ',255')
  end
  Render()
end

-- ------------------------------------------------------------- scheduling ---

local function readScheduleDraft()
  local time_, path_, repeat_, days_, every_, datefolder_, date_, months_, name_ =
    '09:00', '', 'once', '', '', 'off', '', '1', ''
  local f = io.open(scheduleDraftFile, 'r')
  if f then
    for line in f:lines() do
      local k, v = stripBOM(line):match('^(%a+)%s*=%s*(.*)$')
      if k == 'NAME' and v ~= nil then name_ = v end
      if k == 'TIME' and v then time_ = v end
      if k == 'DATE' and v ~= nil then date_ = v end
      if k == 'PATH' and v ~= nil then path_ = v end
      if k == 'REPEAT' and v then repeat_ = v end
      if k == 'DAYS' and v ~= nil then days_ = v end
      if k == 'EVERY' and v ~= nil then every_ = v end
      if k == 'MONTHS' and v ~= nil then months_ = v end
      if k == 'DATEFOLDER' and v then datefolder_ = v end
    end
    f:close()
  end
  return time_, path_, repeat_, days_, every_, datefolder_, date_, months_, name_
end

local function readEmailDraft()
  local to_, cc_, subject_, body_, time_, date_, repeat_, days_, every_, months_ =
    '', '', '', '', 'NOW', '', 'once', '', '', '1'
  local f = io.open(emailDraftFile, 'r')
  if f then
    for line in f:lines() do
      local k, v = stripBOM(line):match('^(%a+)%s*=%s*(.*)$')
      if k == 'TO' and v ~= nil then to_ = v end
      if k == 'CC' and v ~= nil then cc_ = v end
      if k == 'SUBJECT' and v ~= nil then subject_ = v end
      if k == 'BODY' and v ~= nil then body_ = v end
      if k == 'TIME' and v then time_ = v end
      if k == 'DATE' and v ~= nil then date_ = v end
      if k == 'REPEAT' and v then repeat_ = v end
      if k == 'DAYS' and v ~= nil then days_ = v end
      if k == 'EVERY' and v ~= nil then every_ = v end
      if k == 'MONTHS' and v ~= nil then months_ = v end
    end
    f:close()
  end
  return to_, cc_, subject_, body_, time_, date_, repeat_, days_, every_, months_
end

local function readDeleteDraft()
  local taskname_, type_ = '', 'schedule'
  local f = io.open(deleteDraftFile, 'r')
  if f then
    for line in f:lines() do
      local k, v = stripBOM(line):match('^(%a+)%s*=%s*(.*)$')
      if k == 'TASKNAME' and v ~= nil then taskname_ = v end
      if k == 'TYPE' and v and v ~= '' then type_ = v end
    end
    f:close()
  end
  return taskname_, type_
end

local function sanitizeTaskName(s)
  return (s:gsub('[\\/:%*%?"<>|]', '-'))   -- Task Scheduler forbids these characters in a task name
end

local function scheduleSummary()
  local names, count = {}, 0
  for i = 1, REPORT_COUNT do
    if selected[i] then count = count + 1; names[#names + 1] = REPORTS[i].label end
  end
  if dumpMode then return 'DUMP', count end
  if count == 1 then return names[1], count end
  return count .. ' Reports', count
end

-- With an explicit yyyy, mo, d: that exact date/time, no "next occurrence"
-- guessing. Without one: next occurrence of hh:mm from now (today if still
-- ahead, else tomorrow). Returns (RUNAT for the schedule file, a
-- human-readable label for the status line), or nil on an invalid date.
local function computeRunAt(hh, mm, yyyy, mo, d)
  local target
  if yyyy then
    local ok, t = pcall(os.time, {year=yyyy, month=mo, day=d, hour=tonumber(hh), min=tonumber(mm), sec=0})
    if not ok or not t then return nil end
    target = t
  else
    local now = os.time()
    target = os.time{year=tonumber(os.date('%Y')), month=tonumber(os.date('%m')),
                      day=tonumber(os.date('%d')), hour=tonumber(hh), min=tonumber(mm), sec=0}
    if target <= now then target = target + 86400 end
  end
  return os.date('%Y-%m-%d %H:%M:00', target), os.date('%Y-%m-%d %H:%M', target)
end

local VALID_DAYS = {Mon=true, Tue=true, Wed=true, Thu=true, Fri=true, Sat=true, Sun=true}

-- Only ever wired up (via Render(), see below) when 0 reports are selected.
function PrepareScheduleTask()
  setOpt('MeterIdmsScheduleStatus', 'Text', 'Pick at least one report first')
  setOpt('MeterIdmsScheduleStatus', 'FontColor', FAILC .. ',255')
end

-- Fires once Notepad has been launched for the draft file (chained directly
-- off the SAME static LeftMouseUpAction that opens it - see Render()).
-- IMPORTANT: this does NOT mean the user is done editing - confirmed live
-- that a bang chain waiting on notepad.exe to *exit* is unreliable in this
-- environment (Windows 11's Notepad can share a single process across
-- windows/tabs, so closing "a" notepad window doesn't reliably signal the
-- one just opened has closed, and the chained action fired almost
-- immediately with the file still at its default contents). Since
-- registering a schedule is a one-time, terminal action - unlike the
-- read-only preview refresh idms_range.txt/idms_dump_from.txt do, which is
-- harmless even if it fires early because it just redraws and gets
-- re-read next time regardless - it needs a REAL signal, not a guess. So
-- this just flips the SCHEDULE TASK button into "CONFIRM SCHEDULE" mode;
-- FinishScheduleTask() only ever runs on that explicit second click, once
-- the user has actually saved their edits themselves.
function OpenedScheduleDraft()
  awaitingScheduleConfirm = true
  setOpt('MeterIdmsScheduleStatus', 'Text', 'Edit TIME/PATH/REPEAT in Notepad, save it, then click CONFIRM SCHEDULE')
  setOpt('MeterIdmsScheduleStatus', 'FontColor', ACCENT .. ',255')
  Render()
end

function FinishScheduleTask()
  -- Reset immediately, before any validation - whether this attempt
  -- succeeds or fails, the button goes back to "SCHEDULE TASK" (opens
  -- Notepad again) rather than staying stuck offering CONFIRM SCHEDULE
  -- against a file the user may not still have open.
  awaitingScheduleConfirm = false
  local timeStr, pathStr, repeatStr, daysStr, everyStr, datefolderStr, dateStr, monthsStr, nameStr = readScheduleDraft()
  local hh, mm = timeStr:match('^(%d%d):(%d%d)$')
  if not hh or tonumber(hh) > 23 or tonumber(mm) > 59 then
    setOpt('MeterIdmsScheduleStatus', 'Text', 'Invalid TIME (' .. tostring(timeStr) .. ') - use 24-hour HH:MM, e.g. 09:00')
    setOpt('MeterIdmsScheduleStatus', 'FontColor', FAILC .. ',255')
    return
  end
  if repeatStr ~= 'once' and repeatStr ~= 'daily' and repeatStr ~= 'weekly' and repeatStr ~= 'monthly' and repeatStr ~= 'interval' then
    repeatStr = 'once'   -- bad/missing value defaults to the safest option, not a surprise recurrence
  end

  -- DATE= is optional for every REPEAT mode (an exact override of the
  -- "next occurrence of TIME=" default), but REQUIRED for monthly since
  -- that's also how the day-of-month gets picked. Validated up front so
  -- both the once/daily/weekly/interval "override" use and the monthly
  -- "required" use share one check.
  local yyyy, mo, dd = nil, nil, nil
  if dateStr and dateStr ~= '' then
    local y, m, d = dateStr:match('^(%d%d%d%d)%-(%d%d)%-(%d%d)$')
    if not y or tonumber(m) < 1 or tonumber(m) > 12 or tonumber(d) < 1 or tonumber(d) > 31 then
      setOpt('MeterIdmsScheduleStatus', 'Text', 'Invalid DATE (' .. dateStr .. ') - use YYYY-MM-DD, e.g. 2026-08-15, or leave blank')
      setOpt('MeterIdmsScheduleStatus', 'FontColor', FAILC .. ',255')
      return
    end
    yyyy, mo, dd = tonumber(y), tonumber(m), tonumber(d)
  elseif repeatStr == 'monthly' then
    -- No explicit DATE= given for a monthly schedule - fall back to today's
    -- day-of-month so "REPEAT=monthly" alone (no DATE=) still does
    -- something sane rather than erroring.
    yyyy, mo, dd = tonumber(os.date('%Y')), tonumber(os.date('%m')), tonumber(os.date('%d'))
  end

  local monthsN = nil
  if repeatStr == 'monthly' then
    monthsN = tonumber(monthsStr)
    if not monthsN or monthsN < 1 or monthsN ~= math.floor(monthsN) then
      setOpt('MeterIdmsScheduleStatus', 'Text', 'REPEAT=monthly needs MONTHS= set to a whole number of 1 or more, e.g. MONTHS=1')
      setOpt('MeterIdmsScheduleStatus', 'FontColor', FAILC .. ',255')
      return
    end
    -- Day 29/30/31 is allowed - Task Scheduler simply skips firing in a
    -- month that doesn't have that day (e.g. day 31 skips Feb/Apr/Jun/Sep/
    -- Nov), same as picking it in the Windows GUI does. dd is already
    -- known 1-31 from the DATE= regex match above.
  end

  local normalizedDays = nil
  if repeatStr == 'weekly' then
    local parts = {}
    for d in daysStr:gmatch('[^,]+') do
      local trimmed = d:match('^%s*(.-)%s*$')
      if trimmed ~= '' then parts[#parts + 1] = trimmed end
    end
    if #parts == 0 then
      setOpt('MeterIdmsScheduleStatus', 'Text', 'REPEAT=weekly needs DAYS= set, e.g. DAYS=Mon,Wed,Fri')
      setOpt('MeterIdmsScheduleStatus', 'FontColor', FAILC .. ',255')
      return
    end
    local valid = {}
    for _, d in ipairs(parts) do
      local norm = d:sub(1, 1):upper() .. d:sub(2, 3):lower()
      if not VALID_DAYS[norm] then
        setOpt('MeterIdmsScheduleStatus', 'Text', 'Invalid day "' .. d .. '" in DAYS= - use Mon,Tue,Wed,Thu,Fri,Sat,Sun')
        setOpt('MeterIdmsScheduleStatus', 'FontColor', FAILC .. ',255')
        return
      end
      valid[#valid + 1] = norm
    end
    normalizedDays = table.concat(valid, ',')
  end

  local everyMin = nil
  if repeatStr == 'interval' then
    everyMin = tonumber(everyStr)
    if not everyMin or everyMin < 5 then
      setOpt('MeterIdmsScheduleStatus', 'Text', 'REPEAT=interval needs EVERY= set to at least 5 (minutes), e.g. EVERY=120')
      setOpt('MeterIdmsScheduleStatus', 'FontColor', FAILC .. ',255')
      return
    end
    everyMin = math.floor(everyMin)
  end

  local outdir = (pathStr ~= '') and pathStr or nil
  if outdir then
    os.execute('mkdir "' .. outdir .. '" >nul 2>nul')
    local testf = outdir .. '\\.idms_write_test'
    local w = io.open(testf, 'w')
    if not w then
      setOpt('MeterIdmsScheduleStatus', 'Text', 'PATH is not writable: ' .. outdir)
      setOpt('MeterIdmsScheduleStatus', 'FontColor', FAILC .. ',255')
      return
    end
    w:close(); os.remove(testf)
  end

  -- Optional (default off): save into a DD-MM-YYYY subfolder instead of
  -- straight into PATH. Only meaningful with a PATH set - silently ignored
  -- otherwise. The actual date is computed fresh by IdmsDownload.py at the
  -- moment each run fires (not here at creation time), so a recurring
  -- schedule gets a new dated folder every time it runs, automatically.
  local datefolder = 'off'
  if outdir and (datefolderStr == 'today' or datefolderStr == 'yesterday') then
    datefolder = datefolderStr
  end

  local summary, count = scheduleSummary()
  if count == 0 then
    setOpt('MeterIdmsScheduleStatus', 'Text', 'Pick at least one report first')
    setOpt('MeterIdmsScheduleStatus', 'FontColor', FAILC .. ',255')
    return
  end

  local runAtFull, runAtLabel = computeRunAt(hh, mm, yyyy, mo, dd)
  if not runAtFull then
    setOpt('MeterIdmsScheduleStatus', 'Text', 'Invalid DATE (' .. tostring(dateStr) .. ') - that date does not exist, e.g. Feb 30')
    setOpt('MeterIdmsScheduleStatus', 'FontColor', FAILC .. ',255')
    return
  end
  local id = os.date('%Y%m%d%H%M%S')
  local scheduleFilePath = schedulesDir .. 'idms_schedule_' .. id .. '.txt'
  while io.open(scheduleFilePath, 'r') do   -- id collision guard (same-second creation)
    id = id .. 'x'
    scheduleFilePath = schedulesDir .. 'idms_schedule_' .. id .. '.txt'
  end
  local repeatTag = repeatStr
  if repeatStr == 'weekly' then repeatTag = 'Weekly ' .. normalizedDays end
  if repeatStr == 'interval' then repeatTag = 'Every ' .. everyMin .. 'min' end
  if repeatStr == 'monthly' then repeatTag = 'Every ' .. monthsN .. 'mo day' .. dd end
  -- A user-given NAME= (trimmed) wins over the auto-generated summary/
  -- repeat label - either way the unique id suffix stays, so two
  -- schedules can share the exact same NAME= (even across different PCs
  -- via the synced Downloads folder) without ever colliding: each
  -- schedule's own Task Scheduler registration and .txt file live only in
  -- THIS PC's %LOCALAPPDATA% (never synced), so nothing here is shared
  -- between machines in the first place.
  local trimmedName = nameStr:match('^%s*(.-)%s*$')
  local taskLabel
  if trimmedName ~= '' then
    taskLabel = trimmedName
  else
    taskLabel = sanitizeTaskName(summary) .. ' - ' .. sanitizeTaskName(repeatTag) .. ' ' .. hh .. mm
  end
  local taskName = 'IDMS Scheduled - ' .. sanitizeTaskName(taskLabel) .. ' (' .. id:sub(-6) .. ')'

  local list = {'mode=' .. mode, 'dump=' .. (dumpMode and '1' or '0'), 'combine=' .. (combineFiles and '1' or '0')}
  for i = 1, REPORT_COUNT do
    if selected[i] then list[#list + 1] = 'report=' .. REPORTS[i].key end
  end
  if outdir then list[#list + 1] = 'outdir=' .. outdir end
  if datefolder ~= 'off' then list[#list + 1] = 'datefolder=' .. datefolder end
  list[#list + 1] = 'RUNAT=' .. runAtFull
  list[#list + 1] = 'REPEAT=' .. repeatStr
  if normalizedDays then list[#list + 1] = 'DAYS=' .. normalizedDays end
  if everyMin then list[#list + 1] = 'EVERY=' .. everyMin end
  if repeatStr == 'monthly' then
    list[#list + 1] = 'MONTHS=' .. monthsN
    list[#list + 1] = 'DAYOFMONTH=' .. dd
  end
  list[#list + 1] = 'TASKNAME=' .. taskName
  list[#list + 1] = 'TASKPATH=\\IDMS Scheduled\\'
  local f = io.open(scheduleFilePath, 'w')
  if not f then
    setOpt('MeterIdmsScheduleStatus', 'Text', 'Could not write schedule file')
    setOpt('MeterIdmsScheduleStatus', 'FontColor', FAILC .. ',255')
    return
  end
  f:write(table.concat(list, '\r\n') .. '\r\n')
  f:close()

  pendingRegStatusFile = scheduleFilePath .. '.regstatus.txt'
  os.remove(pendingRegStatusFile)   -- clear any stale leftover before firing
  schedulingRegistration = true
  schedulingRegStartTime = os.time()
  scheduleResultShown = false
  setOpt('MeterIdmsScheduleStatus', 'Text', 'Scheduling "' .. summary .. '" for ' .. runAtLabel .. ' (' .. repeatStr .. ') - registering...')
  setOpt('MeterIdmsScheduleStatus', 'FontColor', ACCENT .. ',255')
  setOpt('MeasureIdmsScheduleReg', 'Parameter',
    '-NoProfile -ExecutionPolicy Bypass -File "' .. currentPath .. 'IdmsScheduleTask.ps1" -ScheduleFile "' .. scheduleFilePath .. '"')
  -- Confirmed live: without this, RunCommand's "Run" bang fired but never
  -- actually launched powershell.exe - no process, no regstatus.txt, stuck
  -- on "registering..." forever. !UpdateMeasure forces RunCommand to
  -- commit/reread the just-set Parameter before Run consumes it; the two
  -- other RunCommand measures in this skin (MeasureIdmsAvailScan,
  -- MeasureIdmsListSchedules) never hit this because their Parameter is
  -- static and never gets a fresh !SetOption right before Run.
  SKIN:Bang('!UpdateMeasure', 'MeasureIdmsScheduleReg')
  SKIN:Bang('!CommandMeasure', 'MeasureIdmsScheduleReg', 'Run')
end

local function pollScheduleReg()
  if not schedulingRegistration or not pendingRegStatusFile then return end
  if os.time() - schedulingRegStartTime > SCHEDULE_REG_TIMEOUT_SECS then
    schedulingRegistration = false
    scheduleResultShown = true
    setOpt('MeterIdmsScheduleStatus', 'Text', 'Timed out waiting for a result after ' .. SCHEDULE_REG_TIMEOUT_SECS .. 's - try SCHEDULE TASK again.')
    setOpt('MeterIdmsScheduleStatus', 'FontColor', FAILC .. ',255')
    Render()
    return
  end
  local f = io.open(pendingRegStatusFile, 'r')
  if not f then return end
  local s = {}
  for line in f:lines() do
    local k, v = line:match('^([^=]+)=(.*)$')
    if k then s[k] = v end
  end
  f:close()
  schedulingRegistration = false
  scheduleResultShown = true
  if s.status == 'OK' then
    setOpt('MeterIdmsScheduleStatus', 'Text', s.message or 'Scheduled')
    setOpt('MeterIdmsScheduleStatus', 'FontColor', OKC .. ',235')
  else
    setOpt('MeterIdmsScheduleStatus', 'Text', 'Scheduling failed: ' .. (s.message or 'unknown error'))
    setOpt('MeterIdmsScheduleStatus', 'FontColor', FAILC .. ',255')
  end
  -- Confirmed real bug: without this, MeterIdmsScheduleBtn stayed stuck
  -- showing "CONFIRM SCHEDULE" with its LeftMouseUpAction still bound to
  -- FinishScheduleTask() - awaitingScheduleConfirm was already false (set
  -- at the top of FinishScheduleTask()), but the button's Text/Action are
  -- only ever refreshed by Render(), and nothing called Render() again
  -- after this async result came in. A second click on the stuck button
  -- would have re-run FinishScheduleTask() against whatever the draft file
  -- happens to contain now.
  Render()
end

-- Only ever wired up (via Render(), see below) when 0 reports are selected,
-- or CREATE DUMP is on (not supported by EMAIL - it sends whatever files
-- already exist for a plain, non-dump selection).
function PrepareEmailTask()
  if dumpMode then
    setOpt('MeterIdmsEmailStatus', 'Text', 'EMAIL does not support CREATE DUMP selections - switch it off first')
  else
    setOpt('MeterIdmsEmailStatus', 'Text', 'Pick at least one report first')
  end
  setOpt('MeterIdmsEmailStatus', 'FontColor', FAILC .. ',255')
end

-- Same two-click confirm reasoning as OpenedScheduleDraft() - see that
-- function's comment.
function OpenedEmailDraft()
  awaitingEmailConfirm = true
  setOpt('MeterIdmsEmailStatus', 'Text', 'Edit TO/SUBJECT/BODY in Notepad, save it, then click CONFIRM EMAIL')
  setOpt('MeterIdmsEmailStatus', 'FontColor', ACCENT .. ',255')
  Render()
end

function FinishEmailTask()
  awaitingEmailConfirm = false
  local toStr, ccStr, subjectStr, bodyStr, timeStr, dateStr, repeatStr, daysStr, everyStr, monthsStr = readEmailDraft()

  local summary, count = scheduleSummary()
  if count == 0 then
    setOpt('MeterIdmsEmailStatus', 'Text', 'Pick at least one report first')
    setOpt('MeterIdmsEmailStatus', 'FontColor', FAILC .. ',255')
    return
  end
  if dumpMode then
    setOpt('MeterIdmsEmailStatus', 'Text', 'EMAIL does not support CREATE DUMP selections - switch it off first')
    setOpt('MeterIdmsEmailStatus', 'FontColor', FAILC .. ',255')
    return
  end

  local function parseAddrs(s)
    local list = {}
    for a in s:gmatch('[^,]+') do
      local trimmed = a:match('^%s*(.-)%s*$')
      if trimmed ~= '' then list[#list + 1] = trimmed end
    end
    return list
  end
  local toList = parseAddrs(toStr)
  if #toList == 0 then
    setOpt('MeterIdmsEmailStatus', 'Text', 'TO is required - at least one address')
    setOpt('MeterIdmsEmailStatus', 'FontColor', FAILC .. ',255')
    return
  end
  local ccList = parseAddrs(ccStr)
  for _, a in ipairs(toList) do
    if not a:match('^[^@%s]+@[^@%s]+%.[^@%s]+$') then
      setOpt('MeterIdmsEmailStatus', 'Text', 'Invalid address in TO: "' .. a .. '"')
      setOpt('MeterIdmsEmailStatus', 'FontColor', FAILC .. ',255')
      return
    end
  end
  for _, a in ipairs(ccList) do
    if not a:match('^[^@%s]+@[^@%s]+%.[^@%s]+$') then
      setOpt('MeterIdmsEmailStatus', 'Text', 'Invalid address in CC: "' .. a .. '"')
      setOpt('MeterIdmsEmailStatus', 'FontColor', FAILC .. ',255')
      return
    end
  end

  local subject = subjectStr:match('^%s*(.-)%s*$')
  if subject == '' then subject = 'IDMS DATA' end   -- optional, per explicit ask - never auto-derived from report names
  local body = bodyStr:match('^%s*(.-)%s*$')
  if body == '' then body = 'Please find the attached report(s) below.' end

  local trimmedTime = timeStr:match('^%s*(.-)%s*$')
  local isNow = trimmedTime:upper() == 'NOW'

  -- mode=/dump=0/combine=1 make this same file directly usable as an
  -- IdmsDownload.py --run-file too (dump is always 0 here - CREATE DUMP
  -- selections are already rejected above) - IdmsSendEmail.ps1 uses these
  -- to freshly download any selected report that isn't already sitting in
  -- the Downloads folder, rather than silently skipping it. Unrecognized
  -- keys (TO=/CC=/SUBJECT=/etc) are ignored by IdmsDownload.py's parser,
  -- same "one frozen file, multiple readers" pattern already used
  -- everywhere else in this codebase.
  local list = {'TO=' .. table.concat(toList, ','), 'CC=' .. table.concat(ccList, ','),
                'SUBJECT=' .. subject, 'BODY=' .. body,
                'mode=' .. mode, 'dump=0', 'combine=1'}
  for i = 1, REPORT_COUNT do
    if selected[i] then list[#list + 1] = 'report=' .. REPORTS[i].key end
  end

  local id = os.date('%Y%m%d%H%M%S')
  local jobFilePath = emailsDir .. 'idms_email_' .. id .. '.txt'
  while io.open(jobFilePath, 'r') do   -- id collision guard (same-second creation)
    id = id .. 'x'
    jobFilePath = emailsDir .. 'idms_email_' .. id .. '.txt'
  end

  if isNow then
    list[#list + 1] = 'REPEAT=once'
    local f = io.open(jobFilePath, 'w')
    if not f then
      setOpt('MeterIdmsEmailStatus', 'Text', 'Could not write email job file')
      setOpt('MeterIdmsEmailStatus', 'FontColor', FAILC .. ',255')
      return
    end
    f:write(table.concat(list, '\r\n') .. '\r\n')
    f:close()

    pendingEmailRegStatusFile = jobFilePath .. '.status.txt'
    os.remove(pendingEmailRegStatusFile)
    emailingInProgress = true
    emailingStartTime = os.time()
    emailingTimeoutSecs = EMAIL_SEND_TIMEOUT_SECS
    emailResultShown = false
    setOpt('MeterIdmsEmailStatus', 'Text', 'Sending "' .. summary .. '" to ' .. toList[1] .. (#toList > 1 and (' +' .. (#toList - 1)) or '') .. ' - opening Outlook...')
    setOpt('MeterIdmsEmailStatus', 'FontColor', ACCENT .. ',255')
    setOpt('MeasureIdmsSendEmailNow', 'Parameter',
      '-NoProfile -ExecutionPolicy Bypass -File "' .. currentPath .. 'IdmsSendEmail.ps1" -JobFile "' .. jobFilePath .. '"')
    SKIN:Bang('!UpdateMeasure', 'MeasureIdmsSendEmailNow')
    SKIN:Bang('!CommandMeasure', 'MeasureIdmsSendEmailNow', 'Run')
    return
  end

  -- Scheduled send - same validation as FinishScheduleTask(), duplicated
  -- rather than shared since the two flows diverge enough (no PATH/
  -- DATEFOLDER/outdir here, an extra isNow branch above) that threading a
  -- shared helper through both would need as many parameters as it saved.
  local hh, mm = trimmedTime:match('^(%d%d):(%d%d)$')
  if not hh or tonumber(hh) > 23 or tonumber(mm) > 59 then
    setOpt('MeterIdmsEmailStatus', 'Text', 'Invalid TIME (' .. tostring(timeStr) .. ') - use NOW, or 24-hour HH:MM e.g. 09:00')
    setOpt('MeterIdmsEmailStatus', 'FontColor', FAILC .. ',255')
    return
  end
  if repeatStr ~= 'once' and repeatStr ~= 'daily' and repeatStr ~= 'weekly' and repeatStr ~= 'monthly' and repeatStr ~= 'interval' then
    repeatStr = 'once'
  end

  local yyyy, mo, dd = nil, nil, nil
  if dateStr and dateStr ~= '' then
    local y, m, d = dateStr:match('^(%d%d%d%d)%-(%d%d)%-(%d%d)$')
    if not y or tonumber(m) < 1 or tonumber(m) > 12 or tonumber(d) < 1 or tonumber(d) > 31 then
      setOpt('MeterIdmsEmailStatus', 'Text', 'Invalid DATE (' .. dateStr .. ') - use YYYY-MM-DD, e.g. 2026-08-15, or leave blank')
      setOpt('MeterIdmsEmailStatus', 'FontColor', FAILC .. ',255')
      return
    end
    yyyy, mo, dd = tonumber(y), tonumber(m), tonumber(d)
  elseif repeatStr == 'monthly' then
    yyyy, mo, dd = tonumber(os.date('%Y')), tonumber(os.date('%m')), tonumber(os.date('%d'))
  end

  local monthsN = nil
  if repeatStr == 'monthly' then
    monthsN = tonumber(monthsStr)
    if not monthsN or monthsN < 1 or monthsN ~= math.floor(monthsN) then
      setOpt('MeterIdmsEmailStatus', 'Text', 'REPEAT=monthly needs MONTHS= set to a whole number of 1 or more, e.g. MONTHS=1')
      setOpt('MeterIdmsEmailStatus', 'FontColor', FAILC .. ',255')
      return
    end
  end

  local normalizedDays = nil
  if repeatStr == 'weekly' then
    local parts = {}
    for d in daysStr:gmatch('[^,]+') do
      local trimmed = d:match('^%s*(.-)%s*$')
      if trimmed ~= '' then parts[#parts + 1] = trimmed end
    end
    if #parts == 0 then
      setOpt('MeterIdmsEmailStatus', 'Text', 'REPEAT=weekly needs DAYS= set, e.g. DAYS=Mon,Wed,Fri')
      setOpt('MeterIdmsEmailStatus', 'FontColor', FAILC .. ',255')
      return
    end
    local valid = {}
    for _, d in ipairs(parts) do
      local norm = d:sub(1, 1):upper() .. d:sub(2, 3):lower()
      if not VALID_DAYS[norm] then
        setOpt('MeterIdmsEmailStatus', 'Text', 'Invalid day "' .. d .. '" in DAYS= - use Mon,Tue,Wed,Thu,Fri,Sat,Sun')
        setOpt('MeterIdmsEmailStatus', 'FontColor', FAILC .. ',255')
        return
      end
      valid[#valid + 1] = norm
    end
    normalizedDays = table.concat(valid, ',')
  end

  local everyMin = nil
  if repeatStr == 'interval' then
    everyMin = tonumber(everyStr)
    if not everyMin or everyMin < 5 then
      setOpt('MeterIdmsEmailStatus', 'Text', 'REPEAT=interval needs EVERY= set to at least 5 (minutes), e.g. EVERY=120')
      setOpt('MeterIdmsEmailStatus', 'FontColor', FAILC .. ',255')
      return
    end
    everyMin = math.floor(everyMin)
  end

  local runAtFull, runAtLabel = computeRunAt(hh, mm, yyyy, mo, dd)
  if not runAtFull then
    setOpt('MeterIdmsEmailStatus', 'Text', 'Invalid DATE (' .. tostring(dateStr) .. ') - that date does not exist, e.g. Feb 30')
    setOpt('MeterIdmsEmailStatus', 'FontColor', FAILC .. ',255')
    return
  end

  local repeatTag = repeatStr
  if repeatStr == 'weekly' then repeatTag = 'Weekly ' .. normalizedDays end
  if repeatStr == 'interval' then repeatTag = 'Every ' .. everyMin .. 'min' end
  if repeatStr == 'monthly' then repeatTag = 'Every ' .. monthsN .. 'mo day' .. dd end
  local taskName = 'IDMS Email - ' .. sanitizeTaskName(summary) .. ' to ' .. sanitizeTaskName(toList[1]) ..
    ' - ' .. sanitizeTaskName(repeatTag) .. ' ' .. hh .. mm .. ' (' .. id:sub(-6) .. ')'

  list[#list + 1] = 'RUNAT=' .. runAtFull
  list[#list + 1] = 'REPEAT=' .. repeatStr
  if normalizedDays then list[#list + 1] = 'DAYS=' .. normalizedDays end
  if everyMin then list[#list + 1] = 'EVERY=' .. everyMin end
  if repeatStr == 'monthly' then
    list[#list + 1] = 'MONTHS=' .. monthsN
    list[#list + 1] = 'DAYOFMONTH=' .. dd
  end
  list[#list + 1] = 'TASKNAME=' .. taskName
  -- A different Task Scheduler folder than downloads (\IDMS Scheduled\) -
  -- IdmsListSchedules.ps1 recognizes a schedule file only by its
  -- -ScheduleFile Action argument; an email task's -JobFile argument
  -- wouldn't match that, so without a separate folder an email task would
  -- show up in the downloads SCHEDULES summary as a broken empty entry.
  list[#list + 1] = 'TASKPATH=\\IDMS Email Scheduled\\'

  local f = io.open(jobFilePath, 'w')
  if not f then
    setOpt('MeterIdmsEmailStatus', 'Text', 'Could not write email job file')
    setOpt('MeterIdmsEmailStatus', 'FontColor', FAILC .. ',255')
    return
  end
  f:write(table.concat(list, '\r\n') .. '\r\n')
  f:close()

  pendingEmailRegStatusFile = jobFilePath .. '.regstatus.txt'
  os.remove(pendingEmailRegStatusFile)
  emailingInProgress = true
  emailingStartTime = os.time()
  emailingTimeoutSecs = EMAIL_REG_TIMEOUT_SECS
  emailResultShown = false
  setOpt('MeterIdmsEmailStatus', 'Text', 'Scheduling email "' .. summary .. '" for ' .. runAtLabel .. ' (' .. repeatStr .. ') - registering...')
  setOpt('MeterIdmsEmailStatus', 'FontColor', ACCENT .. ',255')
  setOpt('MeasureIdmsEmailReg', 'Parameter',
    '-NoProfile -ExecutionPolicy Bypass -File "' .. currentPath .. 'IdmsEmailScheduleTask.ps1" -JobFile "' .. jobFilePath .. '"')
  SKIN:Bang('!UpdateMeasure', 'MeasureIdmsEmailReg')
  SKIN:Bang('!CommandMeasure', 'MeasureIdmsEmailReg', 'Run')
end

local function pollEmailReg()
  if not emailingInProgress or not pendingEmailRegStatusFile then return end
  if os.time() - emailingStartTime > emailingTimeoutSecs then
    emailingInProgress = false
    emailResultShown = true
    setOpt('MeterIdmsEmailStatus', 'Text', 'Timed out waiting for a result after ' .. emailingTimeoutSecs .. 's - Outlook or the portal may be stuck. Check Task Manager, then try again.')
    setOpt('MeterIdmsEmailStatus', 'FontColor', FAILC .. ',255')
    Render()
    return
  end
  local f = io.open(pendingEmailRegStatusFile, 'r')
  if not f then return end
  local s = {}
  for line in f:lines() do
    local k, v = line:match('^([^=]+)=(.*)$')
    if k then s[k] = v end
  end
  f:close()
  -- RUNNING is progress, not a result - confirmed real bug this fixes:
  -- without this check, the very first "downloading reports before
  -- sending..." status line IdmsSendEmail.ps1 now writes early was itself
  -- being treated as a terminal (non-OK) result and shown as "Email
  -- failed: downloading reports before sending..." before the send had
  -- even started. Same pattern pollStatus() already uses for DOWNLOAD.
  if s.status == 'RUNNING' then
    setOpt('MeterIdmsEmailStatus', 'Text', (s.message or 'working') .. '...')
    setOpt('MeterIdmsEmailStatus', 'FontColor', ACCENT .. ',255')
    return
  end
  emailingInProgress = false
  emailResultShown = true
  if s.status == 'OK' then
    local msg = s.message or 'Done'
    setOpt('MeterIdmsEmailStatus', 'Text', msg)
    -- Some selected reports may not have had a downloaded file to attach
    -- (IdmsSendEmail.ps1 skips them rather than failing the whole send) -
    -- flagged with ACCENT instead of pure green OKC so a partial send is
    -- visually distinguishable from a complete one even before reading the
    -- (possibly clipped) text.
    if msg:match('skipped') then
      setOpt('MeterIdmsEmailStatus', 'FontColor', ACCENT .. ',255')
    else
      setOpt('MeterIdmsEmailStatus', 'FontColor', OKC .. ',235')
    end
    -- Reset the draft back to blank now that this attempt succeeded - see
    -- writeEmailDraftTemplate()'s comment for why this matters specifically
    -- for EMAIL (not done for SCHEDULE TASK's draft).
    writeEmailDraftTemplate()
  else
    setOpt('MeterIdmsEmailStatus', 'Text', 'Email failed: ' .. (s.message or 'unknown error'))
    setOpt('MeterIdmsEmailStatus', 'FontColor', FAILC .. ',255')
  end
  -- Same real bug/fix as pollScheduleReg() - see its comment. Without this,
  -- MeterIdmsEmailBtn stayed stuck on "CONFIRM EMAIL", still wired to
  -- FinishEmailTask(), after a send had already completed.
  Render()
end

function ViewEmails()
  if viewingEmails then return end
  viewingEmails = true
  os.remove(emailsSummaryStatusFile)
  setOpt('MeterIdmsEmailStatus', 'Text', 'Building email summary...')
  setOpt('MeterIdmsEmailStatus', 'FontColor', ACCENT .. ',255')
  SKIN:Bang('!CommandMeasure', 'MeasureIdmsListEmails', 'Run')
end

local function pollViewEmails()
  if not viewingEmails then return end
  local f = io.open(emailsSummaryStatusFile, 'r')
  if not f then return end
  f:close()
  viewingEmails = false
  SKIN:Bang('["notepad.exe" "' .. emailsSummaryFile .. '"]')
  Render()
end

-- Same two-click confirm pattern as SCHEDULE TASK/EMAIL, same reason - no
-- "0 selected" precondition here though, so unlike those two there's no
-- PrepareDeleteTask() error-only variant; the button always just opens the
-- draft.
function OpenedDeleteDraft()
  awaitingDeleteConfirm = true
  setOpt('MeterIdmsDeleteStatus', 'Text', 'Paste the exact TASKNAME, set TYPE, save it, then click CONFIRM DELETE')
  setOpt('MeterIdmsDeleteStatus', 'FontColor', ACCENT .. ',255')
  Render()
end

function FinishDeleteTask()
  awaitingDeleteConfirm = false
  local taskname, type_ = readDeleteDraft()
  local trimmedName = taskname:match('^%s*(.-)%s*$')
  if trimmedName == '' then
    setOpt('MeterIdmsDeleteStatus', 'Text', 'TASKNAME is required - paste the exact name from SCHEDULES or EMAILS')
    setOpt('MeterIdmsDeleteStatus', 'FontColor', FAILC .. ',255')
    return
  end
  if type_ ~= 'schedule' and type_ ~= 'email' then
    setOpt('MeterIdmsDeleteStatus', 'Text', 'Invalid TYPE (' .. tostring(type_) .. ') - use schedule or email')
    setOpt('MeterIdmsDeleteStatus', 'FontColor', FAILC .. ',255')
    return
  end

  os.remove(deleteStatusFile)   -- clear any stale leftover before firing
  deletingInProgress = true
  deleteResultShown = false
  setOpt('MeterIdmsDeleteStatus', 'Text', 'Deleting "' .. trimmedName .. '"...')
  setOpt('MeterIdmsDeleteStatus', 'FontColor', ACCENT .. ',255')
  setOpt('MeasureIdmsDeleteTask', 'Parameter',
    '-NoProfile -ExecutionPolicy Bypass -File "' .. currentPath .. 'IdmsDeleteTask.ps1" -TaskName "' .. trimmedName .. '" -Type ' .. type_)
  SKIN:Bang('!UpdateMeasure', 'MeasureIdmsDeleteTask')
  SKIN:Bang('!CommandMeasure', 'MeasureIdmsDeleteTask', 'Run')
end

local function pollDeleteReg()
  if not deletingInProgress then return end
  local f = io.open(deleteStatusFile, 'r')
  if not f then return end
  local s = {}
  for line in f:lines() do
    local k, v = line:match('^([^=]+)=(.*)$')
    if k then s[k] = v end
  end
  f:close()
  deletingInProgress = false
  deleteResultShown = true
  if s.status == 'OK' then
    setOpt('MeterIdmsDeleteStatus', 'Text', s.message or 'Deleted')
    setOpt('MeterIdmsDeleteStatus', 'FontColor', OKC .. ',235')
  else
    setOpt('MeterIdmsDeleteStatus', 'Text', 'Delete failed: ' .. (s.message or 'unknown error'))
    setOpt('MeterIdmsDeleteStatus', 'FontColor', FAILC .. ',255')
  end
  -- Same fix as pollScheduleReg()/pollEmailReg() - refresh the button back
  -- from "CONFIRM DELETE" now that this attempt is done.
  Render()
end

function ViewSchedules()
  if viewingSchedules then return end
  viewingSchedules = true
  os.remove(schedulesSummaryStatusFile)   -- clear any stale leftover before firing
  setOpt('MeterIdmsScheduleStatus', 'Text', 'Building schedule summary...')
  setOpt('MeterIdmsScheduleStatus', 'FontColor', ACCENT .. ',255')
  SKIN:Bang('!CommandMeasure', 'MeasureIdmsListSchedules', 'Run')
end

local function pollViewSchedules()
  if not viewingSchedules then return end
  local f = io.open(schedulesSummaryStatusFile, 'r')
  if not f then return end
  f:close()
  viewingSchedules = false
  -- Fire-and-forget open (unlike the SCHEDULE TASK flow, nothing needs to
  -- run AFTER Notepad closes here, so the nested-Bang blocking quirk that
  -- affected FinishScheduleTask() doesn't apply / doesn't matter).
  SKIN:Bang('["notepad.exe" "' .. schedulesSummaryFile .. '"]')
  Render()
end

function Update()
  pollStatus()
  pollAvailStatus()
  pollScheduleReg()
  pollViewSchedules()
  pollEmailReg()
  pollViewEmails()
  pollDeleteReg()
  return 1
end
