"""Diagnostic: does the date filter on docket-cancellation actually restrict
results, or is page_has_data() seeing stale/unfiltered rows regardless of
the from/to values? Probe a range that should definitely be empty (2019)."""
import sys
sys.path.insert(0, r"e:\ibnd\AutomationReminder\Downloads")
import IdmsDownload as idms

def main():
    user, pw = idms.read_creds()
    from playwright.sync_api import sync_playwright
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=True)
        ctx = browser.new_context(accept_downloads=True)
        page = ctx.new_page()
        page.goto(idms.LOGIN_URL, timeout=30000)
        idms.try_fill(page, idms.SEL_USER, user)
        idms.try_fill(page, idms.SEL_PASS, pw)
        page.click(idms.SEL_LOGIN, timeout=8000)
        page.wait_for_load_state("networkidle", timeout=20000)
        cfg = idms.REPORTS["docket_cancellation"]
        idms.goto_report(page, cfg)

        result_2019 = idms.page_has_data(page, cfg, "2019-01-01", "2019-01-31")
        print(f"page_has_data() for 2019-01 range: {result_2019}")

        idms.goto_report(page, cfg)
        result_now = idms.page_has_data(page, cfg, *idms.month_offset_to_range(0))
        print(f"page_has_data() for this month: {result_now}")
        browser.close()

if __name__ == "__main__":
    main()
