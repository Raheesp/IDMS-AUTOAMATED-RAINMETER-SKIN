import sys, re
sys.path.insert(0, r"e:\ibnd\AutomationReminder\Downloads")
import IdmsDownload as idms

def main():
    user, pw = idms.read_creds()
    from playwright.sync_api import sync_playwright
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=True)
        ctx = browser.new_context(accept_downloads=True)
        page = ctx.new_page()
        page.goto(idms.LOGIN_URL, timeout=30000)
        idms.try_fill(page, idms.SEL_USER, user)
        idms.try_fill(page, idms.SEL_PASS, pw)
        page.click(idms.SEL_LOGIN, timeout=8000)
        page.wait_for_load_state("networkidle", timeout=20000)
        if idms.LOGIN_MARKER in page.url.lower():
            print("LOGIN FAILED")
            return

        cfg = idms.REPORTS["docket_cancellation"]
        idms.goto_report(page, cfg)
        idms.try_fill(page, cfg["df"], "2015-01-01")
        idms.try_fill(page, cfg["dt"], "2026-07-24")
        idms.click_text(page, cfg["filt"], timeout=6000)
        rows = page.locator("table tbody tr")
        for _ in range(30):
            page.wait_for_timeout(1000)
            c = rows.count()
            t = rows.first.inner_text()[:40] if c else ""
            if c and "loading" not in t.lower():
                break

        print("total rows on page:", rows.count())
        print("FULL first row text:\n", rows.first.inner_text())
        print("---")
        print("FULL last row text:\n", rows.last.inner_text())

        # look for pagination info / total record count text anywhere on page
        body = page.locator("body").inner_text()
        for line in body.split("\n"):
            if re.search(r"showing|total|of \d+|page", line, re.I) and len(line) < 150:
                print("PAGINATION HINT:", line)

        # look for sortable date column headers
        headers = page.locator("table thead th")
        for i in range(headers.count()):
            print("HEADER:", headers.nth(i).inner_text())

        browser.close()

if __name__ == "__main__":
    main()
