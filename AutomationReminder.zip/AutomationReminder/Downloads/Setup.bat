@echo off
REM ==========================================================================
REM  Setup.bat  -  double-click to install the Portal Data downloader.
REM  Right-click -> "Run as administrator" is recommended (for pip + the task).
REM ==========================================================================
title Portal Data - Setup
echo Installing the Portal Data downloader (Python deps, schedule, credentials)...
echo.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Setup.ps1"
echo.
echo ==========================================================================
echo  If you saw "DONE" above, setup is complete. Otherwise read the message.
echo ==========================================================================
pause
