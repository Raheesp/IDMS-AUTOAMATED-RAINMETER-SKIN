# ============================================================================
#  IdmsListSchedules.ps1  -  builds a human-readable summary of every IDMS
#  scheduled download, cross-referencing live Task Scheduler state (next
#  run, last run, last result) with the actual schedule file each task
#  points at (reports, output path, repeat pattern) - Task Scheduler's own
#  UI shows the former but not the latter, and vice versa for a plain read
#  of the schedule files, so this merges both into one place.
# ----------------------------------------------------------------------------
#  The schedule file path is recovered from each task's own Action
#  arguments (-ScheduleFile "<path>") - no separate mapping file needed,
#  it's the single source of truth already.
#  Writes idms_schedules_summary.txt, then a small status file so the Lua
#  side knows when it's ready to open.
# ============================================================================

$ErrorActionPreference = 'SilentlyContinue'
$appDir = Join-Path $env:LOCALAPPDATA 'AutomationReminder'
if (-not (Test-Path $appDir)) { New-Item -ItemType Directory -Path $appDir -Force | Out-Null }
$summaryFile = Join-Path $appDir 'idms_schedules_summary.txt'
$statusFile  = Join-Path $appDir 'idms_schedules_summary_status.txt'

function Read-ScheduleFile($path) {
    $meta = @{
        mode = 'asis'; dump = $false; combine = $true; outdir = $null; datefolder = 'off'
        reports = @(); REPEAT = 'once'; DAYS = $null; EVERY = $null; MONTHS = $null; DAYOFMONTH = $null; RUNAT = $null
    }
    if (-not (Test-Path $path)) { return $meta }
    foreach ($line in Get-Content $path) {
        if ($line -notmatch '=') { continue }
        $k, $v = $line -split '=', 2
        $k = $k.Trim(); $v = $v.Trim()
        switch ($k) {
            'mode'       { $meta.mode = $v }
            'dump'       { $meta.dump = ($v -eq '1') }
            'combine'    { $meta.combine = ($v -eq '1') }
            'outdir'     { $meta.outdir = $v }
            'datefolder' { $meta.datefolder = $v }
            'report'     { $meta.reports += $v }
            'REPEAT'     { $meta.REPEAT = $v }
            'DAYS'       { $meta.DAYS = $v }
            'EVERY'      { $meta.EVERY = $v }
            'MONTHS'     { $meta.MONTHS = $v }
            'DAYOFMONTH' { $meta.DAYOFMONTH = $v }
            'RUNAT'      { $meta.RUNAT = $v }
        }
    }
    return $meta
}

function Format-Repeat($meta) {
    switch ($meta.REPEAT) {
        'daily'    { return "Daily" }
        'weekly'   { return "Weekly on $($meta.DAYS)" }
        'monthly'  { return "Every $($meta.MONTHS) month(s) on day $($meta.DAYOFMONTH)" }
        'interval' { return "Every $($meta.EVERY) min, all day" }
        default    { return "Once" }
    }
}

function Format-Path($meta) {
    if (-not $meta.outdir) { return "(default Downloads folder)" }
    $p = $meta.outdir
    if ($meta.datefolder -eq 'today')     { return "$p  (dated subfolder created each run - today's date)" }
    if ($meta.datefolder -eq 'yesterday') { return "$p  (dated subfolder created each run - yesterday's date)" }
    return $p
}

function Format-Reports($meta) {
    $tag = ''
    if ($meta.dump) { $tag = if ($meta.combine) { ' (dump, combined into 1 file)' } else { ' (dump, kept separate per month)' } }
    if ($meta.reports.Count -eq 0) { return "(none listed)$tag" }
    return ($meta.reports -join ', ') + $tag
}

$tasks = Get-ScheduledTask -TaskPath '\IDMS Scheduled\' -ErrorAction SilentlyContinue |
    Sort-Object TaskName

$lines = New-Object System.Collections.Generic.List[string]
$lines.Add("IDMS SCHEDULED DOWNLOADS")
$lines.Add("as of $(Get-Date -Format 'yyyy-MM-dd HH:mm')")
$lines.Add("")

if (-not $tasks -or $tasks.Count -eq 0) {
    $lines.Add("No schedules yet.")
    $lines.Add("")
    $lines.Add("Select reports in the panel, click SCHEDULE TASK, and set a time.")
} else {
    $i = 0
    foreach ($t in $tasks) {
        $i++
        $info = $t | Get-ScheduledTaskInfo -ErrorAction SilentlyContinue
        $arg = $t.Actions[0].Arguments
        $scheduleFile = $null
        if ($arg -match '-ScheduleFile\s+"([^"]+)"') { $scheduleFile = $matches[1] }
        $meta = if ($scheduleFile) { Read-ScheduleFile $scheduleFile } else { Read-ScheduleFile '' }

        $lastRun = "never run yet"
        # Task Scheduler's "never run" sentinel is LastTaskResult 267011
        # (SCHED_S_TASK_HAS_NOT_RUN) with LastRunTime pinned at 1999-11-30 -
        # LastRunTime is a real DateTime (never $null), so a plain truthy
        # check on it always passes and would otherwise print that sentinel
        # date/code as if it were a genuine failed run. Confirmed live: a
        # freshly-registered, never-fired daily/weekly/monthly/interval task
        # showed "Last run: 11/30/1999 (exit code 267011 ...)" instead of
        # "never run yet".
        if ($info -and $info.LastTaskResult -ne 267011 -and $info.LastRunTime -gt [datetime]'1901-01-01') {
            $result = if ($null -ne $info.LastTaskResult -and $info.LastTaskResult -eq 0) { "succeeded" }
                      elseif ($null -ne $info.LastTaskResult) { "exit code $($info.LastTaskResult) - check idms_status.txt / the schedule's own .status.txt for details" }
                      else { "unknown result" }
            $lastRun = "$($info.LastRunTime)  ($result)"
        }
        $nextRun = "not scheduled to run again"
        if ($info -and $info.NextRunTime -and $t.State -ne 'Disabled') { $nextRun = "$($info.NextRunTime)" }
        if ($t.State -eq 'Disabled') { $nextRun = "DISABLED in Task Scheduler" }

        $lines.Add(("=" * 78))
        $lines.Add("$i. $($t.TaskName)")
        $lines.Add(("=" * 78))
        $lines.Add("   Repeats:   $(Format-Repeat $meta)")
        $lines.Add("   Reports:   $(Format-Reports $meta)")
        $lines.Add("   Save to:   $(Format-Path $meta)")
        $lines.Add("   Next run:  $nextRun")
        $lines.Add("   Last run:  $lastRun")
        $lines.Add("")
    }
}

$lines.Add(("-" * 78))
$lines.Add("To enable, disable, or delete a schedule directly, open Task Scheduler")
$lines.Add("and look under Task Scheduler Library > IDMS Scheduled.")

[IO.File]::WriteAllLines($summaryFile, $lines, (New-Object System.Text.UTF8Encoding($false)))
[IO.File]::WriteAllLines($statusFile, @("status=OK", "time=$([DateTimeOffset]::UtcNow.ToUnixTimeSeconds())"), (New-Object System.Text.UTF8Encoding($false)))
