-- ============================================================================
--  DownloadEngine.lua  -  engine for the PORTAL DATA bar
--  Reads the machine-local status file written by AutoDownload.py and drives
--  the counts, status line, failure banner and the Update-password button.
--  Theme-aware: Accent/Dim are read from the active theme at load.
-- ============================================================================

local statusFile, credsPath = nil, nil
local ACCENT = "255,186,110"   -- overwritten from the theme in Initialize
local DIM    = "182,168,158"
local OKC    = "122,214,178"   -- green  (same across themes)
local FAILC  = "255,95,95"     -- red    (same across themes)

local function setOpt(m, o, v) SKIN:Bang('!SetOption', m, o, v) end
local function fmtClock(tt) return (os.date("%I:%M %p", tt):gsub("^0", "")) end

function Initialize()
  ACCENT = SKIN:GetVariable('Accent') or ACCENT
  DIM    = SKIN:GetVariable('Dim')    or DIM
  local la   = os.getenv('LOCALAPPDATA') or SKIN:GetVariable('CURRENTPATH')
  local base = la .. '\\AutomationReminder\\'
  statusFile = base .. '_downloads.txt'
  credsPath  = base .. 'creds.txt'
  -- point the "UPDATE PASSWORD" button at the machine-local creds file
  setOpt('MeterBtnPass', 'LeftMouseUpAction', '["notepad.exe" "' .. credsPath .. '"]')
end

local function readStatus()
  local f = io.open(statusFile, 'r')
  if not f then return nil end
  local m = {}
  for line in f:lines() do
    local k, v = line:match("^([^=]+)=(.*)$")
    if k then m[k] = v end
  end
  f:close()
  return m
end

local function setCount(meter, val)
  setOpt(meter, 'Text', (val ~= nil and val ~= '') and val or '-')
end

function Update()
  local s = readStatus()
  if not s then
    setOpt('MeterStatus', 'Text', 'No data yet - click RUN NOW')
    setOpt('MeterStatus', 'FontColor', DIM .. ',220')
    setOpt('MeterBanner', 'Text', '')
    return 1
  end

  local st = s.status or ''
  local t  = tonumber(s.time)

  -- while running OR waiting for a clear slot, keep the last counts on screen -
  if st == 'RUNNING' or st == 'DEFERRED' then
    setOpt('MeterStatus', 'Text', st == 'DEFERRED' and 'Waiting for a clear slot...' or 'Running download...')
    setOpt('MeterStatus', 'FontColor', ACCENT .. ',255')
    setOpt('MeterBanner', 'Text', (st == 'DEFERRED' and s.message ~= nil and s.message ~= '') and s.message or '')
    setOpt('MeterBanner', 'FontColor', DIM .. ',220')
    return 1
  end

  setCount('MeterCntBooking', s.booking)
  setCount('MeterCntDocket',  s.docket)
  setCount('MeterCntEnquiry', s.enquiry)

  if st == 'OK' then
    setOpt('MeterStatus', 'Text', t and ('Updated ' .. fmtClock(t)) or 'Updated')
    setOpt('MeterStatus', 'FontColor', OKC .. ',235')
    setOpt('MeterBanner', 'Text', '')
  elseif st == 'AUTH_FAILED' or st == 'NO_CREDS' then
    setOpt('MeterStatus', 'Text', 'Login failed' .. (t and (' at ' .. fmtClock(t)) or ''))
    setOpt('MeterStatus', 'FontColor', FAILC .. ',255')
    setOpt('MeterBanner', 'Text', 'Password may have changed - click UPDATE PASSWORD, then RUN NOW')
    setOpt('MeterBanner', 'FontColor', FAILC .. ',255')
  elseif st == 'UNREACHABLE' then
    setOpt('MeterStatus', 'Text', 'Portal unreachable' .. (t and (' at ' .. fmtClock(t)) or ''))
    setOpt('MeterStatus', 'FontColor', FAILC .. ',235')
    setOpt('MeterBanner', 'Text', 'Check network / VPN. If it persists, the password may have changed.')
    setOpt('MeterBanner', 'FontColor', FAILC .. ',235')
  else
    setOpt('MeterStatus', 'Text', 'Error' .. (t and (' at ' .. fmtClock(t)) or ''))
    setOpt('MeterStatus', 'FontColor', FAILC .. ',255')
    setOpt('MeterBanner', 'Text', (s.message ~= nil and s.message ~= '') and s.message or 'Unknown error')
    setOpt('MeterBanner', 'FontColor', FAILC .. ',235')
  end
  return 1
end
