-- ============================================================================
--  DownloadEngine.lua  -  engine for the PORTAL DATA bar
--  Reads the machine-local status file written by AutoDownload.py and drives
--  the counts, status line, failure banner and the Update-password button.
--  Theme-aware: Accent/Dim are read from the active theme at load.
--
--  The bar itself comes from the active DESIGN (@Resources\Bars\Portal\*.inc).
--  Besides the core meters every design has, a design may add any of these
--  optional pieces, filled here when present (see @Resources\Widgets.lua):
--    MeterStateBlk / MeterStateTxt   block in the status colour + OK/RUN/ERR
--    MeterStateDot                   dot in the status colour
--    MeterTile                       tile filled with the status colour
--    MeterCntBar<Name>               bar per count, scaled to the largest count
--    MeterCntArc<Name>               ring per count, scaled the same way
-- ============================================================================

local statusFile, credsPath = nil, nil
local ACCENT = "255,186,110"   -- overwritten from the theme in Initialize
local DIM    = "182,168,158"
local OKC    = "122,214,178"   -- green  (same across themes)
local FAILC  = "255,95,95"     -- red    (same across themes)
local W = nil                  -- shared widgets (guarded setters, arcs)
local tint = true              -- false on designs whose status sits on a coloured tile

local function setOpt(m, o, v)
  if W then W.set(m, o, v) else SKIN:Bang('!SetOption', m, o, v) end
end
local function fmtClock(tt) return (os.date("%I:%M %p", tt):gsub("^0", "")) end

function Initialize()
  W = dofile(SKIN:GetVariable('@') .. 'Widgets.lua')
  ACCENT = SKIN:GetVariable('Accent') or ACCENT
  DIM    = SKIN:GetVariable('Dim')    or DIM
  tint   = (SKIN:GetVariable('FixedTextColor') or '0') ~= '1'
  local la   = os.getenv('LOCALAPPDATA') or SKIN:GetVariable('CURRENTPATH')
  local base = la .. '\\AutomationReminder\\'
  statusFile = base .. '_downloads.txt'
  credsPath  = base .. 'creds.txt'
  -- point the "UPDATE PASSWORD" button at the machine-local creds file
  setOpt('MeterBtnPass', 'LeftMouseUpAction', '["notepad.exe" "' .. credsPath .. '"]')
end

local function readStatus()
  local f = io.open(statusFile, 'r')
  if not f then return nil end
  local m = {}
  for line in f:lines() do
    local k, v = line:match("^([^=]+)=(.*)$")
    if k then m[k] = v end
  end
  f:close()
  return m
end

local NAMES = { 'Booking', 'Docket', 'Enquiry' }

-- counts + the optional per-count bars / rings --------------------------------
local function showCounts(s)
  local vals, max = {}, 0
  for _, n in ipairs(NAMES) do
    local v = s[n:lower()]
    setOpt('MeterCnt' .. n, 'Text', (v ~= nil and v ~= '') and v or '-')
    vals[n] = tonumber(v) or 0
    if vals[n] > max then max = vals[n] end
  end
  local bw, bh = W.num('CntBarW', 120), W.num('CntBarH', 4)
  for _, n in ipairs(NAMES) do
    local frac = max > 0 and vals[n] / max or 0
    if W.has('MeterCntBar' .. n) then
      local w = math.floor(frac * bw)
      setOpt('MeterCntBar' .. n, 'Shape', w < 2 and 'Rectangle 0,0,0,0 | StrokeWidth 0' or
        ('Rectangle 0,0,' .. w .. ',' .. bh .. ',' .. (bh / 2) .. ' | Fill Color ' .. ACCENT .. ',255 | StrokeWidth 0'))
    end
    if W.has('MeterCntArc' .. n) then
      setOpt('MeterCntArc' .. n, 'Shape', W.arc(frac, ACCENT, W.num('Arc' .. n .. 'X', 20), W.num('ArcY', 22), W.num('ArcR', 16), W.num('ArcSW', 3)))
    end
  end
end

-- status colour pieces ------------------------------------------------------------
local function paintState(color, word)
  if W.has('MeterStateBlk') then
    setOpt('MeterStateBlk', 'Shape', 'Rectangle 0.5,' .. W.num('BlkY', 0.5) .. ',' .. W.num('BlkW', 56) .. ',' .. W.num('BlkH', 43) ..
      ',' .. W.num('BlkR', 10) .. ' | Fill Color ' .. color .. ',235 | StrokeWidth 0')
  end
  setOpt('MeterStateTxt', 'Text', word)
  setOpt('MeterStateDot', 'Shape', 'Ellipse 4,4,3.5 | Fill Color ' .. color .. ',255 | StrokeWidth 0')
  if W.has('MeterTile') then
    setOpt('MeterTile', 'Shape', 'Rectangle 0,' .. W.num('TileY', 0) .. ',' .. W.num('TileW', 120) .. ',' .. W.num('TileH', 44) .. ',' ..
      W.num('TileR', 2) .. ' | Fill Color ' .. color .. ',240 | StrokeWidth 0')
  end
end

local function status(text, color, alpha)
  setOpt('MeterStatus', 'Text', text)
  if tint then setOpt('MeterStatus', 'FontColor', color .. ',' .. (alpha or '235')) end
end

function Update()
  local s = readStatus()
  if not s then
    status('No data yet - click RUN NOW', DIM, '220')
    setOpt('MeterBanner', 'Text', '')
    paintState(DIM, '--')
    return 1
  end

  local st = s.status or ''
  local t  = tonumber(s.time)
  local good = tonumber(s.goodtime)
  local from = good and (' - showing ' .. fmtClock(good) .. ' data') or ''
  showCounts(s)
  setOpt('MeterStatus', 'ToolTipText', (s.message ~= nil and s.message ~= '') and s.message or 'Booking / Docket / Enquiry for this month')

  -- while running OR waiting for a clear slot, the last good counts stay up --
  if st == 'RUNNING' or st == 'DEFERRED' then
    status(st == 'DEFERRED' and 'Waiting for a clear slot...' or 'Running download...', ACCENT, '255')
    setOpt('MeterBanner', 'Text', (s.message ~= nil and s.message ~= '') and s.message or '')
    setOpt('MeterBanner', 'FontColor', DIM .. ',220')
    paintState(ACCENT, 'RUN')
    return 1
  end

  if st == 'OK' then
    status(t and ('Updated ' .. fmtClock(t)) or 'Updated', OKC)
    setOpt('MeterBanner', 'Text', (s.message ~= nil and s.message ~= '') and s.message or '')
    setOpt('MeterBanner', 'FontColor', DIM .. ',220')
    paintState(OKC, 'OK')
    return 1
  end

  local word = 'ERR'
  if st == 'AUTH_FAILED' or st == 'NO_CREDS' then
    status('Login failed' .. (t and (' at ' .. fmtClock(t)) or '') .. from, FAILC, '255')
    word = 'LOGIN'
  elseif st == 'UNREACHABLE' then
    status('Portal unreachable' .. (t and (' at ' .. fmtClock(t)) or '') .. from, FAILC)
    word = 'NET'
  else
    status('Error' .. (t and (' at ' .. fmtClock(t)) or '') .. from, FAILC, '255')
  end
  -- the downloader's own reason (e.g. "wrong username or password", "portal
  -- did not answer") instead of always guessing at the password
  local msg = (s.message ~= nil and s.message ~= '') and s.message or 'Unknown error'
  if st == 'NO_CREDS' then msg = 'No login saved - click UPDATE PASSWORD, then RUN NOW' end
  setOpt('MeterBanner', 'Text', msg)
  setOpt('MeterBanner', 'FontColor', FAILC .. ',255')
  paintState(FAILC, word)
  return 1
end
