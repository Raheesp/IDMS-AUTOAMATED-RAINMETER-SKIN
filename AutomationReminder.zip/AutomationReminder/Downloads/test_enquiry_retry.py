import sys, os
sys.path.insert(0, r"e:\ibnd\AutomationReminder\Downloads")
import IdmsDownload as idms

def main():
    user, pw = idms.read_creds()
    from playwright.sync_api import sync_playwright
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=True)
        ctx = browser.new_context(accept_downloads=True)
        page = ctx.new_page()
        if not idms.do_login(page, user, pw):
            print("LOGIN FAILED")
            return

        os.makedirs(idms.PROBE_DIR, exist_ok=True)
        cfg = idms.REPORTS["enquiry"]
        d_from, d_to = idms.month_offset_to_range(0)
        for attempt in range(1, 4):
            idms.goto_report(page, cfg)
            res = idms.do_one(page, "enquiry", cfg, "month", d_from, d_to, suffix=f"_r{attempt}", out_dir=idms.PROBE_DIR, out_name="enquiry")
            print(f"attempt {attempt}:", res)

        browser.close()

if __name__ == "__main__":
    main()
