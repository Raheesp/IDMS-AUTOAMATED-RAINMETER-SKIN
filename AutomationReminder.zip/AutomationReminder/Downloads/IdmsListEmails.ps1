# ============================================================================
#  IdmsListEmails.ps1  -  builds a human-readable summary of every IDMS
#  scheduled email, cross-referencing live Task Scheduler state (next run,
#  last run, last result) with the actual job file each task points at
#  (recipients, subject, reports, repeat pattern) - same idea as
#  IdmsListSchedules.ps1, for the separate \IDMS Email Scheduled\ folder.
# ----------------------------------------------------------------------------
#  The job file path is recovered from each task's own Action arguments
#  (-JobFile "<path>") - no separate mapping file needed.
#  Writes idms_emails_summary.txt, then a small status file so the Lua side
#  knows when it's ready to open.
# ============================================================================

$ErrorActionPreference = 'SilentlyContinue'
$appDir = Join-Path $env:LOCALAPPDATA 'AutomationReminder'
if (-not (Test-Path $appDir)) { New-Item -ItemType Directory -Path $appDir -Force | Out-Null }
$summaryFile = Join-Path $appDir 'idms_emails_summary.txt'
$statusFile  = Join-Path $appDir 'idms_emails_summary_status.txt'

function Read-JobFile($path) {
    $meta = @{
        TO = ''; CC = ''; SUBJECT = ''; reports = @()
        REPEAT = 'once'; DAYS = $null; EVERY = $null; MONTHS = $null; DAYOFMONTH = $null
    }
    if (-not (Test-Path $path)) { return $meta }
    foreach ($line in Get-Content $path) {
        if ($line -notmatch '=') { continue }
        $k, $v = $line -split '=', 2
        $k = $k.Trim(); $v = $v.Trim()
        switch ($k) {
            'TO'         { $meta.TO = $v }
            'CC'         { $meta.CC = $v }
            'SUBJECT'    { $meta.SUBJECT = $v }
            'report'     { $meta.reports += $v }
            'REPEAT'     { $meta.REPEAT = $v }
            'DAYS'       { $meta.DAYS = $v }
            'EVERY'      { $meta.EVERY = $v }
            'MONTHS'     { $meta.MONTHS = $v }
            'DAYOFMONTH' { $meta.DAYOFMONTH = $v }
        }
    }
    return $meta
}

function Format-Repeat($meta) {
    switch ($meta.REPEAT) {
        'daily'    { return "Daily" }
        'weekly'   { return "Weekly on $($meta.DAYS)" }
        'monthly'  { return "Every $($meta.MONTHS) month(s) on day $($meta.DAYOFMONTH)" }
        'interval' { return "Every $($meta.EVERY) min, all day" }
        default    { return "Once" }
    }
}

function Format-Recipients($meta) {
    $s = $meta.TO
    if ($meta.CC) { $s += "  (cc: $($meta.CC))" }
    if (-not $s) { return "(none listed)" }
    return $s
}

function Format-Reports($meta) {
    if ($meta.reports.Count -eq 0) { return "(none listed)" }
    return ($meta.reports -join ', ')
}

$tasks = Get-ScheduledTask -TaskPath '\IDMS Email Scheduled\' -ErrorAction SilentlyContinue |
    Sort-Object TaskName

$lines = New-Object System.Collections.Generic.List[string]
$lines.Add("IDMS SCHEDULED EMAILS")
$lines.Add("as of $(Get-Date -Format 'yyyy-MM-dd HH:mm')")
$lines.Add("")

if (-not $tasks -or $tasks.Count -eq 0) {
    $lines.Add("No scheduled emails yet.")
    $lines.Add("")
    $lines.Add("Select reports in the panel, click EMAIL, and fill in TO/SUBJECT/TIME.")
} else {
    $i = 0
    foreach ($t in $tasks) {
        $i++
        $info = $t | Get-ScheduledTaskInfo -ErrorAction SilentlyContinue
        $arg = $t.Actions[0].Arguments
        $jobFile = $null
        if ($arg -match '-JobFile\s+"([^"]+)"') { $jobFile = $matches[1] }
        $meta = if ($jobFile) { Read-JobFile $jobFile } else { Read-JobFile '' }

        $lastRun = "never run yet"
        if ($info -and $info.LastTaskResult -ne 267011 -and $info.LastRunTime -gt [datetime]'1901-01-01') {
            $result = if ($null -ne $info.LastTaskResult -and $info.LastTaskResult -eq 0) { "succeeded" }
                      elseif ($null -ne $info.LastTaskResult) { "exit code $($info.LastTaskResult) - check the job's own .status.txt for details" }
                      else { "unknown result" }
            $lastRun = "$($info.LastRunTime)  ($result)"
        }
        $nextRun = "not scheduled to run again"
        if ($info -and $info.NextRunTime -and $t.State -ne 'Disabled') { $nextRun = "$($info.NextRunTime)" }
        if ($t.State -eq 'Disabled') { $nextRun = "DISABLED in Task Scheduler" }

        $lines.Add(("=" * 78))
        $lines.Add("$i. $($t.TaskName)")
        $lines.Add(("=" * 78))
        $lines.Add("   Subject:    $($meta.SUBJECT)")
        $lines.Add("   To:         $(Format-Recipients $meta)")
        $lines.Add("   Reports:    $(Format-Reports $meta)")
        $lines.Add("   Repeats:    $(Format-Repeat $meta)")
        $lines.Add("   Next run:   $nextRun")
        $lines.Add("   Last run:   $lastRun")
        $lines.Add("")
    }
}

$lines.Add(("-" * 78))
$lines.Add("These are real Windows Scheduled Tasks - also visible/editable in")
$lines.Add("Task Scheduler's own All Tasks view, under Task Scheduler Library >")
$lines.Add("IDMS Email Scheduled. To enable, disable, or delete one directly, use")
$lines.Add("that instead.")

[IO.File]::WriteAllLines($summaryFile, $lines, (New-Object System.Text.UTF8Encoding($false)))
[IO.File]::WriteAllLines($statusFile, @("status=OK", "time=$([DateTimeOffset]::UtcNow.ToUnixTimeSeconds())"), (New-Object System.Text.UTF8Encoding($false)))
