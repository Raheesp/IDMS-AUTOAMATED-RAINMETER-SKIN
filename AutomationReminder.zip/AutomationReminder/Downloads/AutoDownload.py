#!/usr/bin/env python3
# ============================================================================
#  AutoDownload.py  -  headless-Chrome downloader for the DataDownloader widget
# ----------------------------------------------------------------------------
#  Logs into the dealer portal (Playwright / Chromium), downloads BOOKING,
#  DOCKET and ENQUIRY for the 1st of this month -> today, counts the rows, and
#  writes the result to a MACHINE-LOCAL status file the Rainmeter widget reads.
#  Nothing here is synced (Syncthing-safe): creds, downloads and status all live
#  under %LOCALAPPDATA%\AutomationReminder\.
#
#  ONE-TIME SETUP on the PC that runs it:
#     pip install playwright pandas openpyxl
#     python -m playwright install chromium
#     Create the credentials file (or use the widget's "Update password" button):
#        %LOCALAPPDATA%\AutomationReminder\creds.txt
#        line 1 = username
#        line 2 = password
#
#  RUN:
#     python AutoDownload.py           real run (needs the CONFIG below filled in)
#     python AutoDownload.py --mock    no browser; writes sample counts to test
#                                      the widget end-to-end
# ============================================================================

import os, sys, time, datetime, traceback, subprocess

APP_DIR   = os.path.join(os.environ.get("LOCALAPPDATA", os.path.expanduser("~")), "AutomationReminder")
CREDS     = os.path.join(APP_DIR, "creds.txt")
STATUS    = os.path.join(APP_DIR, "_downloads.txt")
DOWNLOADS = os.path.join(APP_DIR, "downloads")

# --- collision avoidance: never run within MIN_GAP of any scheduled task -----
TASK_FOLDER = "\\Uipath Automation\\"  # tasks to stay clear of (UiPath jobs)
MIN_GAP  = 300     # required clearance (s) before/after any task run = 5 min
MAX_WAIT = 240     # give up waiting after this long (s); the next 5-min run retries
POLL     = 30      # re-check the schedule every this many seconds while waiting

# ============================ CONFIG ========================================
# IDMS / sos.ammotors.in portal. Login uses generic robust selectors (the first
# text box = username, the password box = password, the "Login" button). If the
# page still shows /userlogin after submitting, we treat it as a bad password.
LOGIN_URL      = "https://sos.ammotors.in/userlogin"
LOGIN_MARKER   = "userlogin"                          # still in the URL => not logged in
SEL_USER       = "input[type=text]"                   # username box (first text input)
SEL_PASS       = "input[type=password]"               # password box
SEL_LOGIN      = "button:has-text('Login')"           # the Login button

DATE_FMT = "%Y-%m-%d"     # native <input type=date> always takes YYYY-MM-DD

# Report pages. Each has two date pickers (From = 1st, To = today), a Filter
# button, then a download button. Selectors below match the pages you showed:
#   From Date = first date input, To Date = second; then Filter, then download.
REPORTS = {
    "booking": dict(url="https://sos.ammotors.in/booking-report",
                    date_from="input[type=date] >> nth=0",
                    date_to="input[type=date] >> nth=1",
                    search="button:has-text('Filter')",
                    export="button:has-text('Download')"),
    "docket":  dict(url="https://sos.ammotors.in/docket_report",
                    date_from="input[type=date] >> nth=0",
                    date_to="input[type=date] >> nth=1",
                    search="button:has-text('Filter')",
                    export="button:has-text('Download')",
                    # Docket Type / Docket Status are COLUMNS in the downloaded
                    # sheet - filter the rows after download (reliable), keeping
                    # only Current Month and excluding Deleted Docket:
                    row_filter={"Docket Type":   ("==", "Current Month"),
                                "Docket Status": ("!=", "Deleted Docket")}),
    "enquiry": dict(url="https://sos.ammotors.in/enquiry-report",
                    date_from="input[type=date] >> nth=0",
                    date_to="input[type=date] >> nth=1",
                    search="button:has-text('Filter')",
                    export="button:has-text('Export Excel')"),
}
# ============================================================================


LASTGOOD = os.path.join(APP_DIR, "_downloads_lastgood.txt")


def _last_good():
    vals = {}
    try:
        with open(LASTGOOD, encoding="utf-8") as f:
            for line in f:
                if "=" in line:
                    k, v = line.strip().split("=", 1)
                    vals[k] = v
    except OSError:
        pass
    return vals


def write_status(status, counts=None, message=""):
    """status = OK | RUNNING | AUTH_FAILED | UNREACHABLE | NO_CREDS | ERROR

    Every OK run's counts are also kept in _downloads_lastgood.txt (this PC
    only). Any other status carries those last good counts plus goodtime=,
    so the bar keeps showing real numbers - marked with when they're from -
    instead of dashes while a run is in progress or after a failed one."""
    counts = dict(counts or {})
    keys = ("booking", "docket", "enquiry")
    lines = [f"status={status}", f"time={int(time.time())}", f"message={message}"]
    if status == "OK" and any(counts.get(k) not in (None, "") for k in keys):
        try:
            with open(LASTGOOD, "w", encoding="utf-8") as f:
                f.write(f"time={int(time.time())}\n" + "".join(f"{k}={counts.get(k, '')}\n" for k in keys))
        except OSError:
            pass
    elif status != "OK":
        good = _last_good()
        if good.get("time"):
            for k in keys:
                if counts.get(k) in (None, "") and good.get(k):
                    counts[k] = good[k]
            lines.append(f"goodtime={good['time']}")
    for key in keys:
        lines.append(f"{key}={counts.get(key, '')}")
    os.makedirs(APP_DIR, exist_ok=True)
    tmp = STATUS + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        f.write("\n".join(lines) + "\n")
    os.replace(tmp, STATUS)   # atomic, so the widget never reads a half file


def read_creds():
    # utf-8-sig: Setup.ps1 writes creds.txt with a BOM (PowerShell 5.1
    # Set-Content -Encoding UTF8), which plain utf-8 would glue onto the username
    with open(CREDS, encoding="utf-8-sig") as f:
        vals = [ln.strip() for ln in f if ln.strip()]
    if len(vals) < 2:
        raise ValueError("creds.txt needs username on line 1, password on line 2")
    return vals[0], vals[1]


def count_rows(path, row_filter=None):
    """Row count of the downloaded sheet. If row_filter is given, count only the
    rows that match it, e.g. {"Docket Type": ("==", "Current Month"),
    "Docket Status": ("!=", "Deleted Docket")}. Column and value matching is
    trimmed + case-insensitive, so spaces / casing don't matter."""
    try:
        import pandas as pd
        df = pd.read_excel(path) if path.lower().endswith((".xlsx", ".xls")) else pd.read_csv(path)
    except Exception:
        with open(path, encoding="utf-8", errors="ignore") as f:
            return max(0, sum(1 for _ in f) - 1)   # rows minus header (unfiltered)

    if not row_filter:
        return int(len(df))

    def find_col(name):
        nl = name.strip().lower()
        for c in df.columns:
            if str(c).strip().lower() == nl:
                return c
        return None

    mask = None
    for colname, (op, val) in row_filter.items():
        c = find_col(colname)
        if c is None:
            continue                                   # column absent -> skip cond
        series = df[c].astype(str).str.strip().str.lower()
        v = str(val).strip().lower()
        cond = (series == v) if op == "==" else (series != v)
        mask = cond if mask is None else (mask & cond)
    return int(len(df) if mask is None else mask.sum())


CREATE_NO_WINDOW = 0x08000000   # run child processes with no console (no focus steal)

def _powershell(cmd):
    try:
        out = subprocess.check_output(
            ["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", cmd],
            creationflags=CREATE_NO_WINDOW, stderr=subprocess.DEVNULL, timeout=30)
        return out.decode("utf-8", "ignore")
    except Exception:
        return ""


def tasks_snapshot():
    """(nextEpoch, lastEpoch, state) for each enabled task in TASK_FOLDER."""
    ps = ("$f='" + TASK_FOLDER + "';"
          "Get-ScheduledTask -TaskPath $f -ErrorAction SilentlyContinue |"
          " Where-Object {$_.State -ne 'Disabled'} | ForEach-Object {"
          " $i=$_|Get-ScheduledTaskInfo -ErrorAction SilentlyContinue; $n=0; $l=0;"
          " if($i.NextRunTime){try{$n=[int]([datetimeoffset]$i.NextRunTime).ToUnixTimeSeconds()}catch{}};"
          " if($i.LastRunTime){try{$l=[int]([datetimeoffset]$i.LastRunTime).ToUnixTimeSeconds()}catch{}};"
          " \"$n|$l|$($_.State)\" }")
    rows = []
    for line in _powershell(ps).splitlines():
        p = line.strip().split("|")
        if len(p) == 3:
            try: rows.append((int(p[0]), int(p[1]), p[2]))
            except ValueError: pass
    return rows


def window_clear(tasks, now):
    """True if no task is running / starting / just-started within MIN_GAP."""
    for nxt, last, state in tasks:
        if state == "Running":
            return False, "a UiPath task is running"
        if nxt > 0 and 0 <= nxt - now <= MIN_GAP:
            return False, "a task starts within %d min" % (MIN_GAP // 60)
        if last > 0 and 0 <= now - last <= MIN_GAP:
            return False, "a task started in the last %d min" % (MIN_GAP // 60)
    return True, ""


def wait_for_clear_window():
    """Block until there is a clear MIN_GAP window, or give up after MAX_WAIT."""
    waited = 0
    while True:
        tasks = tasks_snapshot()
        if not tasks:            # can't read the schedule -> don't block forever
            return True
        ok, reason = window_clear(tasks, time.time())
        if ok:
            return True
        if waited >= MAX_WAIT:
            return False
        write_status("DEFERRED", None, "waiting for a clear 5-min slot: " + reason)
        time.sleep(POLL)
        waited += POLL


# --- form helpers: tolerant of spaces / case / native-vs-custom widgets -----
def try_fill(page, selector, value):
    if not selector:
        return False
    try:
        page.fill(selector, value, timeout=8000)
        return True
    except Exception:
        return False


def pick(page, label, value):
    """Choose an option whose visible text == value (trimmed, case-insensitive).
    Works for native <select> and for click-open custom dropdowns."""
    vl = value.strip().lower()
    # 1) native <select> that has this option
    try:
        n = page.locator("select").count()
    except Exception:
        n = 0
    for i in range(n):
        sel = page.locator("select").nth(i)
        try:
            texts = sel.locator("option").all_inner_texts()
        except Exception:
            continue
        for t in texts:
            if t.strip().lower() == vl:
                try:
                    sel.select_option(label=t.strip())
                    return True
                except Exception:
                    pass
    # 2) custom dropdown: open the control nearest the label, then click the option
    for opener in (
        "xpath=//label[contains(normalize-space(.),%r)]/following::*[self::div or self::button or self::input or self::span][1]" % label,
        "xpath=//*[contains(normalize-space(.),%r)]/following::*[self::div or self::button or self::input][1]" % label,
    ):
        try:
            page.locator(opener).first.click(timeout=3000)
            break
        except Exception:
            continue
    try:
        page.get_by_text(value, exact=True).first.click(timeout=3000)
        return True
    except Exception:
        return False


def unpick(page, label, value):
    """Remove a selected option (chip with an 'x', or a checkbox) matching value."""
    # 1) a selected chip/tag with a nearby remove control
    try:
        tag = page.get_by_text(value, exact=True).first
        for rm in ("xpath=following-sibling::*[1]",
                   "xpath=./*[contains(@class,'remove') or contains(@class,'close')]",
                   "xpath=..//*[normalize-space(.)='x' or normalize-space(.)='X' or contains(@class,'remove') or contains(@class,'close')]"):
            try:
                tag.locator(rm).first.click(timeout=2000)
                return True
            except Exception:
                continue
    except Exception:
        pass
    # 2) a checkbox labelled value -> uncheck it
    try:
        cb = page.get_by_label(value, exact=True)
        if cb.is_checked():
            cb.uncheck()
        return True
    except Exception:
        return False


def do_extra(page, step):
    action, label, value = step
    try:
        if action == "pick":
            return pick(page, label, value)
        if action == "unpick":
            return unpick(page, label, value)
    except Exception:
        return False
    return False


def run_mock():
    import random
    counts = {k: random.randint(40, 900) for k in ("booking", "docket", "enquiry")}
    write_status("OK", counts, "mock run")
    print("mock ->", counts)


def run_real():
    """Log in once and pull BOOKING / DOCKET / ENQUIRY for the 1st of this
    month -> today, then count rows. The browser work reuses IdmsDownload.py's
    proven pieces (same folder): new_browser_context, do_login with its 8
    backed-off attempts, goto_report, and do_one, which captures the file
    whether the portal delivers it as a normal download, a popup, or a
    fetch() response. Confirmed live 2026-09-29: this script's old
    page.expect_download()-only click timed out on Booking every run on both
    PCs, while IdmsDownload.py downloaded the same pages fine - the portal no
    longer fires a plain download event for these exports.
    Each report gets REPORT_ATTEMPTS tries and is reported on its own, so one
    slow report no longer blanks the other two counts."""
    from playwright.sync_api import sync_playwright
    import IdmsDownload as idms

    REPORT_ATTEMPTS = 3
    os.makedirs(DOWNLOADS, exist_ok=True)
    user, pw = read_creds()
    write_status("RUNNING", None, "logging in...")   # widget shows "Running..."

    first = datetime.date.today().replace(day=1)
    today = datetime.date.today()
    d_from, d_to = first.strftime(DATE_FMT), today.strftime(DATE_FMT)
    counts, notes = {}, []

    with sync_playwright() as p:
        browser = p.chromium.launch(headless=True)
        ctx = idms.new_browser_context(browser)
        page = ctx.new_page()

        # No separate page.goto(LOGIN_URL) first: confirmed live 2026-09-29
        # that loading the login page twice (once here, once inside
        # do_login) made every login attempt bounce back to /userlogin.
        if not idms.do_login(page, user, pw):
            if LOGIN_MARKER not in page.url.lower():
                write_status("UNREACHABLE", None, "cannot reach the portal - check network / VPN")
            else:
                write_status("AUTH_FAILED", None, "login did not go through (" + (idms.LAST_LOGIN_ERROR or "no reason given") +
                             ") - retries automatically on the next run")
            browser.close(); return

        for name, r in REPORTS.items():
            cfg = idms.REPORTS[name]
            write_status("RUNNING", counts, f"downloading {name}...")
            last_err = ""
            for attempt in range(1, REPORT_ATTEMPTS + 1):
                if not idms.goto_report(page, cfg):
                    # session dropped back to the login page - log in again once
                    if not idms.do_login(page, user, pw):
                        write_status("AUTH_FAILED", counts, "session dropped to login and re-login failed")
                        browser.close(); return
                    continue
                ok, res = idms.do_one(page, name, cfg, "custom", d_from, d_to, out_dir=DOWNLOADS)
                if ok:
                    counts[name] = count_rows(res, r.get("row_filter"))
                    break
                last_err = res
                page.wait_for_timeout(3000 * attempt)
            else:
                notes.append(f"{name}: {last_err}")

        browser.close()

    if not counts:
        write_status("ERROR", None, "; ".join(notes) or "no report could be downloaded")
        return
    write_status("OK", counts, "; ".join(notes))
    print("done ->", counts, "| notes:", notes)


if __name__ == "__main__":
    try:
        if "--mock" in sys.argv:
            run_mock()
        else:
            run_real()
    except FileNotFoundError:
        write_status("NO_CREDS", None, "creds.txt not found - click Update password")
    except Exception as e:
        write_status("ERROR", None, str(e))
        traceback.print_exc()
