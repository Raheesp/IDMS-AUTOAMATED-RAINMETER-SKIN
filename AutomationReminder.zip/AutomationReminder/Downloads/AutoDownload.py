#!/usr/bin/env python3
# ============================================================================
#  AutoDownload.py  -  headless-Chrome downloader for the DataDownloader widget
# ----------------------------------------------------------------------------
#  Logs into the dealer portal (Playwright / Chromium), downloads BOOKING,
#  DOCKET and ENQUIRY for the 1st of this month -> today, counts the rows, and
#  writes the result to a MACHINE-LOCAL status file the Rainmeter widget reads.
#  Nothing here is synced (Syncthing-safe): creds, downloads and status all live
#  under %LOCALAPPDATA%\AutomationReminder\.
#
#  ONE-TIME SETUP on the PC that runs it:
#     pip install playwright pandas openpyxl
#     python -m playwright install chromium
#     Create the credentials file (or use the widget's "Update password" button):
#        %LOCALAPPDATA%\AutomationReminder\creds.txt
#        line 1 = username
#        line 2 = password
#
#  RUN:
#     python AutoDownload.py           real run (needs the CONFIG below filled in)
#     python AutoDownload.py --mock    no browser; writes sample counts to test
#                                      the widget end-to-end
# ============================================================================

import os, sys, time, datetime, traceback, subprocess

APP_DIR   = os.path.join(os.environ.get("LOCALAPPDATA", os.path.expanduser("~")), "AutomationReminder")
CREDS     = os.path.join(APP_DIR, "creds.txt")
STATUS    = os.path.join(APP_DIR, "_downloads.txt")
DOWNLOADS = os.path.join(APP_DIR, "downloads")

# --- collision avoidance: never run within MIN_GAP of any scheduled task -----
TASK_FOLDER = "\\Uipath Automation\\"  # tasks to stay clear of (UiPath jobs)
MIN_GAP  = 300     # required clearance (s) before/after any task run = 5 min
MAX_WAIT = 240     # give up waiting after this long (s); the next 5-min run retries
POLL     = 30      # re-check the schedule every this many seconds while waiting

# ============================ CONFIG ========================================
# IDMS / sos.ammotors.in portal. Login uses generic robust selectors (the first
# text box = username, the password box = password, the "Login" button). If the
# page still shows /userlogin after submitting, we treat it as a bad password.
LOGIN_URL      = "https://sos.ammotors.in/userlogin"
LOGIN_MARKER   = "userlogin"                          # still in the URL => not logged in
SEL_USER       = "input[type=text]"                   # username box (first text input)
SEL_PASS       = "input[type=password]"               # password box
SEL_LOGIN      = "button:has-text('Login')"           # the Login button

DATE_FMT = "%Y-%m-%d"     # native <input type=date> always takes YYYY-MM-DD

# Report pages. Each has two date pickers (From = 1st, To = today), a Filter
# button, then a download button. Selectors below match the pages you showed:
#   From Date = first date input, To Date = second; then Filter, then download.
REPORTS = {
    "booking": dict(url="https://sos.ammotors.in/booking-report",
                    date_from="input[type=date] >> nth=0",
                    date_to="input[type=date] >> nth=1",
                    search="button:has-text('Filter')",
                    export="button:has-text('Download')"),
    "docket":  dict(url="https://sos.ammotors.in/docket_report",
                    date_from="input[type=date] >> nth=0",
                    date_to="input[type=date] >> nth=1",
                    search="button:has-text('Filter')",
                    export="button:has-text('Download')",
                    # Docket Type / Docket Status are COLUMNS in the downloaded
                    # sheet - filter the rows after download (reliable), keeping
                    # only Current Month and excluding Deleted Docket:
                    row_filter={"Docket Type":   ("==", "Current Month"),
                                "Docket Status": ("!=", "Deleted Docket")}),
    "enquiry": dict(url="https://sos.ammotors.in/enquiry-report",
                    date_from="input[type=date] >> nth=0",
                    date_to="input[type=date] >> nth=1",
                    search="button:has-text('Filter')",
                    export="button:has-text('Export Excel')"),
}
# ============================================================================


def write_status(status, counts=None, message=""):
    """status = OK | AUTH_FAILED | UNREACHABLE | NO_CREDS | ERROR"""
    counts = counts or {}
    lines = [f"status={status}", f"time={int(time.time())}", f"message={message}"]
    for key in ("booking", "docket", "enquiry"):
        lines.append(f"{key}={counts.get(key, '')}")
    os.makedirs(APP_DIR, exist_ok=True)
    tmp = STATUS + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        f.write("\n".join(lines) + "\n")
    os.replace(tmp, STATUS)   # atomic, so the widget never reads a half file


def read_creds():
    with open(CREDS, encoding="utf-8") as f:
        vals = [ln.strip() for ln in f if ln.strip()]
    if len(vals) < 2:
        raise ValueError("creds.txt needs username on line 1, password on line 2")
    return vals[0], vals[1]


def count_rows(path, row_filter=None):
    """Row count of the downloaded sheet. If row_filter is given, count only the
    rows that match it, e.g. {"Docket Type": ("==", "Current Month"),
    "Docket Status": ("!=", "Deleted Docket")}. Column and value matching is
    trimmed + case-insensitive, so spaces / casing don't matter."""
    try:
        import pandas as pd
        df = pd.read_excel(path) if path.lower().endswith((".xlsx", ".xls")) else pd.read_csv(path)
    except Exception:
        with open(path, encoding="utf-8", errors="ignore") as f:
            return max(0, sum(1 for _ in f) - 1)   # rows minus header (unfiltered)

    if not row_filter:
        return int(len(df))

    def find_col(name):
        nl = name.strip().lower()
        for c in df.columns:
            if str(c).strip().lower() == nl:
                return c
        return None

    mask = None
    for colname, (op, val) in row_filter.items():
        c = find_col(colname)
        if c is None:
            continue                                   # column absent -> skip cond
        series = df[c].astype(str).str.strip().str.lower()
        v = str(val).strip().lower()
        cond = (series == v) if op == "==" else (series != v)
        mask = cond if mask is None else (mask & cond)
    return int(len(df) if mask is None else mask.sum())


CREATE_NO_WINDOW = 0x08000000   # run child processes with no console (no focus steal)

def _powershell(cmd):
    try:
        out = subprocess.check_output(
            ["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", cmd],
            creationflags=CREATE_NO_WINDOW, stderr=subprocess.DEVNULL, timeout=30)
        return out.decode("utf-8", "ignore")
    except Exception:
        return ""


def tasks_snapshot():
    """(nextEpoch, lastEpoch, state) for each enabled task in TASK_FOLDER."""
    ps = ("$f='" + TASK_FOLDER + "';"
          "Get-ScheduledTask -TaskPath $f -ErrorAction SilentlyContinue |"
          " Where-Object {$_.State -ne 'Disabled'} | ForEach-Object {"
          " $i=$_|Get-ScheduledTaskInfo -ErrorAction SilentlyContinue; $n=0; $l=0;"
          " if($i.NextRunTime){try{$n=[int]([datetimeoffset]$i.NextRunTime).ToUnixTimeSeconds()}catch{}};"
          " if($i.LastRunTime){try{$l=[int]([datetimeoffset]$i.LastRunTime).ToUnixTimeSeconds()}catch{}};"
          " \"$n|$l|$($_.State)\" }")
    rows = []
    for line in _powershell(ps).splitlines():
        p = line.strip().split("|")
        if len(p) == 3:
            try: rows.append((int(p[0]), int(p[1]), p[2]))
            except ValueError: pass
    return rows


def window_clear(tasks, now):
    """True if no task is running / starting / just-started within MIN_GAP."""
    for nxt, last, state in tasks:
        if state == "Running":
            return False, "a UiPath task is running"
        if nxt > 0 and 0 <= nxt - now <= MIN_GAP:
            return False, "a task starts within %d min" % (MIN_GAP // 60)
        if last > 0 and 0 <= now - last <= MIN_GAP:
            return False, "a task started in the last %d min" % (MIN_GAP // 60)
    return True, ""


def wait_for_clear_window():
    """Block until there is a clear MIN_GAP window, or give up after MAX_WAIT."""
    waited = 0
    while True:
        tasks = tasks_snapshot()
        if not tasks:            # can't read the schedule -> don't block forever
            return True
        ok, reason = window_clear(tasks, time.time())
        if ok:
            return True
        if waited >= MAX_WAIT:
            return False
        write_status("DEFERRED", None, "waiting for a clear 5-min slot: " + reason)
        time.sleep(POLL)
        waited += POLL


# --- form helpers: tolerant of spaces / case / native-vs-custom widgets -----
def try_fill(page, selector, value):
    if not selector:
        return False
    try:
        page.fill(selector, value, timeout=8000)
        return True
    except Exception:
        return False


def pick(page, label, value):
    """Choose an option whose visible text == value (trimmed, case-insensitive).
    Works for native <select> and for click-open custom dropdowns."""
    vl = value.strip().lower()
    # 1) native <select> that has this option
    try:
        n = page.locator("select").count()
    except Exception:
        n = 0
    for i in range(n):
        sel = page.locator("select").nth(i)
        try:
            texts = sel.locator("option").all_inner_texts()
        except Exception:
            continue
        for t in texts:
            if t.strip().lower() == vl:
                try:
                    sel.select_option(label=t.strip())
                    return True
                except Exception:
                    pass
    # 2) custom dropdown: open the control nearest the label, then click the option
    for opener in (
        "xpath=//label[contains(normalize-space(.),%r)]/following::*[self::div or self::button or self::input or self::span][1]" % label,
        "xpath=//*[contains(normalize-space(.),%r)]/following::*[self::div or self::button or self::input][1]" % label,
    ):
        try:
            page.locator(opener).first.click(timeout=3000)
            break
        except Exception:
            continue
    try:
        page.get_by_text(value, exact=True).first.click(timeout=3000)
        return True
    except Exception:
        return False


def unpick(page, label, value):
    """Remove a selected option (chip with an 'x', or a checkbox) matching value."""
    # 1) a selected chip/tag with a nearby remove control
    try:
        tag = page.get_by_text(value, exact=True).first
        for rm in ("xpath=following-sibling::*[1]",
                   "xpath=./*[contains(@class,'remove') or contains(@class,'close')]",
                   "xpath=..//*[normalize-space(.)='x' or normalize-space(.)='X' or contains(@class,'remove') or contains(@class,'close')]"):
            try:
                tag.locator(rm).first.click(timeout=2000)
                return True
            except Exception:
                continue
    except Exception:
        pass
    # 2) a checkbox labelled value -> uncheck it
    try:
        cb = page.get_by_label(value, exact=True)
        if cb.is_checked():
            cb.uncheck()
        return True
    except Exception:
        return False


def do_extra(page, step):
    action, label, value = step
    try:
        if action == "pick":
            return pick(page, label, value)
        if action == "unpick":
            return unpick(page, label, value)
    except Exception:
        return False
    return False


def run_mock():
    import random
    counts = {k: random.randint(40, 900) for k in ("booking", "docket", "enquiry")}
    write_status("OK", counts, "mock run")
    print("mock ->", counts)


def run_real():
    from playwright.sync_api import sync_playwright, TimeoutError as PWTimeout
    os.makedirs(DOWNLOADS, exist_ok=True)
    user, pw = read_creds()
    write_status("RUNNING", None, "logging in...")   # widget shows "Running..."

    first = datetime.date.today().replace(day=1)
    today = datetime.date.today()
    d_from, d_to = first.strftime(DATE_FMT), today.strftime(DATE_FMT)
    counts = {}

    with sync_playwright() as p:
        browser = p.chromium.launch(headless=True)
        ctx = browser.new_context(accept_downloads=True)
        page = ctx.new_page()

        # ---- login ------------------------------------------------------
        try:
            page.goto(LOGIN_URL, timeout=30000)
        except Exception as e:
            write_status("UNREACHABLE", None, f"cannot reach portal: {e}")
            browser.close(); return

        page.fill(SEL_USER, user)
        page.fill(SEL_PASS, pw)
        page.click(SEL_LOGIN)
        try:
            page.wait_for_load_state("networkidle", timeout=20000)
        except PWTimeout:
            pass
        if LOGIN_MARKER in page.url.lower():
            # still on the login page => wrong password (or account locked)
            write_status("AUTH_FAILED", None, "login did not succeed - password may have changed")
            browser.close(); return

        # ---- each report ------------------------------------------------
        notes = []
        for name, r in REPORTS.items():
            page.goto(r["url"], timeout=30000)
            try:
                page.wait_for_load_state("networkidle", timeout=20000)
            except PWTimeout:
                pass
            if LOGIN_MARKER in page.url.lower():
                write_status("AUTH_FAILED", None, "session dropped to login - password may have changed")
                browser.close(); return
            # extra dropdown/status filters (docket: Current Month, exclude Deleted)
            for step in r.get("extras", []):
                if not do_extra(page, step):
                    notes.append("%s: could not set %s='%s'" % (name, step[1], step[2]))
            try_fill(page, r.get("date_from"), d_from)
            try_fill(page, r.get("date_to"),   d_to)
            if r.get("search"):
                page.click(r["search"])
                try: page.wait_for_load_state("networkidle", timeout=30000)
                except PWTimeout: pass
                page.wait_for_timeout(1500)   # let the table finish rendering
            if r.get("export"):
                with page.expect_download(timeout=120000) as dl:
                    page.click(r["export"])
                out = os.path.join(DOWNLOADS, name + ".xlsx")
                dl.value.save_as(out)
                counts[name] = count_rows(out, r.get("row_filter"))
            else:
                counts[name] = page.locator("table tbody tr").count()

        browser.close()

    write_status("OK", counts, "; ".join(notes))
    print("done ->", counts, "| notes:", notes)


if __name__ == "__main__":
    try:
        if "--mock" in sys.argv:
            run_mock()
        else:
            run_real()
    except FileNotFoundError:
        write_status("NO_CREDS", None, "creds.txt not found - click Update password")
    except Exception as e:
        write_status("ERROR", None, str(e))
        traceback.print_exc()
