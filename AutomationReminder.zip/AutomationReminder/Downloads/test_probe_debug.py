import sys
sys.path.insert(0, r"e:\ibnd\AutomationReminder\Downloads")
import IdmsDownload as idms

def main():
    user, pw = idms.read_creds()
    from playwright.sync_api import sync_playwright
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=True)
        ctx = browser.new_context(accept_downloads=True)
        page = ctx.new_page()
        if not idms.do_login(page, user, pw):
            print("LOGIN FAILED, url:", page.url)
            print(page.locator("body").inner_text()[:800])
            return

        import os
        os.makedirs(idms.PROBE_DIR, exist_ok=True)

        cfg = idms.REPORTS["taxlist"]
        earliest, latest = idms.extract_date_range(os.path.join(idms.PROBE_DIR, "taxlist_dbg.xlsx"))
        print("taxlist_dbg.xlsx date range found:", earliest, latest)
        r = idms.file_has_rows(os.path.join(idms.PROBE_DIR, "taxlist_dbg.xlsx"))
        print("taxlist_dbg.xlsx file_has_rows:", r)

        # check enquiry's actual table for this month - is it really empty?
        cfg = idms.REPORTS["enquiry"]
        d_from, d_to = idms.month_offset_to_range(0)
        idms.goto_report(page, cfg)
        idms.try_fill(page, cfg["df"], d_from)
        idms.try_fill(page, cfg["dt"], d_to)
        idms.click_text(page, cfg["filt"], timeout=6000)
        page.wait_for_timeout(3000)
        rows = page.locator("table tbody tr")
        print("enquiry table row count for this month:", rows.count())
        if rows.count():
            print("first row:", rows.first.inner_text()[:200])
        # is the Export Excel button even present/enabled?
        btn = page.get_by_text("Export Excel", exact=True)
        print("Export Excel button count:", btn.count())
        if btn.count():
            print("Export Excel first element outer html:", btn.first.evaluate("el => el.outerHTML"))

        browser.close()

if __name__ == "__main__":
    main()
