# ============================================================================
#  IdmsCmdLauncher.ps1  -  the PowerShell half of every portable IDMS .cmd
# ----------------------------------------------------------------------------
#  NOT run from this folder. IdmsMakeCmd.ps1 copies this file verbatim into
#  each .cmd it builds (the download icon in the IDMS panel), next to a JOB
#  section (reports + frozen dates) and a base64 copy of IdmsDownload.py.
#  The .cmd's batch header reads this section back out of itself and runs it,
#  so the .cmd needs nothing from this skin folder and runs on a bare PC:
#
#    1. Python 3.9+: one already on the PC, else a PRIVATE copy it installs
#       itself (official python.org installer, per-user, no admin, into
#       %LOCALAPPDATA%\AutomationReminder\python), else winget.
#    2. playwright / pandas / openpyxl + Chromium, installed if missing.
#    3. THAT PC's IDMS login, asked once and kept in its own
#       %LOCALAPPDATA%\AutomationReminder\creds.txt - never inside the .cmd.
#    4. Downloads into the SAME folder the .cmd is in at the moment it runs,
#       and keeps going until everything is downloaded: waits for the
#       network/portal, retries in rounds with growing pauses, and each round
#       re-runs ONLY the reports that are still missing.
#
#  Keep this file ASCII-only, and never start a line with ":::IDMS:" - that
#  prefix marks the section boundaries inside the .cmd.
# ============================================================================

$ErrorActionPreference = 'Continue'
$ProgressPreference = 'SilentlyContinue'
try { [Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12 } catch {}
try { [Net.WebRequest]::DefaultWebProxy.Credentials = [Net.CredentialCache]::DefaultNetworkCredentials } catch {}

# --- retry policy -------------------------------------------------------------
$MaxRounds     = 8                                # download rounds before giving up
$RoundPauses   = @(20, 45, 90, 180, 300, 300, 300) # seconds to wait before round 2, 3, ...
$NetWaitMax    = 30 * 60                          # wait up to 30 min for the portal to answer
$PortalUrl     = 'https://sos.ammotors.in/userlogin'
$PythonVersion = '3.12.10'                        # private install, when the PC has none

$selfText = [IO.File]::ReadAllText($env:IDMS_SELF)

function Say($m, $c = 'Gray') { Write-Host $m -ForegroundColor $c }

function Get-Section([string]$name) {
    $m = [regex]::Match($selfText, "(?ms)^:::IDMS:" + $name + ":::\r?\n(.*?)(?=^:::IDMS:|\z)")
    if (-not $m.Success) { return $null }
    return $m.Groups[1].Value
}

function Stop-Launcher($msg) {
    Say ""
    Say $msg 'Red'
    exit 1
}

# Visible countdown; any key skips the rest of the wait.
function Wait-Countdown([int]$seconds, [string]$why) {
    for ($s = $seconds; $s -gt 0; $s--) {
        Write-Host ("`r      {0} - next try in {1,3}s (press any key to try now) " -f $why, $s) -NoNewline -ForegroundColor DarkYellow
        for ($i = 0; $i -lt 10; $i++) {
            Start-Sleep -Milliseconds 100
            try { if ([Console]::KeyAvailable) { [void][Console]::ReadKey($true); Write-Host ""; return } } catch {}
        }
    }
    Write-Host ""
}

# Returns $true when the given key was pressed within $seconds.
function Read-KeyWithin([int]$seconds, [char]$key) {
    $end = (Get-Date).AddSeconds($seconds)
    while ((Get-Date) -lt $end) {
        try {
            if ([Console]::KeyAvailable) {
                $k = [Console]::ReadKey($true)
                return ([char]::ToUpper($k.KeyChar) -eq [char]::ToUpper($key))
            }
        } catch { return $false }
        Start-Sleep -Milliseconds 150
    }
    return $false
}

function Get-File([string]$url, [string]$dest, [long]$MinBytes = 1MB) {
    for ($try = 1; $try -le 3; $try++) {
        Remove-Item $dest -Force -ErrorAction SilentlyContinue
        $curl = Get-Command curl.exe -ErrorAction SilentlyContinue
        if ($curl) { & $curl.Source -L --fail --silent --show-error --retry 2 -o $dest $url 2>$null }
        if (-not (Test-Path $dest) -or (Get-Item $dest).Length -lt $MinBytes) {
            try { Invoke-WebRequest -Uri $url -OutFile $dest -UseBasicParsing -TimeoutSec 600 } catch {}
        }
        if ((Test-Path $dest) -and (Get-Item $dest).Length -ge $MinBytes) { return $true }
        Start-Sleep -Seconds (5 * $try)
    }
    return $false
}

# --- what this .cmd downloads ------------------------------------------------
$jobText = Get-Section 'JOB'
$pyB64   = Get-Section 'PY'
if (-not $jobText -or -not $pyB64) { Stop-Launcher "This .cmd file is damaged. Create it again with the download icon in the IDMS panel." }

$job = @{}
$shownReports = @()
$reportKeys = @()
$baseLines = @()
foreach ($l in ($jobText -split "\r?\n")) {
    if ($l -notmatch '^([^=]+)=(.*)$') { continue }
    $k, $v = $matches[1], $matches[2]
    if ($k -eq 'show_report') { $shownReports += $v; continue }
    if ($k -eq 'report') { $reportKeys += $v; continue }
    if ($k -eq 'outdir') { continue }
    $job[$k] = $v
    $baseLines += $l
}
$labelOf = @{}
for ($i = 0; $i -lt $reportKeys.Count; $i++) { $labelOf[$reportKeys[$i]] = $(if ($i -lt $shownReports.Count) { $shownReports[$i] } else { $reportKeys[$i] }) }

Say "=====================================================================" 'DarkCyan'
Say "  IDMS REPORT DOWNLOAD   (sos.ammotors.in)" 'Cyan'
Say "=====================================================================" 'DarkCyan'
Say "  $($job['name'])" 'White'
Say "  Dates:    $($job['show_range'])"
# A DYNAMIC .cmd carries a date RULE, not dates: show what it means today.
# Same rules as resolve_dates() in the embedded IdmsDownload.py.
function Get-RuleDates([string]$rule, [int]$n) {
    $today = (Get-Date).Date
    $first = New-Object DateTime $today.Year, $today.Month, 1
    switch ($rule) {
        'today'       { return @($today, $today) }
        'month'       { return @($first, $today) }
        'lastmonth'   { return @($first.AddMonths(-1), $first.AddDays(-1)) }
        'last2months' { return @($first.AddMonths(-2), $today) }
        'last3months' { return @($first.AddMonths(-3), $today) }
        'lastnmonths' { return @($first.AddMonths(-$n), $today) }
    }
    return $null
}
if ($job['show_rule']) {
    $rd = Get-RuleDates $job['show_rule'] ([int]("0" + $job['show_months']))
    if ($rd) { Say ("            today that is: {0:yyyy-MM-dd} to {1:yyyy-MM-dd}" -f $rd[0], $rd[1]) 'Yellow' }
}
Say "  Reports:  $($reportKeys.Count)"
foreach ($k in $reportKeys) { Say "            - $($labelOf[$k])" 'DarkGray' }
Say "  Created:  $($job['created'])"
Say ""

$appDir = Join-Path $env:LOCALAPPDATA 'AutomationReminder'
New-Item -ItemType Directory -Force -Path $appDir | Out-Null

# --- 1. Python -----------------------------------------------------------------
$privPyDir = Join-Path $appDir 'python'
function Test-RealPython($p) {
    if (-not $p) { return $false }
    if ($p -like '*\WindowsApps\*') { return $false }   # Microsoft Store stub
    if (-not (Test-Path $p)) { return $false }
    try {
        $o = & $p -c "import sys;assert sys.version_info>=(3,9);print(sys.executable)" 2>$null
        return ($LASTEXITCODE -eq 0 -and $o)
    } catch { return $false }
}
function Find-Python {
    $priv = Join-Path $privPyDir 'python.exe'
    if (Test-RealPython $priv) { return $priv }
    # set IDMS_TEST_BARE=1 to act like a PC with no Python at all (testing)
    if ($env:IDMS_TEST_BARE -eq '1') { return $null }
    try { $e = (& py -3 -c "import sys;print(sys.executable)" 2>$null); if ($e) { $e = "$e".Trim(); if (Test-RealPython $e) { return $e } } } catch {}
    foreach ($g in (Get-Command python.exe -All -ErrorAction SilentlyContinue)) { if (Test-RealPython $g.Source) { return $g.Source } }
    $guesses = @("$env:USERPROFILE\anaconda3\python.exe", "$env:USERPROFILE\miniconda3\python.exe", "$env:ProgramData\anaconda3\python.exe")
    foreach ($d in @("$env:LOCALAPPDATA\Programs\Python", "$env:ProgramFiles\Python312", "$env:ProgramFiles\Python311", "$env:ProgramFiles\Python313")) {
        if (Test-Path $d) { Get-ChildItem $d -Recurse -Filter python.exe -ErrorAction SilentlyContinue | ForEach-Object { $guesses += $_.FullName } }
    }
    foreach ($g in $guesses) { if (Test-RealPython $g) { return $g } }
    return $null
}
# Private Python = the official "embeddable" zip from python.org + pip. No
# installer, no registry, no admin, and it can't collide with (or be hijacked
# by) any Python already on the PC. Confirmed live: the regular installer in
# /quiet mode silently repairs an existing same-version install instead of
# honouring TargetDir, so it is NOT used.
function Install-PrivatePython {
    $arch = switch ($env:PROCESSOR_ARCHITECTURE) { 'ARM64' { 'arm64' } 'AMD64' { 'amd64' } default { if ($env:PROCESSOR_ARCHITEW6432) { 'amd64' } else { 'win32' } } }
    $zipUrl = "https://www.python.org/ftp/python/$PythonVersion/python-$PythonVersion-embed-$arch.zip"
    $zip = Join-Path $env:TEMP "idms-python-$PythonVersion-$arch.zip"
    Say "      Downloading portable Python $PythonVersion from python.org (about 11 MB)..." 'Yellow'
    if (-not (Get-File $zipUrl $zip)) { Say "      Could not download $zipUrl" 'Yellow'; return }
    Remove-Item $privPyDir -Recurse -Force -ErrorAction SilentlyContinue
    New-Item -ItemType Directory -Force -Path $privPyDir | Out-Null
    try { Expand-Archive -Path $zip -DestinationPath $privPyDir -Force }
    catch { Say "      Could not unpack Python: $($_.Exception.Message)" 'Yellow'; return }
    Remove-Item $zip -Force -ErrorAction SilentlyContinue
    # let it use site-packages (pip installs there); the ._pth file disables it by default
    Get-ChildItem $privPyDir -Filter 'python*._pth' | ForEach-Object {
        $pth = (Get-Content $_.FullName) -replace '^#\s*import site', 'import site'
        if ($pth -notcontains 'Lib\site-packages') { $pth += 'Lib\site-packages' }
        [IO.File]::WriteAllLines($_.FullName, $pth)
    }
    $getPip = Join-Path $privPyDir 'get-pip.py'
    Say "      Adding pip..." 'Yellow'
    if (-not (Get-File 'https://bootstrap.pypa.io/get-pip.py' $getPip -MinBytes 100KB)) { Say "      Could not download get-pip.py" 'Yellow'; return }
    & (Join-Path $privPyDir 'python.exe') $getPip --no-warn-script-location --disable-pip-version-check --quiet
    Remove-Item $getPip -Force -ErrorAction SilentlyContinue
}

Say "[1/4] Checking Python..." 'Cyan'
$py = Find-Python
if (-not $py) {
    Say "      No usable Python on this PC - setting one up (one time, a few minutes)." 'Yellow'
    Install-PrivatePython
    $py = Find-Python
}
if (-not $py -and (Get-Command winget -ErrorAction SilentlyContinue)) {
    Say "      Trying winget instead..." 'Yellow'
    winget install -e --id Python.Python.3.12 --scope user --silent --accept-source-agreements --accept-package-agreements | Out-Host
    $py = Find-Python
}
if (-not $py) {
    Stop-Launcher ("Python could not be set up automatically (python.org and winget both failed).`n" +
        "Check the internet connection / proxy, or install Python from https://www.python.org/downloads/,`n" +
        "then double-click this .cmd again.")
}
Say "      $py" 'DarkGray'

# --- 2. packages + browser -------------------------------------------------------
Say "[2/4] Checking the download tools (Playwright, pandas, openpyxl)..." 'Cyan'
& $py -c "import playwright, pandas, openpyxl" 2>$null
if ($LASTEXITCODE -ne 0) {
    Say "      Installing them (one time, a few minutes)..." 'Yellow'
    & $py -m pip --version *> $null
    if ($LASTEXITCODE -ne 0) { & $py -m ensurepip --upgrade *> $null }
    for ($try = 1; $try -le 3; $try++) {
        & $py -m pip install --disable-pip-version-check --no-warn-script-location --quiet playwright pandas openpyxl
        if ($LASTEXITCODE -ne 0) { & $py -m pip install --disable-pip-version-check --no-warn-script-location --quiet --user playwright pandas openpyxl }
        & $py -c "import playwright, pandas, openpyxl" 2>$null
        if ($LASTEXITCODE -eq 0) { break }
        if ($try -lt 3) { Wait-Countdown (15 * $try) 'Package install failed' }
    }
    & $py -c "import playwright, pandas, openpyxl" 2>$null
    if ($LASTEXITCODE -ne 0) {
        Stop-Launcher ("Could not install playwright / pandas / openpyxl.`n" +
            "Check this PC's internet connection (or proxy), then run this .cmd again.")
    }
}
$browserOk = $false
for ($try = 1; $try -le 3; $try++) {
    & $py -m playwright install chromium
    if ($LASTEXITCODE -eq 0) { $browserOk = $true; break }
    if ($try -lt 3) { Wait-Countdown (15 * $try) 'Browser download failed' }
}
if (-not $browserOk) {
    Stop-Launcher "Could not install the Chromium browser Playwright needs. Check the internet connection, then run this .cmd again."
}

# --- 3. this PC's IDMS login -------------------------------------------------------
$creds = Join-Path $appDir 'creds.txt'

function Test-Creds {
    if (-not (Test-Path $creds)) { return $false }
    $v = @(Get-Content $creds -Encoding UTF8 | Where-Object { $_.Trim() })
    return ($v.Count -ge 2 -and $v[1] -notmatch 'ENTER-YOUR-PASSWORD')
}
function Read-Creds {
    if ([Console]::IsInputRedirected) { Stop-Launcher "No IDMS login is saved on this PC. Double-click the .cmd (so it can ask for one), or put username / password on two lines in $creds." }
    Say ""
    Say "      Enter the IDMS login for sos.ammotors.in." 'Yellow'
    Say "      It is saved only on this PC ($creds)." 'DarkGray'
    $u = ''
    while (-not $u) { $u = (Read-Host "      Username").Trim() }
    $sp = Read-Host "      Password" -AsSecureString
    $bstr = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($sp)
    try { $pw = [Runtime.InteropServices.Marshal]::PtrToStringBSTR($bstr) }
    finally { [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($bstr) }
    [IO.File]::WriteAllLines($creds, @($u, $pw), (New-Object Text.UTF8Encoding($false)))
}

Say "[3/4] Checking the IDMS login..." 'Cyan'
if (-not (Test-Creds)) { Read-Creds } else { Say "      Using the login saved on this PC." 'DarkGray' }

# --- 4. download -------------------------------------------------------------------
# Reports land in the folder this .cmd is sitting in right now - wherever it
# has been moved or copied to. Only if that folder can't be written to (a
# read-only share, Program Files, a zip opened without extracting) does it
# fall back to Downloads\IDMS Reports\, and it says so.
function Test-Writable($dir) {
    try {
        $probe = Join-Path $dir (".idms_write_test_" + [guid]::NewGuid().ToString('N'))
        [IO.File]::WriteAllText($probe, '')
        Remove-Item $probe -Force
        return $true
    } catch { return $false }
}
$outDir = Split-Path -Parent $env:IDMS_SELF
$usedFallback = $false
if ($env:IDMS_SELF -match '\\Temp\d+_[^\\]+\.zip\\') {
    Say "      This .cmd was opened from inside a zip file - extract the zip first to save next to it." 'Yellow'
    $outDir = $null
}
if ($outDir -and -not (Test-Writable $outDir)) {
    Say "      Can't save into $outDir (read-only)." 'Yellow'
    $outDir = $null
}
if (-not $outDir) {
    $dl = $null
    try { $dl = (New-Object -ComObject Shell.Application).NameSpace('shell:Downloads').Self.Path } catch {}
    if (-not $dl -or -not (Test-Path $dl)) { $dl = Join-Path $env:USERPROFILE 'Downloads' }
    $outDir = Join-Path $dl 'IDMS Reports'
    New-Item -ItemType Directory -Force -Path $outDir | Out-Null
    $usedFallback = $true
    Say "      Saving to $outDir instead." 'Yellow'
}

$runDir = Join-Path $appDir 'cmd_runs'
New-Item -ItemType Directory -Force -Path $runDir | Out-Null
Get-ChildItem $runDir -File -ErrorAction SilentlyContinue |
    Where-Object { $_.LastWriteTime -lt (Get-Date).AddDays(-7) } | Remove-Item -Force -ErrorAction SilentlyContinue
$stamp   = Get-Date -Format 'yyyyMMdd_HHmmss_fff'
$pyFile  = Join-Path $runDir "IdmsDownload_$stamp.py"
$jobFile = Join-Path $runDir "job_$stamp.txt"
$status  = "$jobFile.status.txt"
$failed  = "$jobFile.failed.txt"
[IO.File]::WriteAllBytes($pyFile, [Convert]::FromBase64String(($pyB64 -replace '\s', '')))

function Read-Status {
    $s = @{}
    try {
        foreach ($l in [IO.File]::ReadAllLines($status)) { if ($l -match '^([^=]+)=(.*)$') { $s[$matches[1]] = $matches[2] } }
    } catch {}
    return $s
}

function Test-Portal {
    try {
        $r = Invoke-WebRequest -Uri $PortalUrl -UseBasicParsing -TimeoutSec 20 -Method Get
        return ($r.StatusCode -ge 200 -and $r.StatusCode -lt 500)
    } catch {
        $resp = $_.Exception.Response
        if ($resp -and [int]$resp.StatusCode -lt 500) { return $true }
        return $false
    }
}

function Wait-ForPortal {
    if (Test-Portal) { return $true }
    Say "      The portal is not answering - waiting for the network / portal to come back..." 'Yellow'
    $waited = 0
    while ($waited -lt $NetWaitMax) {
        Wait-Countdown 30 'Portal unreachable'
        $waited += 30
        if (Test-Portal) { Say "      Portal is reachable again." 'Green'; return $true }
    }
    return $false
}

# One download pass over $keys. Returns @{ status; message; failedKeys }.
function Invoke-Round([string[]]$keys) {
    Remove-Item $status, $failed -Force -ErrorAction SilentlyContinue
    $lines = @($baseLines) + @($keys | ForEach-Object { "report=$_" }) + "outdir=$outDir"
    [IO.File]::WriteAllLines($jobFile, $lines, (New-Object Text.UTF8Encoding($false)))

    $p = Start-Process -FilePath $py -ArgumentList @("`"$pyFile`"", '--run-file', "`"$jobFile`"") -NoNewWindow -PassThru
    $last = ''
    while (-not $p.HasExited) {
        Start-Sleep -Milliseconds 700
        if (-not (Test-Path $status)) { continue }
        $s = Read-Status
        if ($s['status'] -ne 'RUNNING') { continue }
        $line = "      [$($s['done'])/$($s['total'])] $($s['current'])"
        if ($s['message']) { $line += "  ($($s['message']))" }
        if ($line -ne $last) { Say $line; $last = $line }
    }
    $p.WaitForExit()
    $s = if (Test-Path $status) { Read-Status } else { @{ status = 'ERROR'; message = "the downloader stopped unexpectedly (exit code $($p.ExitCode))" } }
    $fk = @()
    if ($s['status'] -eq 'OK') {
        if (Test-Path $failed) { $fk = @(Get-Content $failed | Where-Object { $_.Trim() }) }
    } else {
        $fk = $keys   # nothing usable came back - all of them are still to do
    }
    return @{ status = $s['status']; message = $s['message']; failedKeys = $fk }
}

Say "[4/4] Downloading (a browser runs invisibly in the background)..." 'Cyan'
Say "      Saving into: $outDir" 'DarkGray'
$remaining = @($reportKeys)
$authFails = 0
$result = $null
for ($round = 1; $round -le $MaxRounds -and $remaining.Count -gt 0; $round++) {
    if ($round -gt 1) {
        $pause = $RoundPauses[[Math]::Min($round - 2, $RoundPauses.Count - 1)]
        Say ""
        Say ("      Round {0} of {1}: {2} report(s) still to download." -f $round, $MaxRounds, $remaining.Count) 'Yellow'
        Wait-Countdown $pause 'Waiting before retrying'
    }
    if (-not (Wait-ForPortal)) {
        $result = @{ status = 'UNREACHABLE'; message = 'the portal stayed unreachable' }
        break
    }
    $result = Invoke-Round $remaining
    switch ($result.status) {
        'OK' {
            $authFails = 0
            $remaining = @($result.failedKeys)
            if ($remaining.Count) {
                Say ("      {0} report(s) did not come through this round: {1}" -f $remaining.Count, (($remaining | ForEach-Object { $labelOf[$_] }) -join ', ')) 'Yellow'
            }
        }
        { $_ -in @('AUTH_FAILED', 'NO_CREDS') } {
            $authFails++
            Say "      Login did not go through: $($result.message)" 'Yellow'
            if ($_ -eq 'NO_CREDS' -or $authFails -ge 2) {
                Say "      Press P within 20 seconds to re-enter the password, or wait to retry automatically." 'Yellow'
                if ($_ -eq 'NO_CREDS' -or (Read-KeyWithin 20 'P')) { Read-Creds; $authFails = 0 }
            }
        }
        default {
            Say "      This round failed: $($result.message)" 'Yellow'
        }
    }
}

Remove-Item $pyFile, $jobFile, $status, $failed -Force -ErrorAction SilentlyContinue

Say ""
$done = $reportKeys.Count - $remaining.Count
if ($remaining.Count -eq 0) {
    Say "DONE: all $($reportKeys.Count) report(s) downloaded." 'Green'
    Say "Saved to: $outDir" 'Green'
    # the .cmd's own folder is already open in front of them; only pop a
    # window when the files went somewhere else
    if ($usedFallback -and (Test-Path $outDir)) { Start-Process explorer.exe "`"$outDir`"" }
    exit 0
}
Say "Finished with $done of $($reportKeys.Count) report(s) downloaded, after $MaxRounds rounds." 'Yellow'
Say ("Still missing: " + (($remaining | ForEach-Object { $labelOf[$_] }) -join ', ')) 'Red'
if ($result -and $result.message) { Say "Last message: $($result.message)" 'DarkGray' }
Say "Saved what did download to: $outDir" 'Yellow'
Say "Run this .cmd again later to fetch the rest - it will replace the files with fresh copies." 'DarkGray'
exit 2
