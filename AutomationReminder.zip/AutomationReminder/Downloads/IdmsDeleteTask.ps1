# ============================================================================
#  IdmsDeleteTask.ps1  -  permanently removes one IDMS scheduled download or
#  scheduled email: unregisters the real Windows Scheduled Task AND deletes
#  its associated config file (schedule/job .txt, plus any leftover
#  .status.txt/.regstatus.txt) so nothing orphaned is left behind in
#  %LOCALAPPDATA%\AutomationReminder\schedules\ or \emails\.
# ----------------------------------------------------------------------------
#  -Type schedule -> looks in \IDMS Scheduled\, recovers the config file via
#                    the task's own -ScheduleFile Action argument
#  -Type email    -> looks in \IDMS Email Scheduled\, recovers it via
#                    -JobFile
#  There is deliberately no "modify" - to change a schedule's time, reports,
#  path, or recipients, delete it here and create a new one with SCHEDULE
#  TASK or EMAIL. A real Scheduled Task's trigger can't be edited in place
#  through this same lightweight draft-file mechanism without either a much
#  larger UI or silently reusing a stale id/name, so recreate-don't-mutate
#  is the same tradeoff IdmsScheduleTask.ps1 already made deliberately (no
#  -Force on Register-ScheduledTask).
# ============================================================================

param(
    [Parameter(Mandatory)][string]$TaskName,
    [Parameter(Mandatory)][ValidateSet('schedule', 'email')][string]$Type
)
$ErrorActionPreference = 'Stop'
$appDir = Join-Path $env:LOCALAPPDATA 'AutomationReminder'
$statusFile = Join-Path $appDir 'idms_delete_status.txt'

$TaskPath = if ($Type -eq 'email') { '\IDMS Email Scheduled\' } else { '\IDMS Scheduled\' }
$argPattern = if ($Type -eq 'email') { '-JobFile\s+"([^"]+)"' } else { '-ScheduleFile\s+"([^"]+)"' }

function Write-Result($status, $msg) {
    $lines = @("status=$status", "time=$([DateTimeOffset]::UtcNow.ToUnixTimeSeconds())", "message=$msg")
    [IO.File]::WriteAllLines($statusFile, $lines, (New-Object System.Text.UTF8Encoding($false)))
}

try {
    $task = Get-ScheduledTask -TaskName $TaskName -TaskPath $TaskPath -ErrorAction SilentlyContinue
    if (-not $task) {
        Write-Result 'ERROR' "no $Type task named '$TaskName' found under $TaskPath - check the exact spelling/copy from the summary"
        exit 1
    }

    $configFile = $null
    $arg = $task.Actions[0].Arguments
    if ($arg -match $argPattern) { $configFile = $matches[1] }

    Unregister-ScheduledTask -TaskName $TaskName -TaskPath $TaskPath -Confirm:$false

    $removed = New-Object System.Collections.Generic.List[string]
    if ($configFile) {
        foreach ($suffix in @('', '.status.txt', '.regstatus.txt')) {
            $f = "$configFile$suffix"
            if (Test-Path $f) { Remove-Item $f -Force -ErrorAction SilentlyContinue; $removed.Add((Split-Path -Leaf $f)) }
        }
    }

    $detail = if ($removed.Count -gt 0) { " (removed: $($removed -join ', '))" } else { " (task removed - no config file found to clean up)" }
    Write-Result 'OK' "deleted '$TaskName'$detail"
} catch {
    Write-Result 'ERROR' ($_.Exception.Message -replace '[\r\n]+', ' ')
}
