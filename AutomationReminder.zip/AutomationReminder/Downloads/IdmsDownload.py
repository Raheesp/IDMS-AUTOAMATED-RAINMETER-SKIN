#!/usr/bin/env python3
# ============================================================================
#  IdmsDownload.py  -  ad-hoc multi-report downloader for the IDMS panel
# ----------------------------------------------------------------------------
#  Triggered by the "DOWNLOAD" button in the IDMS dropdown (Downloads.ini /
#  IdmsEngine.lua). Reads the user's report + date-mode selection, logs into
#  sos.ammotors.in ONCE, then walks every selected report page and downloads
#  it. Progress and the final result are written to a machine-local status
#  file the widget polls, same pattern as AutoDownload.py / _downloads.txt.
#
#  Selection file (written by the Lua, one "key=value" per line):
#     %LOCALAPPDATA%\AutomationReminder\idms_selection.txt
#        mode=asis | today | month | custom
#        dump=0|1              (CREATE DUMP toggle - see below)
#        combine=0|1           (only read when dump=1)
#        report=<key>          (repeated, one per selected report)
#
#  CREATE DUMP (dump=1) ignores the date-mode pill entirely and instead
#  downloads each date-driven report month by month, from a configurable
#  start month through the current month - one request per month, not one
#  big range, since that's how a person would build a year-to-date archive
#  by hand. Reports with no date filter at all (Stock, Priority Booking,
#  ...) just download once as-is, since iterating months would fetch the
#  same file seven times. combine=1 merges the month files into one file
#  per report (via pandas); combine=0 leaves them as separate month-named
#  files in a subfolder named after the report.
#
#  CREATE DUMP's start month, edited via the "DUMP FROM" label the same way
#  as the CUSTOM date range (opens in Notepad, save & close):
#     %LOCALAPPDATA%\AutomationReminder\idms_dump_from.txt
#        FROM=YYYY-MM          (e.g. FROM=2025-04 for "April last year")
#  Defaults to January of this year if the file is missing or unparsable.
#
#  Custom date range (only read when mode=custom), edited by the user via the
#  "CUSTOM" pill, which opens it in Notepad exactly like creds.txt:
#     %LOCALAPPDATA%\AutomationReminder\idms_range.txt
#        FROM=YYYY-MM-DD
#        TO=YYYY-MM-DD
#
#  asis mode does NOT touch any date field and does NOT click Filter/Search -
#  it goes straight to the download button with whatever the page loaded with
#  (the user's explicit "just download it as-is" request).
#
#  Shares creds.txt / the "UPDATE PASSWORD" notepad flow with AutoDownload.py.
# ============================================================================

import os, sys, time, re, shutil, subprocess, datetime, traceback

# Confirmed live: a report/error message containing a non-ASCII character
# (e.g. a portal page's own "->" arrow glyph) crashes a bare print() with
# UnicodeEncodeError when stdout is the Windows console's default codepage
# (cp1252) rather than UTF-8 - which then propagates up and overwrites an
# already-successful run's status with a contentless ERROR, wiping out the
# real per-report results that had already been written to disk. Console
# output here is only ever a human-readable echo of what write_status()
# already persisted, so it must never be able to take the whole run down.
for _stream in (sys.stdout, sys.stderr):
    try:
        _stream.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

APP_DIR   = os.path.join(os.environ.get("LOCALAPPDATA", os.path.expanduser("~")), "AutomationReminder")
CREDS     = os.path.join(APP_DIR, "creds.txt")
SELECTION = os.path.join(APP_DIR, "idms_selection.txt")
RANGEFILE = os.path.join(APP_DIR, "idms_range.txt")
MONTHSFILE = os.path.join(APP_DIR, "idms_months_custom.txt")
DUMPSTARTFILE = os.path.join(APP_DIR, "idms_dump_from.txt")
STATUS    = os.path.join(APP_DIR, "idms_status.txt")
AVAILABILITY_FILE = os.path.join(APP_DIR, "idms_availability.txt")
AVAIL_STATUS_FILE = os.path.join(APP_DIR, "idms_availability_status.txt")
DOWNLOADS = os.path.join(APP_DIR, "idms_downloads")
LOCKFILE  = os.path.join(APP_DIR, "idms_run.lock")
LOCK_STALE_SECS = 30 * 60

# Overridden per-invocation by run(run_file=...) for scheduled runs, so a
# scheduled download's status never collides with the shared idms_status.txt
# an ad-hoc DOWNLOAD click writes to (and vice versa, if both ever ran close
# together despite the lock below).
_STATUS_PATH = STATUS

LOGIN_URL    = "https://sos.ammotors.in/userlogin"
LOGIN_MARKER = "userlogin"
SEL_USER  = "#login-username"
SEL_PASS  = "#login-password"
SEL_LOGIN = "button:has-text('Login')"

DATE_FMT = "%Y-%m-%d"

# key -> label, url, date_from/date_to selectors (None = no date filter on this
# page), the Filter/Search button text (None = no filter step), the list of
# download-button texts to try in order, and optional sub-view "tabs" (only
# Follow Ups has these: Current / Overdue / Upcoming - each is downloaded as
# its own file whenever "followups" is selected).
REPORTS = {
    "pending_booking":     dict(label="Pending Booking Report",  url="https://sos.ammotors.in/PendingBookingReport",        df="#fromDate", dt="#toDate", filt="Filter",        dl=["Download"]),
    "booking":             dict(label="Booking Report",          url="https://sos.ammotors.in/booking-report",              df="#fromDate", dt="#toDate", filt="Filter",        dl=["Download"]),
    "registration":        dict(label="Registration Report",     url="https://sos.ammotors.in/registration_report",         df="#rrFromDate", dt="#rrToDate", filt="Filter",     dl=["Download"]),
    "docket":              dict(label="Docket Report",           url="https://sos.ammotors.in/docket_report",               df="#fromDate", dt="#toDate", filt="Filter",        dl=["Download"]),
    "stock":               dict(label="Stock Report",            url="https://sos.ammotors.in/stock-report",                df=None, dt=None, filt=None,                       dl=["Download"]),
    "sales":               dict(label="Sales Report",            url="https://sos.ammotors.in/sales-report",                df="#fromDate", dt="#toDate", filt="Filter",        dl=["Download"]),
    "invoice_pending":     dict(label="Invoice Pending Report",  url="https://sos.ammotors.in/invoicependingreport",        df=None, dt=None, filt=None,                       dl=["Download"]),
    "delivery":            dict(label="Delivery Report",         url="https://sos.ammotors.in/delivery-report",             df="#fromDate", dt="#toDate", filt="Filter",        dl=["Download"]),
    "ibnd":                dict(label="IBND Reports",            url="https://sos.ammotors.in/ibnd_reports",                df="#fromDate", dt="#toDate", filt="Filter",        dl=["Download"]),
    "docket_cancellation": dict(label="Docket Cancellation",     url="https://sos.ammotors.in/docket-cancellation",         df="#fromDate", dt="#toDate", filt="Filter",        dl=["Download"]),
    "idms_data_collection":dict(label="IDMS Data Collection",    url="https://sos.ammotors.in/idms-data-collection-report", df="input[type=date] >> nth=0", dt="input[type=date] >> nth=1", filt="Apply Filters", dl=["Download Excel"]),
    "enquiry":             dict(label="Enquiry Report",          url="https://sos.ammotors.in/enquiry-report",              df="#fromDate", dt="#toDate", filt="Filter",        dl=["Export Excel"]),
    "commitment":          dict(label="Commitment Report",       url="https://sos.ammotors.in/commitment_report",           df="input[type=date] >> nth=0", dt="input[type=date] >> nth=1", filt="Filter", dl=["Download"]),
    "docket_commitment":   dict(label="Docket Commitment Report",url="https://sos.ammotors.in/docket_commitment_report",    df="input[type=date] >> nth=0", dt="input[type=date] >> nth=1", filt="Filter", dl=["Download"]),
    "pdi_work":            dict(label="PDI Work Report",         url="https://sos.ammotors.in/pdi_work_report",             df="#fromDate", dt="#toDate", filt="Search",        dl=["Download"]),
    "lead_enquiry":        dict(label="Lead Enquiry Report",     url="https://sos.ammotors.in/lead_enquiry_report",         df="input[type=date] >> nth=0", dt="input[type=date] >> nth=1", filt="Filter", dl=["Download"]),
    "priority_booking":    dict(label="Priority Booking Report", url="https://sos.ammotors.in/priority_booking_report",     df=None, dt=None, filt=None,                       dl=["Download"]),
    "service_contact":     dict(label="Service Contact Report",  url="https://sos.ammotors.in/service_contact_report",      df="input[type=date] >> nth=0", dt="input[type=date] >> nth=1", filt="Filter", dl=["Download"]),
    "lost_enquiry":        dict(label="Lost Enquiry Report",     url="https://sos.ammotors.in/lost_enquiry_report",         df="input[type=date] >> nth=0", dt="input[type=date] >> nth=1", filt="Apply Filters", dl=["Download Excel"]),
    "event_request":       dict(label="Event Request Report",    url="https://sos.ammotors.in/event-request-report",        df=None, dt=None, filt=None,                       dl=["Download"], pre_select=[(0, "Event Request Date")]),
    "tax_invoice":         dict(label="Tax Invoice",             url="https://sos.ammotors.in/tax-invoice",                 df="#fromDate", dt="#toDate", filt="Search",        dl=["Download"]),
    "finalplan":           dict(label="Final Plan",              url="https://sos.ammotors.in/finalplan",                   df="#fromDate", dt="#toDate", filt="Filter",        dl=["Download"]),
    "taxlist":             dict(label="Tax List Report",         url="https://sos.ammotors.in/taxlist-report",              df="#fromDate", dt="#toDate", filt="Search",        dl=["Download"]),
    "priceviewlist":       dict(label="Price View List",         url="https://sos.ammotors.in/priceviewlist",               df=None, dt=None, filt=None,                       dl=["Download"]),
    "cancelled_without_doc":dict(label="Cancelled Without Document", url="https://sos.ammotors.in/cancelledwithoutdocument",df=None, dt=None, filt=None,                       dl=["Download"]),
    "cancelled_booking":   dict(label="Cancelled Booking",       url="https://sos.ammotors.in/cancelledbooking",            df=None, dt=None, filt=None,                       dl=["Download"]),
    "reg_number_status":   dict(label="Reg Number Status",       url="https://sos.ammotors.in/reg-number-status",           df=None, dt=None, filt=None,                       dl=["Download"]),
    "delivery_completed":  dict(label="Delivery Completed",      url="https://sos.ammotors.in/DeliveryComplted",            df="#fromDate", dt="#toDate", filt="Filter",        dl=["Download"]),
    "stock_view":          dict(label="Stock View",              url="https://sos.ammotors.in/stock-view",                  df=None, dt=None, filt=None,                       dl=["Download"]),
    "pending_reg_number":  dict(label="Pending Reg Number",      url="https://sos.ammotors.in/pending-registration-number", df=None, dt=None, filt=None,                       dl=["Download"]),
    "vftracking":          dict(label="Vehicle Financial Tracker",url="https://sos.ammotors.in/vftracking_report",           df="input[type=date] >> nth=0", dt="input[type=date] >> nth=1", filt="Filter", dl=["Download"]),
    # list_crm_enquiry has 3 tabs (ACTIVE/LOST/INCOMPLETE BOOKING) - same
    # tab= mechanism as the Follow Ups entries below. Confirmed real bug:
    # the single old "crm_enquiry" entry (no tab=) always downloaded
    # whichever tab happens to be default-active on page load, silently
    # never reaching the other two no matter what the user actually wanted.
    # INCOMPLETE BOOKING is deliberately NOT an entry here - confirmed live
    # (screenshot + full button inventory) that tab genuinely has no
    # Excel/export button anywhere on the page even with real data loaded
    # and paginated - a portal-side gap, not an automation timing issue.
    # See DISABLED_REPORTS below.
    "crm_enquiry_active":     dict(label="CRM Enquiry - Active",             url="https://sos.ammotors.in/list_crm_enquiry", df="input[type=date] >> nth=0", dt="input[type=date] >> nth=1", filt="Filter", dl=["Excel"], tab="ACTIVE"),
    "crm_enquiry_lost":       dict(label="CRM Enquiry - Lost",               url="https://sos.ammotors.in/list_crm_enquiry", df="input[type=date] >> nth=0", dt="input[type=date] >> nth=1", filt="Filter", dl=["Excel"], tab="LOST"),
    # Follow Ups is one page with three tabs (Current is the default view on
    # load). Each tab is its own selectable report, so picking "Follow Ups -
    # Overdue" alone doesn't also fetch the other two - plus one "All"
    # option for grabbing all three in a single click.
    "followups_current":   dict(label="Follow Ups - Current",    url="https://sos.ammotors.in/followups",                   df=None, dt=None, filt="Filter", dl=["Export Excel"], tab="CURRENT"),
    "followups_overdue":   dict(label="Follow Ups - Overdue",    url="https://sos.ammotors.in/followups",                   df=None, dt=None, filt="Filter", dl=["Export Excel"], tab="OVERDUE"),
    "followups_upcoming":  dict(label="Follow Ups - Upcoming",   url="https://sos.ammotors.in/followups",                   df=None, dt=None, filt="Filter", dl=["Export Excel"], tab="UPCOMING"),
    "followups_all":       dict(label="Follow Ups - All 3",      url="https://sos.ammotors.in/followups",                   df=None, dt=None, filt="Filter", dl=["Export Excel"], tabs=["CURRENT", "OVERDUE", "UPCOMING"]),
}
# ============================================================================


CREATE_NO_WINDOW = 0x08000000   # run notification helper with no console flash


def _ps_quote(s):
    return "'" + str(s).replace("'", "''") + "'"


def notify_windows(title, message, is_warning=False):
    """Best-effort Windows balloon/toast notification so a finished run gets
    noticed even if nobody's looking at the panel - e.g. 'some months' data
    wasn't available' shouldn't only live in a text file nobody opens.
    NotifyIcon (not the raw WinRT toast API) because it works out of the box
    without an app registration, on every Windows 10/11 box. Never allowed
    to break the actual download run - all errors here are swallowed."""
    try:
        icon = "Warning" if is_warning else "Info"
        ps = (
            "Add-Type -AssemblyName System.Windows.Forms;"
            "$n = New-Object System.Windows.Forms.NotifyIcon;"
            f"$n.Icon = [System.Drawing.SystemIcons]::{icon};"
            "$n.Visible = $true;"
            f"$n.ShowBalloonTip(10000, {_ps_quote(title)}, {_ps_quote(message)}, "
            f"[System.Windows.Forms.ToolTipIcon]::{icon});"
            "Start-Sleep -Seconds 11;"   # must outlive the balloon (10s) - disposing early hides it
            "$n.Dispose()"
        )
        subprocess.Popen(
            ["powershell", "-NoProfile", "-WindowStyle", "Hidden", "-Command", ps],
            creationflags=CREATE_NO_WINDOW,
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
        )
    except Exception:
        pass


def notify_run_complete(status, done, total, message):
    """Called once per run from write_status() whenever it lands on a
    terminal state (not the repeated RUNNING updates)."""
    if status == "OK":
        failed = "failed" in (message or "")
        title = "IDMS Download - some data unavailable" if failed else "IDMS Download Complete"
        body = message or f"{done}/{total} reports downloaded"
        notify_windows(title, body, is_warning=failed)
    elif status == "AUTH_FAILED":
        notify_windows("IDMS Download - login failed", "The portal didn't respond after several tries - usually temporary. Try again in a minute; if it keeps happening, check UPDATE PASSWORD.", is_warning=True)
    elif status == "UNREACHABLE":
        notify_windows("IDMS Download - portal unreachable", "Check network/VPN, then try again.", is_warning=True)
    elif status == "ERROR":
        notify_windows("IDMS Download - error", message or "Unknown error", is_warning=True)


def write_status(status, done=0, total=0, current="", message=""):
    """status = RUNNING | OK | AUTH_FAILED | UNREACHABLE | NO_CREDS | NO_SELECTION | ERROR"""
    os.makedirs(APP_DIR, exist_ok=True)
    lines = [
        f"status={status}", f"time={int(time.time())}", f"done={done}",
        f"total={total}", f"current={current}", f"message={message}",
    ]
    tmp = _STATUS_PATH + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        f.write("\n".join(lines) + "\n")
    os.replace(tmp, _STATUS_PATH)   # atomic, so the widget never reads a half file
    if status not in ("RUNNING", "NO_SELECTION", "NO_CREDS"):
        notify_run_complete(status, done, total, message)


def read_creds():
    with open(CREDS, encoding="utf-8-sig") as f:
        vals = [ln.strip() for ln in f if ln.strip()]
    if len(vals) < 2:
        raise ValueError("creds.txt needs username on line 1, password on line 2")
    return vals[0], vals[1]


def read_selection(path=None):
    """mode/dump/combine/outdir/datefolder + ordered list of selected report
    keys. path defaults to the live idms_selection.txt (ad-hoc DOWNLOAD
    flow); a scheduled run passes its own frozen per-schedule file instead.
    Unknown keys (RUNAT=/REPEAT=/TASKNAME=/TASKPATH=/DAYS=/EVERY=, written
    for the scheduler, not for us) are silently skipped, same as any other
    unrecognized line always has been."""
    if path is None:
        path = SELECTION
    mode, reports, dump, combine, outdir, datefolder = "asis", [], False, True, None, "off"
    with open(path, encoding="utf-8-sig") as f:
        for line in f:
            line = line.strip()
            if not line or "=" not in line:
                continue
            k, v = line.split("=", 1)
            k, v = k.strip(), v.strip()
            if k == "mode":
                mode = v
            elif k == "dump":
                dump = v == "1"
            elif k == "combine":
                combine = v == "1"
            elif k == "outdir":
                outdir = v or None
            elif k == "datefolder":
                datefolder = v if v in ("today", "yesterday") else "off"
            elif k == "report" and v in REPORTS:
                reports.append(v)
    return mode, reports, dump, combine, outdir, datefolder


def read_schedule_meta(path):
    """REPEAT=/TASKNAME=/TASKPATH= from a schedule file - used only at the
    end of a scheduled run to decide whether to self-unregister a one-shot
    task. Never called for the ordinary idms_selection.txt flow."""
    meta = {"REPEAT": "once", "TASKNAME": None, "TASKPATH": "\\IDMS Scheduled\\"}
    try:
        with open(path, encoding="utf-8-sig") as f:
            for line in f:
                line = line.strip()
                if "=" not in line:
                    continue
                k, v = line.split("=", 1)
                k = k.strip()
                if k in meta:
                    meta[k] = v.strip()
    except FileNotFoundError:
        pass
    return meta


def read_custom_range():
    """FROM=/TO= from idms_range.txt (edited by hand via Notepad). Falls back
    to 1st-of-month -> today for anything missing or unparsable."""
    first = datetime.date.today().replace(day=1).strftime(DATE_FMT)
    today = datetime.date.today().strftime(DATE_FMT)
    vals = {"FROM": first, "TO": today}
    try:
        with open(RANGEFILE, encoding="utf-8-sig") as f:
            for line in f:
                line = line.strip()
                if "=" in line:
                    k, v = line.split("=", 1)
                    k, v = k.strip().upper(), v.strip()
                    if k in vals and v:
                        vals[k] = v
    except FileNotFoundError:
        pass
    return vals["FROM"], vals["TO"]


def read_custom_months():
    """N (months back from today) from idms_months_custom.txt (MONTHS=N,
    edited by hand via Notepad). Falls back to 4 for anything missing or
    unparsable."""
    n = 4
    try:
        with open(MONTHSFILE, encoding="utf-8-sig") as f:
            for line in f:
                line = line.strip()
                if line.upper().startswith("MONTHS="):
                    try:
                        v = int(line.split("=", 1)[1].strip())
                        if v >= 1:
                            n = v
                    except ValueError:
                        pass
    except FileNotFoundError:
        pass
    return n


def months_ago_first(n):
    """1st of the month N months before this one (n=0 -> this month)."""
    d = datetime.date.today().replace(day=1)
    y, m = d.year, d.month - n
    while m < 1:
        m += 12
        y -= 1
    return datetime.date(y, m, 1)


def resolve_dates(mode):
    """(from, to) for the chosen mode, or (None, None) for asis (untouched)."""
    today = datetime.date.today()
    if mode == "today":
        d = today.strftime(DATE_FMT)
        return d, d
    if mode == "month":
        return months_ago_first(0).strftime(DATE_FMT), today.strftime(DATE_FMT)
    if mode == "lastmonth":
        first_this = months_ago_first(0)
        last_day_prev = first_this - datetime.timedelta(days=1)
        return months_ago_first(1).strftime(DATE_FMT), last_day_prev.strftime(DATE_FMT)
    if mode == "last1month":
        return months_ago_first(1).strftime(DATE_FMT), today.strftime(DATE_FMT)
    if mode == "last2months":
        return months_ago_first(2).strftime(DATE_FMT), today.strftime(DATE_FMT)
    if mode == "last3months":
        return months_ago_first(3).strftime(DATE_FMT), today.strftime(DATE_FMT)
    if mode == "lastnmonths":
        return months_ago_first(read_custom_months()).strftime(DATE_FMT), today.strftime(DATE_FMT)
    if mode == "custom":
        return read_custom_range()
    return None, None   # asis


def read_dump_start():
    """(year, month) CREATE DUMP should start from, read from
    idms_dump_from.txt (FROM=YYYY-MM, edited via Notepad same as the CUSTOM
    date range). Defaults to January of this year if missing/unparsable."""
    today = datetime.date.today()
    year, month = today.year, 1
    try:
        with open(DUMPSTARTFILE, encoding="utf-8-sig") as f:
            for line in f:
                line = line.strip()
                if line.upper().startswith("FROM="):
                    parts = line.split("=", 1)[1].strip().split("-")
                    if len(parts) >= 2:
                        try:
                            year, month = int(parts[0]), int(parts[1])
                        except ValueError:
                            pass
    except FileNotFoundError:
        pass
    if month < 1 or month > 12:
        month = 1
    return year, month


def dump_months():
    """[(label, from, to), ...] from the configured CREATE DUMP start month
    through the current month (which runs to today, not month-end). Capped
    at 60 months so a typo'd start year (e.g. 2005 instead of 2025) can't
    accidentally kick off a multi-hour run - that's still 5 years of history,
    far beyond anything this portal would realistically hold anyway."""
    start_year, start_month = read_dump_start()
    today = datetime.date.today()
    months = []
    y, m = start_year, start_month
    while (y, m) <= (today.year, today.month) and len(months) < 60:
        first = datetime.date(y, m, 1)
        if (y, m) == (today.year, today.month):
            last = today
        elif m == 12:
            last = datetime.date(y, 12, 31)
        else:
            last = datetime.date(y, m + 1, 1) - datetime.timedelta(days=1)
        months.append((f"{y}-{m:02d}", first.strftime(DATE_FMT), last.strftime(DATE_FMT)))
        m += 1
        if m > 12:
            m = 1
            y += 1
    return months


def prev_month_range(d_from_str):
    """Given a YYYY-MM-DD first-of-month string, (from, to) for the calendar
    month immediately before it - used by process_report_dump()'s per-month
    fallback below."""
    d = datetime.datetime.strptime(d_from_str, DATE_FMT).date()
    last_day_prev = d - datetime.timedelta(days=1)
    first_day_prev = last_day_prev.replace(day=1)
    return first_day_prev.strftime(DATE_FMT), last_day_prev.strftime(DATE_FMT)


def try_fill(page, selector, value):
    if not selector:
        return False
    try:
        page.fill(selector, value, timeout=8000)
        return True
    except Exception:
        return False


def new_browser_context(browser):
    """A plain browser.new_context() on a headless-launched browser
    announces itself two ways: navigator.webdriver reads True, and the
    User-Agent string literally contains "HeadlessChrome" instead of
    "Chrome" - both textbook automation tells. Confirmed via direct
    testing that this is exactly what our sessions were sending. Some
    backend bot-mitigation layers key off signals like this (often
    probabilistically/by pattern rather than an outright hard block),
    which lines up with the login flakiness seen in testing - clean in
    isolation, then failing repeatedly with no server-side error surfaced
    at all after a burst of automated traffic. Stripping "Headless" from
    the UA (keeping the real Chromium version intact) and making
    navigator.webdriver read as undefined removes both tells without
    changing anything about what the automation actually does.
    """
    tmp_page = browser.new_page()
    real_ua = tmp_page.evaluate("navigator.userAgent")
    tmp_page.close()
    ctx = browser.new_context(accept_downloads=True, user_agent=real_ua.replace("HeadlessChrome", "Chrome"))
    ctx.add_init_script("Object.defineProperty(navigator, 'webdriver', {get: () => undefined})")
    return ctx


def do_login(page, user, pw, attempts=8):
    """Log in, retrying on failure - observed intermittently during testing
    (login occasionally doesn't take on the first try, no error shown, just
    lands back on the login page). Root-caused via extensive isolated
    testing: read_creds(), the fill+click+networkidle sequence, and the
    browser fingerprint (see new_browser_context) are all confirmed
    correct - credentials are right (confirmed with the user directly) and
    the account isn't locked (confirmed by the user logging in manually on
    the same account while automated attempts were failing). What's real is
    genuine transient portal-side slowness that can, occasionally, last
    several minutes across a whole burst of attempts before clearing on its
    own - confirmed by watching a run of consecutive failures resolve into
    a run of consecutive successes with nothing client-side changed.
    attempts=8 with an increasing, capped backoff (roughly 6s up to 15s
    between tries, ~1.5-2 minutes worst case) gives those longer blips
    enough room to clear before this ever gets reported as a failure -
    much better than the user seeing an error and having to notice and
    retry by hand.
    """
    for attempt in range(1, attempts + 1):
        try:
            page.goto(LOGIN_URL, timeout=30000)
        except Exception:
            page.wait_for_timeout(2000)
            continue
        try_fill(page, SEL_USER, user)
        try_fill(page, SEL_PASS, pw)
        try:
            page.click(SEL_LOGIN, timeout=8000)
        except Exception:
            pass
        try:
            page.wait_for_load_state("networkidle", timeout=20000)
        except Exception:
            pass
        if LOGIN_MARKER not in page.url.lower():
            return True
        if attempt < attempts:
            page.wait_for_timeout(min(4000 + attempt * 2000, 15000))   # 6,8,10,12,14,15,15s
    return False


def click_text(page, text, timeout=6000):
    """Click a button/link/input whose visible text == text (exact match, so
    'Download' never accidentally matches 'Download Excel'). Real <button>
    and <input> controls are tried FIRST and exclusively - only if none
    match do we fall back to <a> tags. This matters because the site's top
    nav bar has a literal "Search" link on every page, which sits earlier
    in the DOM than a report's own Search/Filter button - matching <a> tags
    up front was navigating to the nav's global search page instead of
    filtering the report (confirmed live on Tax Invoice/PDI Work/Tax List,
    which all use a "Search" filter button)."""
    for selector in (":is(button, input[type=submit], input[type=button])", "a"):
        loc = page.locator(selector, has_text=text)
        for i in range(loc.count()):
            el = loc.nth(i)
            try:
                if el.inner_text().strip() == text or (el.get_attribute("value") or "").strip() == text:
                    el.click(timeout=timeout)
                    return True
            except Exception:
                continue
    # last resort: any element with that exact visible text (custom-styled controls)
    try:
        page.get_by_text(text, exact=True).first.click(timeout=timeout)
        return True
    except Exception:
        return False


def auto_select_all_placeholders(page):
    """Several report pages have Model/Variant/Colour/etc <select> filters
    that default to an unpicked '--Select X--' placeholder. Left alone, some
    of these make the export endpoint 500 (confirmed via network trace on
    Price View List). Wherever a dropdown is still on its placeholder AND has
    an 'All ...' option, pick that - it's the least surprising 'don't filter
    by this' choice and matches how a person would clear the report."""
    try:
        n = page.locator("select").count()
    except Exception:
        return
    for i in range(n):
        sel = page.locator("select").nth(i)
        try:
            texts = [t.strip() for t in sel.locator("option").all_inner_texts()]
            if not texts:
                continue
            idx = sel.evaluate("el => el.selectedIndex")
        except Exception:
            continue
        current = texts[idx] if 0 <= idx < len(texts) else texts[0]
        if not re.match(r"^-*\s*select\b", current, re.I):
            continue   # already has a real value picked
        all_opt = next((t for t in texts if re.match(r"^all\b", t, re.I)), None)
        if all_opt:
            try:
                sel.select_option(label=all_opt, timeout=3000)
            except Exception:
                pass


def apply_pre_select(page, pre_select):
    """cfg['pre_select'] = [(select_nth_index, option_text), ...] for the
    rare page where a dropdown has no 'All' option and a specific choice is
    required before the export works at all (e.g. Event Request Report's
    'Date type' picker - without it the export link 404s)."""
    for nth, option_text in pre_select or []:
        try:
            page.locator("select").nth(nth).select_option(label=option_text, timeout=5000)
        except Exception:
            pass


def ext_from(headers, url):
    ct = (headers.get("content-type") or "").lower()
    if "csv" in ct:
        return ".csv"
    if "sheet" in ct or "excel" in ct:
        return ".xlsx"
    if "pdf" in ct:
        return ".pdf"
    m = re.search(r"\.(xlsx|xls|csv|pdf)(\?|$)", url.lower())
    if m:
        return "." + m.group(1)
    return ".xlsx"


def _prepare_overwrite_target(out):
    """Every save always lands on the exact same filename, every time -
    never a Windows-style auto-incremented "name (1).ext", "name (2).ext"
    duplicate. This matters most now that a report can be on a recurring
    schedule: the point of a daily/interval pull is one fresh file in
    place, not an ever-growing pile of near-identical copies. Deletes the
    target first if it already exists, and cleans up any stray numbered
    siblings left over from the same base name so old copies don't linger
    once a fresh one lands. Raises PermissionError with a clear, specific
    message if the target is locked (e.g. open in Excel) rather than
    silently falling back to a different filename."""
    d = os.path.dirname(out) or "."
    base, ext = os.path.splitext(os.path.basename(out))
    if os.path.exists(out):
        try:
            os.remove(out)
        except PermissionError:
            raise PermissionError(
                f"{os.path.basename(out)} could not be overwritten - it may be open "
                f"in Excel or another program right now, close it and try again"
            )
    try:
        pattern = re.compile(r"^" + re.escape(base) + r" \(\d+\)" + re.escape(ext) + r"$")
        for name in os.listdir(d):
            if pattern.match(name):
                try:
                    os.remove(os.path.join(d, name))
                except OSError:
                    pass   # leftover duplicate cleanup is best-effort, never fatal
    except OSError:
        pass


def do_one(page, key, cfg, mode, d_from, d_to, suffix="", out_dir=None, out_name=None):
    """Fill dates (unless asis) -> click Filter/Search -> click Download.
    The site uses three different mechanisms across its 32 report pages for
    the actual file transfer: a same-page browser download, a popup tab that
    navigates straight to a signed export link, or a plain fetch()/XHR that
    the page turns into a blob download client-side. We listen for all three
    at once and use whichever fires. Returns (True, filepath) or (False, err).
    out_dir/out_name let CREATE DUMP save into a per-report subfolder with
    month-named files instead of the usual DOWNLOADS/key.ext.
    """
    ctx = page.context

    for step in cfg.get("pre_click", []):
        try:
            click_text(page, step, timeout=5000)
            page.wait_for_timeout(600)
        except Exception:
            pass

    # Dropdown state affects whether the export endpoint works at all
    # (confirmed 500s on unset Model/Variant/Colour filters) - this runs
    # regardless of date mode, since it's not a date filter.
    auto_select_all_placeholders(page)
    apply_pre_select(page, cfg.get("pre_select"))

    if mode != "asis":
        if cfg.get("df"):
            try_fill(page, cfg["df"], d_from)
        if cfg.get("dt"):
            try_fill(page, cfg["dt"], d_to)
        if cfg.get("filt"):
            try:
                click_text(page, cfg["filt"], timeout=6000)
                try:
                    page.wait_for_load_state("networkidle", timeout=20000)
                except Exception:
                    pass
                page.wait_for_timeout(1200)
                # Same "Loading..." placeholder race as goto_report()'s tab
                # switch - a Filter click can re-trigger it too.
                try:
                    page.get_by_text("Loading...", exact=True).first.wait_for(state="detached", timeout=15000)
                except Exception:
                    pass
            except Exception:
                pass
    # asis: touch nothing, go straight to the download button

    def looks_like_error_json(data):
        """A handful of pages return a normal 200 JSON payload (table data,
        or {"data":[]...}) on the same request pattern we key off of. Never
        accept that as a real file - a real xlsx/csv never starts with { or [."""
        head = data[:1]
        return head in (b"{", b"[")

    last_err = "no matching download button"
    for name in cfg.get("dl", ["Download"]):
        captured = {}

        def on_download(d):
            captured.setdefault("download", d)

        def on_popup(p):
            captured["popup"] = p
            # the popup itself is very often the actual browser download (a
            # signed link with Content-Disposition: attachment) - listen on
            # IT directly rather than re-fetching the (often single-use /
            # short-lived) URL ourselves after the fact.
            p.on("download", lambda d: captured.setdefault("popup_download", d))

        def on_response(resp):
            try:
                url_l, ct = resp.url.lower(), (resp.headers.get("content-type") or "").lower()
            except Exception:
                return
            if ("export" in url_l or "download" in url_l) and any(
                t in ct for t in ("excel", "csv", "spreadsheet", "octet-stream", "pdf")
            ):
                captured.setdefault("response", resp)
            elif resp.status >= 400 and ("export" in url_l or "download" in url_l or "signed_url" in url_l):
                captured.setdefault("server_error", (resp.status, resp.url))

        page.on("download", on_download)
        ctx.on("page", on_popup)
        page.on("response", on_response)
        try:
            if not click_text(page, name, timeout=6000):
                last_err = f"button '{name}' not found"
                continue
            for _ in range(60):   # up to ~30s - large reports (PDI Work, Follow Ups Upcoming) can take a while to build
                if any(k in captured for k in ("download", "popup_download", "response", "server_error")):
                    break
                page.wait_for_timeout(500)
        finally:
            page.remove_listener("download", on_download)
            ctx.remove_listener("page", on_popup)
            page.remove_listener("response", on_response)

        if not captured:
            last_err = "click produced no download, popup, or export response"
            continue

        out_base = os.path.join(out_dir or DOWNLOADS, (out_name or key) + suffix)
        try:
            if "download" in captured:
                d = captured["download"]
                ext = os.path.splitext(d.suggested_filename)[1] or ".xlsx"
                out = out_base + ext
                _prepare_overwrite_target(out)
                d.save_as(out)
                return True, out

            if "popup_download" in captured:
                d = captured["popup_download"]
                ext = os.path.splitext(d.suggested_filename)[1] or ".xlsx"
                out = out_base + ext
                _prepare_overwrite_target(out)
                d.save_as(out)
                if "popup" in captured:
                    try:
                        captured["popup"].close()
                    except Exception:
                        pass
                return True, out

            if "response" in captured:
                resp = captured["response"]
                body = resp.body()
                if looks_like_error_json(body):
                    last_err = f"export request returned JSON, not a file: {body[:120]!r}"
                    continue
                out = out_base + ext_from(resp.headers, resp.url)
                _prepare_overwrite_target(out)
                with open(out, "wb") as f:
                    f.write(body)
                return True, out

            if "popup" in captured:
                # last resort: the popup opened but never fired its own
                # download event - try re-fetching its URL directly.
                p = captured["popup"]
                try:
                    p.wait_for_load_state("load", timeout=8000)
                except Exception:
                    pass
                resp = ctx.request.get(p.url)
                try:
                    p.close()
                except Exception:
                    pass
                if not resp.ok:
                    last_err = f"export link returned HTTP {resp.status}"
                    continue
                body = resp.body()
                if looks_like_error_json(body):
                    last_err = f"export link returned JSON, not a file: {body[:120]!r}"
                    continue
                out = out_base + ext_from(resp.headers, p.url)
                _prepare_overwrite_target(out)
                with open(out, "wb") as f:
                    f.write(body)
                return True, out

            if "server_error" in captured:
                status, url = captured["server_error"]
                last_err = f"server returned HTTP {status} for the export request (site-side issue, not a login/automation problem)"
                continue
        except Exception as e:
            last_err = str(e)
            continue

    return False, last_err


def goto_report(page, cfg, tab=None):
    """(Re)load the report fresh - used both for the first attempt and
    before any retry, so a retry never inherits a stuck/partial UI state
    from the attempt that just failed. If tab is given (Follow Ups'
    Current/Overdue/Upcoming), click it and wait for the table to actually
    settle before returning - a fixed short wait was letting Upcoming's
    export fire before the switch from Overdue had finished, producing two
    identical files."""
    page.goto(cfg["url"], timeout=30000)
    try:
        page.wait_for_load_state("networkidle", timeout=20000)
    except Exception:
        pass
    page.wait_for_timeout(600)
    if LOGIN_MARKER in page.url.lower():
        return False
    if tab:
        try:
            page.get_by_text(tab, exact=True).first.click(timeout=5000)
        except Exception:
            pass
        try:
            page.wait_for_load_state("networkidle", timeout=10000)
        except Exception:
            pass
        page.wait_for_timeout(1200)
        # Some tabs (confirmed on CRM Enquiry's INCOMPLETE BOOKING) keep
        # showing a "Loading..." placeholder row well after networkidle
        # fires - the Excel button doesn't exist until that's gone.
        # Resolves immediately if no such placeholder is present at all.
        try:
            page.get_by_text("Loading...", exact=True).first.wait_for(state="detached", timeout=15000)
        except Exception:
            pass
    return True


RETRY_ATTEMPTS = 3   # extra same-range attempts before giving up on an explicit date choice


def _is_hard_failure(msg):
    """A failure that clicking the exact same button again won't fix - a
    server error, or a session that's no longer logged in. Confirmed live
    (33-report batch run): the generic transient misses (click/popup/export
    response never arrived, button not found yet) often DO succeed a try or
    two later, so those get the full retry budget even if the identical
    message repeats - cutting them short after one repeat, as an earlier
    version of this function did, was giving up before the retries that
    would have actually worked. Only bail early on failures that are
    structurally certain to repeat forever."""
    m = msg.lower()
    return "http 4" in m or "http 5" in m or "server returned" in m or "session dropped" in m


def do_one_with_fallback(page, key, cfg, mode, d_from, d_to, suffix="", tab=None, out_dir=None):
    """Two different resilience strategies, chosen by mode:

    - asis: the report's own default view has no fixed range to fall back
      within, so a miss is retried once against a genuinely different,
      well-defined window (last calendar month's 1st through today) -
      reported back to the caller as a substitution so it's never silently
      swapped in without the user knowing.

    - every other mode (TODAY, THIS MONTH, LAST MONTH, LAST 2/3 MONTHS,
      LAST N MONTHS, CUSTOM DATES... - an explicit range the user chose on
      purpose): never substituted for a different range. A miss here is far
      more often the site's export click missing - confirmed live,
      intermittent - than genuinely zero rows across the whole window, so
      it's retried against the *exact same* request, up to RETRY_ATTEMPTS
      more times, before being reported as failed. A report that genuinely
      has zero data in a range the user deliberately picked should fail
      honestly, not have a different range quietly handed back instead -
      that would defeat the point of picking one.

    Each retry/substitution attempt starts from a fresh page load (see
    goto_report), never reusing state left behind by the attempt before it.
    A server error (HTTP 500/404) or a page that never fires a download at
    all will keep failing the same way regardless of range or retries, so
    those still get reported honestly rather than papered over.

    Returns (ok, result, substitution_note) - substitution_note is only
    ever set for the asis case, since that's the only path that can hand
    back data for a different range than what was requested."""
    ok, res = do_one(page, key, cfg, mode, d_from, d_to, suffix, out_dir=out_dir)
    if ok:
        return ok, res, None

    if mode != "asis":
        tried = [res]
        for _ in range(RETRY_ATTEMPTS):
            if _is_hard_failure(tried[-1]):
                break   # a server error or a dead session won't start
                         # working just because we clicked it again
            if not goto_report(page, cfg, tab):
                tried.append("session dropped to login")
                break
            ok, res = do_one(page, key, cfg, mode, d_from, d_to, suffix, out_dir=out_dir)
            if ok:
                return True, res, None
            tried.append(res)
        return False, tried[0] + "".join(f" | retry: {t}" for t in tried[1:]), None

    # asis: one substitution attempt with a clearly-defined wider window.
    if not goto_report(page, cfg, tab):
        return False, res + " | Last Month through Today: session dropped to login", None
    fb_from, fb_to = resolve_dates("last1month")
    ok2, res2 = do_one(page, key, cfg, "last1month", fb_from, fb_to, suffix, out_dir=out_dir)
    if ok2:
        note = "your requested date range had no data - delivered Last Month through Today instead"
        return True, res2, note
    return False, f"{res} | Last Month through Today: {res2}", None


def process_report(page, key, mode, d_from, d_to, out_dir=None):
    """cfg['tabs'] (a list) means "download every one of these as its own
    file" (Follow Ups - All 3). cfg['tab'] (a single string) means "this
    report is permanently pinned to one tab" (Follow Ups - Current/Overdue/
    Upcoming picked individually). Neither is the common case.
    Returns (status, results, substitutions) - substitutions is a list of
    "label: note" strings for any report that succeeded using a broader
    date range than requested (see do_one_with_fallback)."""
    cfg = REPORTS[key]
    tabs = cfg.get("tabs")
    subs = []

    if tabs:
        out = []
        for tab in tabs:
            if not goto_report(page, cfg, tab):
                return "AUTH_FAILED", out, subs
            ok, res, sub = do_one_with_fallback(page, key, cfg, mode, d_from, d_to, suffix="_" + tab.lower(), tab=tab, out_dir=out_dir)
            out.append((tab, ok, res))
            if sub:
                subs.append(f"{cfg['label']} ({tab}): {sub}")
        return "OK", out, subs

    tab = cfg.get("tab")
    if not goto_report(page, cfg, tab):
        return "AUTH_FAILED", [], subs
    ok, res, sub = do_one_with_fallback(page, key, cfg, mode, d_from, d_to, tab=tab, out_dir=out_dir)
    if sub:
        subs.append(f"{cfg['label']}: {sub}")
    return "OK", [(None, ok, res)], subs


def combine_report_dump(key, month_results, out_dir=None):
    """Merge every successfully-downloaded month file for this report into
    one file (via pandas), then delete the per-month subfolder - the point
    of combine mode is a single clean file, not a folder of leftovers.
    Returns the combined file's path, or None if nothing could be merged."""
    try:
        import pandas as pd
    except ImportError:
        return None

    frames, ext = [], None
    for _label, ok, path in month_results:
        if not (ok and path and os.path.isfile(path)):
            continue
        try:
            if path.lower().endswith(".csv"):
                frames.append(pd.read_csv(path))
                ext = ext or ".csv"
            else:
                frames.append(pd.read_excel(path))
                ext = ext or ".xlsx"
        except Exception:
            continue
    if not frames:
        return None

    combined = pd.concat(frames, ignore_index=True)
    base = out_dir or DOWNLOADS
    out = os.path.join(base, key + "_dump_combined" + (ext or ".xlsx"))
    _prepare_overwrite_target(out)
    if ext == ".csv":
        combined.to_csv(out, index=False)
    else:
        combined.to_excel(out, index=False)
    shutil.rmtree(os.path.join(base, key), ignore_errors=True)
    return out


def process_report_dump(page, key, combine, run_done=0, run_total=0, out_dir=None):
    """CREATE DUMP: for a date-driven report, download the configured start
    month (idms_dump_from.txt, default January of this year) through the
    current month as separate per-month requests (one honest request per
    month, not one huge range) into DOWNLOADS/<key>/, then optionally merge
    them into one file. A month that's blank/fails does NOT stop the run -
    every remaining month is still attempted through to today, and whatever
    was found gets used. Reports with no date filter at all have nothing to
    iterate over - a month-by-month loop would just fetch the same file
    seven times - so those get a single plain download.
    run_done/run_total are the OUTER report-level progress (e.g. "5/35
    reports") - passed through so the live status line can show both that
    and which month of THIS report is currently being checked."""
    cfg = REPORTS[key]
    label = cfg["label"]

    base = out_dir or DOWNLOADS
    if cfg.get("tabs") or cfg.get("tab") or not cfg.get("df"):
        if not goto_report(page, cfg, cfg.get("tab")):
            return "AUTH_FAILED", []
        ok, res = do_one(page, key, cfg, "asis", None, None, out_dir=out_dir)
        return "OK", [(None, ok, res)]

    report_dir = os.path.join(base, key)
    os.makedirs(report_dir, exist_ok=True)
    out = []
    months = dump_months()
    found_months = []
    for i, (mlabel, d_from, d_to) in enumerate(months, 1):
        found_note = f"found: {', '.join(found_months)}" if found_months else "no data found yet"
        write_status("RUNNING", run_done, run_total, f"{label} - checking {mlabel} ({i}/{len(months)})", found_note)
        if not goto_report(page, cfg):
            return "AUTH_FAILED", out
        ok, res = do_one(page, key, cfg, "dump", d_from, d_to, out_dir=report_dir, out_name=key + "_" + mlabel)
        out_label = mlabel
        if not ok:
            # Confirmed real gap: unlike the single-shot download flow (which
            # automatically widens to This Month/Last Month/Last 2 Months/
            # As-is when a request comes back empty - see
            # do_one_with_fallback), each month here was just marked failed
            # and skipped with no retry at all. A failed do_one() means THIS
            # SPECIFIC request glitched (export error, button not found,
            # etc) - not that the dealership necessarily had zero real
            # activity that month - so retry once with the previous
            # calendar month's window before giving up on this slot.
            # Clearly labelled (never silently substituted) so a combined
            # file never misrepresents which month the data is actually
            # from.
            prev_from, prev_to = prev_month_range(d_from)
            write_status("RUNNING", run_done, run_total,
                         f"{label} - {mlabel} had no data, trying {prev_from[:7]} instead ({i}/{len(months)})", found_note)
            if not goto_report(page, cfg):
                return "AUTH_FAILED", out
            # Distinct filename (not key_<mlabel>) so the file on disk can
            # never be mistaken for genuine <mlabel> data if someone looks
            # in the dump folder without reading the status message.
            fallback_name = f"{key}_{mlabel}_used_{prev_from[:7]}"
            ok2, res2 = do_one(page, key, cfg, "dump", prev_from, prev_to, out_dir=report_dir, out_name=fallback_name)
            if ok2:
                ok, res = ok2, res2
                out_label = f"{mlabel} (used {prev_from[:7]} data - {mlabel} itself had none)"
        out.append((out_label, ok, res))
        if ok:
            found_months.append(out_label)

    if combine:
        combined_path = combine_report_dump(key, out, out_dir=out_dir)
        if combined_path:
            results = [("combined into 1 file", True, combined_path)]
            failed = [(label, ok, res) for label, ok, res in out if not ok]
            if failed:
                # Combining still succeeds with whatever months came back, but
                # silently merging past a failure would hide missing data
                # inside what looks like a complete file - surface it instead
                # (confirmed real case: Delivery Report months before Aug 2025
                # 404 on export, and got dropped from the merge unnoticed).
                missing = ", ".join(label for label, _, _ in failed)
                reasons = "; ".join(f"{label}: {res}" for label, _, res in failed)
                results.append((
                    f"missing {len(failed)} of {len(out)} month(s) from the combined file",
                    False,
                    f"{missing} could not be downloaded and are NOT included ({reasons})",
                ))
            return "OK", results
    return "OK", out


# ============================================================================
#  Data-availability scan - "what date range does each report actually have
#  data for?" so the IDMS panel can show it in a tooltip before you even hit
#  Download, instead of finding out via a failed export.
#
#  First attempt read the results table directly (fill dates, click Filter,
#  look at what rows came back) - rejected after testing showed it can't be
#  trusted. Not every report's date filter actually restricts the table by
#  the date column it displays: Booking Report's does (different months
#  give different row counts), but Docket Cancellation's filter appears to
#  key off a different date field than the one shown first per row, so
#  reading "the first date in each row" as the row's filtered date produced
#  a wrong, inconsistent range across repeated runs. There's no reliable
#  general way to know which displayed date column a given report's filter
#  actually keys off from the page alone.
#
#  So instead this uses the actual export mechanism (do_one(), the exact
#  code path a real Download click goes through) as ground truth: binary-
#  search month offsets, each probe a real throwaway download. "Has data"
#  here always means exactly what a real download would return, because it
#  IS a real download. Once the boundary month is found, the downloaded
#  file itself is opened and its date column read directly for the precise
#  earliest day - no more guessing from page text.
# ============================================================================

MAX_AVAILABILITY_MONTHS_BACK = 24
PROBE_DIR = os.path.join(APP_DIR, "idms_probe_tmp")


def month_offset_to_range(offset):
    """(from_date_str, to_date_str) for the calendar month `offset` months
    before this one (0 = this month, running to today not month-end)."""
    today = datetime.date.today()
    y, m = today.year, today.month - offset
    while m < 1:
        m += 12
        y -= 1
    first = datetime.date(y, m, 1)
    if offset == 0:
        last = today
    elif m == 12:
        last = datetime.date(y, 12, 31)
    else:
        last = datetime.date(y, m + 1, 1) - datetime.timedelta(days=1)
    return first.strftime(DATE_FMT), last.strftime(DATE_FMT)


def file_has_rows(filepath):
    """Best-effort check that a downloaded file has real data rows, not
    just headers. Some reports return a validly-formatted, empty file for
    a date range with nothing in it. Unreadable -> assume yes (a real
    export succeeding is already reasonable signal on its own)."""
    try:
        import pandas as pd
        df = pd.read_csv(filepath, nrows=2) if filepath.lower().endswith(".csv") else pd.read_excel(filepath, nrows=2)
        return len(df) > 0
    except Exception:
        return True


def extract_date_range(filepath):
    """Best-effort: find the report's primary date column (the first
    column whose name contains "date") and return (min, max) of its
    values as 'YYYY-MM-DD' strings. (None, None) if no usable column."""
    try:
        import pandas as pd
        df = pd.read_csv(filepath) if filepath.lower().endswith(".csv") else pd.read_excel(filepath)
        date_col = next((c for c in df.columns if "date" in str(c).lower()), None)
        if date_col is None:
            return (None, None)
        valid = pd.to_datetime(df[date_col], errors="coerce").dropna()
        if valid.empty:
            return (None, None)
        return (valid.min().strftime(DATE_FMT), valid.max().strftime(DATE_FMT))
    except Exception:
        return (None, None)


def probe_export(page, cfg, key, d_from, d_to, attempts=2):
    """Attempt a real (throwaway) export for [d_from, d_to] via the same
    do_one() path a real Download click uses. Returns (True, filepath) or
    (False, None) - caller owns cleanup of the returned file.
    Retries once on failure - confirmed live (Enquiry Report, 3 back-to-back
    attempts) that the export click can miss intermittently (no download/
    popup/response captured) even though the report genuinely has data and
    a normal Download click works fine a moment later. A probe that gives
    up after one flaky attempt would wrongly record a report as having no
    data at all."""
    for attempt in range(1, attempts + 1):
        if not goto_report(page, cfg):
            continue
        ok, res = do_one(page, key, cfg, "month", d_from, d_to, suffix="_probe", out_dir=PROBE_DIR, out_name=key)
        if ok:
            break
    else:
        return False, None
    if not file_has_rows(res):
        try:
            os.remove(res)
        except Exception:
            pass
        return False, None
    return True, res


def find_data_bounds(page, cfg, key):
    """Returns (earliest_date, latest_date) as 'YYYY-MM-DD' strings (or an
    'YYYY-MM-DD or earlier' earliest when data goes back past the search
    window). (None, None) means no data found at all; 'n/a' means the
    report has no date filter to search over."""
    if not cfg.get("df"):
        return ("n/a", "n/a")

    os.makedirs(PROBE_DIR, exist_ok=True)
    today_str = datetime.date.today().strftime(DATE_FMT)
    kept = []

    def probe(offset):
        d_from, d_to = month_offset_to_range(offset)
        ok, path = probe_export(page, cfg, key, d_from, d_to)
        if ok:
            kept.append(path)
        return path if ok else None

    def cleanup():
        for p in kept:
            try:
                os.remove(p)
            except Exception:
                pass

    path0 = probe(0)
    if not path0:
        cleanup()
        return (None, None)

    _, latest = extract_date_range(path0)
    latest = latest or today_str

    lo, hi = 0, MAX_AVAILABILITY_MONTHS_BACK
    boundary_path = path0
    path_hi = probe(hi)
    hit_cap = path_hi is not None
    if hit_cap:
        boundary_path = path_hi
    else:
        while hi - lo > 1:
            mid = (lo + hi) // 2
            path_mid = probe(mid)
            if path_mid:
                lo = mid
                boundary_path = path_mid
            else:
                hi = mid

    earliest, _ = extract_date_range(boundary_path)
    if earliest is None:
        earliest = month_offset_to_range(hi if hit_cap else lo)[0]
    if hit_cap:
        # only hedge with "or earlier" if going back to the cap actually
        # changed anything - some reports' exports return the same
        # underlying data no matter what range is requested (the date
        # filter is effectively decorative), in which case the cap probe
        # and the "this month" probe agree and this earliest IS the real
        # floor, not just the furthest point we happened to check
        earliest0, _ = extract_date_range(path0)
        if not (earliest0 and earliest0 == earliest):
            earliest = f"{earliest} or earlier"

    cleanup()
    return (earliest, latest)


def run_availability_scan():
    """Scans every date-driven report and writes idms_availability.txt:
    one line per report, 'key=YYYY-MM-DD to YYYY-MM-DD' (or a leading
    'YYYY-MM-DD or earlier' when data goes back past the search window),
    'key=none' (report has no data at all), or 'key=error: ...'. Reports
    with no date filter, or a fixed tab (Follow Ups), aren't date-range-
    scannable and are skipped entirely rather than written with a
    misleading value."""
    from playwright.sync_api import sync_playwright

    try:
        user, pw = read_creds()
    except (FileNotFoundError, ValueError) as e:
        with open(AVAIL_STATUS_FILE, "w", encoding="utf-8") as f:
            f.write(f"status=NO_CREDS\ntime={int(time.time())}\nmessage={e}\n")
        return

    # event_request/priceviewlist/cancelled_booking/delivery_completed are
    # temporarily removed from the UI (confirmed broken on the site's own
    # backend) - no point spending scan time on reports the user can't even
    # select right now. (crm_enquiry used to be in this set too, back when
    # it was a single broken entry with no tab= - re-tested and re-enabled
    # as two separate tab-based entries, crm_enquiry_active/crm_enquiry_lost,
    # see REPORTS above. The third tab, INCOMPLETE BOOKING, was tried too but
    # confirmed to have no Excel/export button on the site at all - not
    # added to REPORTS, so nothing to list here for it either.)
    DISABLED_REPORTS = {"event_request", "priceviewlist", "cancelled_booking", "delivery_completed"}
    scannable = [k for k, cfg in REPORTS.items()
                 if cfg.get("df") and not cfg.get("tab") and not cfg.get("tabs") and k not in DISABLED_REPORTS]
    total = len(scannable)
    results = {}

    def write_progress(done, current):
        with open(AVAIL_STATUS_FILE, "w", encoding="utf-8") as f:
            f.write(f"status=RUNNING\ntime={int(time.time())}\ndone={done}\ntotal={total}\ncurrent={current}\n")

    write_progress(0, "logging in...")
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=True)
        ctx = new_browser_context(browser)
        page = ctx.new_page()
        if not do_login(page, user, pw):
            with open(AVAIL_STATUS_FILE, "w", encoding="utf-8") as f:
                f.write(f"status=AUTH_FAILED\ntime={int(time.time())}\nmessage=login did not go through after several tries - the portal is usually just slow to respond, try again shortly (or check UPDATE PASSWORD if this keeps happening)\n")
            browser.close()
            return

        for i, key in enumerate(scannable, 1):
            write_progress(i - 1, REPORTS[key]["label"])
            try:
                earliest, latest = find_data_bounds(page, REPORTS[key], key)
                if earliest is None:
                    results[key] = "none"
                elif earliest == "n/a":
                    results[key] = "n/a"
                else:
                    results[key] = f"{earliest} to {latest}"
            except Exception as e:
                results[key] = f"error: {e}"

        browser.close()

    shutil.rmtree(PROBE_DIR, ignore_errors=True)

    with open(AVAILABILITY_FILE, "w", encoding="utf-8") as f:
        f.write(f"checked={datetime.date.today().strftime(DATE_FMT)}\n")
        for key, val in results.items():
            f.write(f"{key}={val}\n")

    with open(AVAIL_STATUS_FILE, "w", encoding="utf-8") as f:
        f.write(f"status=OK\ntime={int(time.time())}\ndone={total}\ntotal={total}\nmessage=checked {total} reports\n")
    print(f"availability scan done -> {total} reports checked")


def _acquire_lock():
    """Stale-safe lock so two downloads (two schedules firing close together,
    or a schedule firing during an ad-hoc DOWNLOAD click) never both log in
    and drive the portal at once - many portals invalidate the OTHER active
    session on a second concurrent login, which would corrupt both runs."""
    try:
        fd = os.open(LOCKFILE, os.O_CREAT | os.O_EXCL | os.O_RDWR)
        os.write(fd, str(os.getpid()).encode())
        os.close(fd)
        return True
    except FileExistsError:
        try:
            if time.time() - os.path.getmtime(LOCKFILE) > LOCK_STALE_SECS:
                os.remove(LOCKFILE)
                return _acquire_lock()
        except OSError:
            pass
        return False


def _release_lock():
    try:
        os.remove(LOCKFILE)
    except FileNotFoundError:
        pass


def _ps_quote(s):
    """Single-quote a value for embedding in a PowerShell -Command string."""
    return "'" + s.replace("'", "''") + "'"


def run(run_file=None):
    from playwright.sync_api import sync_playwright
    global _STATUS_PATH

    sel_path = run_file or SELECTION
    if run_file:
        _STATUS_PATH = run_file + ".status.txt"

    os.makedirs(DOWNLOADS, exist_ok=True)

    try:
        mode, reports, dump, combine, outdir, datefolder = read_selection(sel_path)
    except FileNotFoundError:
        write_status("NO_SELECTION", message=(
            "no selection file - pick reports in the IDMS panel first" if not run_file
            else f"schedule file not found: {run_file}"))
        return
    if not reports:
        write_status("NO_SELECTION", message="no reports selected")
        return

    try:
        user, pw = read_creds()
    except (FileNotFoundError, ValueError) as e:
        write_status("NO_CREDS", message=str(e))
        return

    out_dir_override = None
    if outdir:
        target_dir = outdir
        if datefolder in ("today", "yesterday"):
            # Computed fresh on every run (not baked in at schedule-creation
            # time) - this is what makes a recurring daily/weekly/interval
            # schedule land in a NEW dated folder each time it fires,
            # automatically, without ever revisiting this code.
            d = datetime.date.today()
            if datefolder == "yesterday":
                d -= datetime.timedelta(days=1)
            target_dir = os.path.join(outdir, d.strftime("%d-%m-%Y"))
        try:
            os.makedirs(target_dir, exist_ok=True)
            probe = os.path.join(target_dir, ".idms_write_test")
            open(probe, "w").close()
            os.remove(probe)
            out_dir_override = target_dir
        except Exception as e:
            write_status("ERROR", message=f"output path not writable: {target_dir} ({e})")
            return

    if not _acquire_lock():
        write_status("ERROR", message="another IDMS download is already running - try again shortly")
        return

    reached_ok = False
    try:
        d_from, d_to = resolve_dates(mode)
        total = len(reports)
        write_status("RUNNING", 0, total, "", "logging in...")

        notes, done = [], 0
        reports_with_issues = set()
        substitutions = []
        with sync_playwright() as p:
            browser = p.chromium.launch(headless=True)
            ctx = new_browser_context(browser)
            page = ctx.new_page()

            if not do_login(page, user, pw):
                write_status("AUTH_FAILED", 0, total, "", "login did not go through after several tries - the portal is usually just slow to respond, try again shortly (or check UPDATE PASSWORD if this keeps happening)")
                browser.close()
                return

            for key in reports:
                label = REPORTS[key]["label"]
                write_status("RUNNING", done, total, label + (" (dump)" if dump else ""), "")
                try:
                    if dump:
                        status, results = process_report_dump(page, key, combine, done, total, out_dir=out_dir_override)
                        subs = []
                    else:
                        status, results, subs = process_report(page, key, mode, d_from, d_to, out_dir=out_dir_override)
                except Exception as e:
                    notes.append(f"{label}: {e}")
                    reports_with_issues.add(key)
                    done += 1
                    continue
                if status == "AUTH_FAILED":
                    write_status("AUTH_FAILED", done, total, label, "session dropped back to the login page mid-run - usually a temporary portal hiccup, try again shortly")
                    browser.close()
                    return
                for tab, ok, res in results:
                    tag = f"{label} ({tab})" if tab else label
                    if not ok:
                        notes.append(f"{tag}: {res}")
                        reports_with_issues.add(key)
                substitutions.extend(subs)
                done += 1

            browser.close()

        # Anything that couldn't be downloaded is marked right in the downloads
        # folder (not just buried in a log) so it's obvious at a glance, and the
        # run always finishes and reports the rest rather than stopping cold.
        # notes can hold several entries per report (one per missing month in
        # CREATE DUMP), so report-level "X/Y ok" counts use reports_with_issues,
        # not len(notes) - otherwise a single dump-mode report with 12 missing
        # months could make the summary go negative.
        out_base = out_dir_override or DOWNLOADS
        marker = os.path.join(out_base, "0_FAILED_REPORTS.txt")
        if notes:
            with open(marker, "w", encoding="utf-8") as f:
                f.write(f"{len(reports_with_issues)} of {total} report(s) had an issue ({datetime.datetime.now().strftime('%Y-%m-%d %H:%M')}):\n\n")
                for n in notes:
                    f.write("- " + n + "\n")
        else:
            try:
                os.remove(marker)
            except FileNotFoundError:
                pass

        # Reports that came back empty for the requested range but succeeded
        # using a broader fallback get a file delivered either way - but the
        # user needs to know it's NOT what they originally asked for.
        sub_marker = os.path.join(out_base, "0_USED_WIDER_DATE_RANGE.txt")
        if substitutions:
            with open(sub_marker, "w", encoding="utf-8") as f:
                f.write(f"{len(substitutions)} report(s) had no data in your requested range, "
                         f"so the latest available data was delivered instead ({datetime.datetime.now().strftime('%Y-%m-%d %H:%M')}):\n\n")
                for s in substitutions:
                    f.write("- " + s + "\n")
        else:
            try:
                os.remove(sub_marker)
            except FileNotFoundError:
                pass

        failed = len(reports_with_issues)
        extra = []
        if failed:
            extra.append(f"{failed} failed - see 0_FAILED_REPORTS.txt")
        if substitutions:
            extra.append(f"{len(substitutions)} used a wider date range - see 0_USED_WIDER_DATE_RANGE.txt")
        write_status("OK", done, total, "", f"{done - failed}/{total} ok" + ("; " + "; ".join(extra) if extra else ""))
        reached_ok = True
        # Best-effort console echo of what was already written above - a
        # printing hiccup (confirmed live: an unencodable character from a
        # report/error message) must never take down a run that already
        # succeeded and already persisted its real status to disk.
        try:
            if notes:
                print("done with issues:")
                for n in notes:
                    print(" -", n)
            else:
                print(f"done -> {done}/{total} downloaded")
            if substitutions:
                print("used a wider date range for:")
                for s in substitutions:
                    print(" -", s)
        except Exception:
            pass
    finally:
        _release_lock()

    # A one-shot schedule that reached a real terminal "OK" (even if some
    # individual reports had issues - those are surfaced via
    # 0_FAILED_REPORTS.txt, not by keeping the task around) cleans itself up.
    # Never unregisters on AUTH_FAILED/NO_CREDS/ERROR - Task Scheduler is the
    # only durable record of the schedule (no separate list UI), so a failed
    # one-shot has to stay visible for a retry rather than vanish silently.
    if run_file and reached_ok:
        meta = read_schedule_meta(run_file)
        if meta["REPEAT"] == "once" and meta["TASKNAME"]:
            try:
                subprocess.run(
                    ["powershell", "-NoProfile", "-Command",
                     f"Unregister-ScheduledTask -TaskName {_ps_quote(meta['TASKNAME'])} "
                     f"-TaskPath {_ps_quote(meta['TASKPATH'])} -Confirm:$false"],
                    creationflags=subprocess.CREATE_NO_WINDOW, timeout=30,
                    stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            except Exception:
                pass


if __name__ == "__main__":
    if "--scan" in sys.argv:
        try:
            run_availability_scan()
        except Exception as e:
            with open(AVAIL_STATUS_FILE, "w", encoding="utf-8") as f:
                f.write(f"status=ERROR\ntime={int(time.time())}\nmessage={e}\n")
            traceback.print_exc()
    elif "--run-file" in sys.argv:
        try:
            run_file = sys.argv[sys.argv.index("--run-file") + 1]
        except IndexError:
            write_status("ERROR", message="--run-file given without a path")
        else:
            try:
                run(run_file=run_file)
            except Exception as e:
                write_status("ERROR", message=str(e))
                traceback.print_exc()
    else:
        try:
            run()
        except Exception as e:
            write_status("ERROR", message=str(e))
            traceback.print_exc()
