# ============================================================================
#  Setup.ps1  -  installs the PORTAL DATA downloader on this PC.
#  Run it by double-clicking Setup.bat (which calls this with the right policy).
#  Operates IN PLACE on the folder it lives in (the deployed Downloads config),
#  so it never copies files onto themselves.
# ============================================================================
$ErrorActionPreference = 'Stop'
$here = Split-Path -Parent $MyInvocation.MyCommand.Path

# How often the download runs (minutes). 15 is a good balance; 30 is lighter.
$IntervalMinutes = 15

function Say($m, $c = 'Gray') { Write-Host $m -ForegroundColor $c }

# Confirmed real bug this fixes: on some PCs (seen live - HRESULT 0x80070005
# "Access is denied", likely a restricted/managed-machine policy limiting who
# can register scheduled tasks), Register-ScheduledTask throws. With the
# script-wide $ErrorActionPreference='Stop' and no try/catch, that single
# failure used to abort the ENTIRE setup mid-script - credentials were never
# configured, Notepad never opened, and the second scheduled task was never
# even attempted, even though nothing about those later steps depended on
# this one succeeding. Now: try normal (non-elevated) registration first: if
# THAT fails specifically on access, retry once via a UAC-elevated child
# process (this resolves the access-denied case on every machine that isn't
# under an outright Group Policy block); if it still fails, report clearly
# and let the rest of Setup continue rather than taking everything else down
# with it.
function Register-TaskResilient {
    param(
        [string]$TaskName, [string]$Exe, [string]$Argument, [string]$AtTime,
        [int]$RepetitionMinutes = 0, [switch]$LongRunning, [string]$Description
    )
    try {
        $trigger = New-ScheduledTaskTrigger -Daily -At $AtTime
        if ($RepetitionMinutes -gt 0) {
            $trigger.Repetition = (New-ScheduledTaskTrigger -Once -At $AtTime `
                    -RepetitionInterval (New-TimeSpan -Minutes $RepetitionMinutes) `
                    -RepetitionDuration (New-TimeSpan -Days 1)).Repetition
        }
        $action = New-ScheduledTaskAction -Execute $Exe -Argument $Argument
        $settingsArgs = @{ MultipleInstances = 'IgnoreNew'; StartWhenAvailable = $true; AllowStartIfOnBatteries = $true; DontStopIfGoingOnBatteries = $true }
        if ($LongRunning) { $settingsArgs.ExecutionTimeLimit = (New-TimeSpan -Hours 2) }
        $settings = New-ScheduledTaskSettingsSet @settingsArgs
        Register-ScheduledTask -TaskName $TaskName -Action $action -Trigger $trigger `
            -Settings $settings -Description $Description -Force -ErrorAction Stop | Out-Null
        Say "Scheduled task '$TaskName' registered."
        return $true
    } catch {
        Say "Scheduled task '$TaskName' could not be registered (non-admin): $($_.Exception.Message)" 'Yellow'
        Say "  Retrying with an administrator prompt (a UAC window should appear)..." 'Yellow'
        $tmpScript = Join-Path $env:TEMP "setup_task_$([guid]::NewGuid().ToString('N').Substring(0,8)).ps1"
        # ' -> '' escaping so any apostrophe in these values (e.g. "panel's")
        # can't break out of the single-quoted strings in the generated script.
        $qExe = $Exe.Replace("'", "''"); $qArg = $Argument.Replace("'", "''"); $qDesc = $Description.Replace("'", "''")
        $repLine = if ($RepetitionMinutes -gt 0) {
            "`$t.Repetition = (New-ScheduledTaskTrigger -Once -At '$AtTime' -RepetitionInterval (New-TimeSpan -Minutes $RepetitionMinutes) -RepetitionDuration (New-TimeSpan -Days 1)).Repetition"
        } else { "" }
        $settingsLine = "New-ScheduledTaskSettingsSet -MultipleInstances IgnoreNew -StartWhenAvailable -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries" + $(if ($LongRunning) { " -ExecutionTimeLimit (New-TimeSpan -Hours 2)" } else { "" })
        @"
`$action = New-ScheduledTaskAction -Execute '$qExe' -Argument '$qArg'
`$t = New-ScheduledTaskTrigger -Daily -At '$AtTime'
$repLine
`$settings = $settingsLine
Register-ScheduledTask -TaskName '$TaskName' -Action `$action -Trigger `$t -Settings `$settings -Description '$qDesc' -Force | Out-Null
"@ | Set-Content $tmpScript -Encoding UTF8
        try {
            Start-Process powershell -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$tmpScript`"" -Verb RunAs -Wait -ErrorAction Stop
        } catch {
            Say "  Elevated retry was cancelled or failed: $($_.Exception.Message)" 'Red'
        }
        Remove-Item $tmpScript -Force -ErrorAction SilentlyContinue
        if (Get-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue) {
            Say "Scheduled task '$TaskName' registered (via elevated retry)." 'Green'
            return $true
        }
        Say "Scheduled task '$TaskName' still could not be registered. This PC's security policy may block task creation entirely - check with IT if it's a managed machine, or ask an administrator to run Setup.bat with 'Run as administrator'." 'Red'
        return $false
    }
}

Say "=== Portal Data downloader setup ===" 'Cyan'

# --- find a REAL Python (the Microsoft Store stub does not count) -----------
function Test-RealPython($p) {
    if (-not $p) { return $false }
    if ($p -like '*\WindowsApps\*') { return $false }   # Store execution-alias stub
    if (-not (Test-Path $p)) { return $false }
    try { $o = & $p -c "import sys;print(sys.executable)" 2>$null; return ($o -and (Test-Path ($o.Trim()))) }
    catch { return $false }
}
function Find-Python {
    # 1) the py launcher usually resolves the real install
    try { $e = (& py -3 -c "import sys;print(sys.executable)" 2>$null); if ($e) { $e = $e.Trim(); if (Test-RealPython $e) { return $e } } } catch {}
    # 2) every python.exe on PATH, skipping the store stub
    foreach ($g in (Get-Command python.exe -All -ErrorAction SilentlyContinue)) { if (Test-RealPython $g.Source) { return $g.Source } }
    # 3) common install locations
    $guesses = @("$env:USERPROFILE\anaconda3\python.exe", "$env:USERPROFILE\miniconda3\python.exe", "$env:ProgramData\anaconda3\python.exe")
    foreach ($d in @("$env:LOCALAPPDATA\Programs\Python", "$env:ProgramFiles\Python312", "$env:ProgramFiles\Python311")) {
        if (Test-Path $d) { Get-ChildItem $d -Recurse -Filter python.exe -ErrorAction SilentlyContinue | ForEach-Object { $guesses += $_.FullName } }
    }
    foreach ($g in $guesses) { if (Test-RealPython $g) { return $g } }
    return $null
}

$py = Find-Python
if (-not $py -and (Get-Command winget -ErrorAction SilentlyContinue)) {
    Say "No real Python found - installing Python 3.12 via winget..." 'Yellow'
    winget install -e --id Python.Python.3.12 --accept-source-agreements --accept-package-agreements --silent
    $py = Find-Python
}
if (-not $py) {
    Say "Python is not installed (the Microsoft Store stub does not count)." 'Red'
    Say "Install from https://www.python.org/downloads/ and tick 'Add python.exe to PATH', then run Setup again." 'Yellow'
    Say "Tip: Settings > Apps > Advanced app settings > App execution aliases -> turn OFF the two python.exe aliases." 'Yellow'
    exit 1
}
$pydir = Split-Path $py
$pyw = Join-Path $pydir 'pythonw.exe'
if (-not (Test-Path $pyw)) { $pyw = $py }
Say "Python:  $py"

# --- dependencies ----------------------------------------------------------
Say "Installing packages (playwright, pandas, openpyxl)..." 'Cyan'
& $py -m pip install --quiet --upgrade pip
& $py -m pip install --quiet --upgrade playwright pandas openpyxl
Say "Installing Chromium for Playwright..." 'Cyan'
& $py -m playwright install chromium

# --- point the widget at the real pythonw (in place) -----------------------
$ini = Join-Path $here 'Downloads.ini'
if (Test-Path $ini) {
    (Get-Content $ini) -replace '^PythonExe=.*', "PythonExe=$pyw" | Set-Content $ini -Encoding UTF8
    Say "Widget pointed at: $pyw"
}

# --- app dir + credentials template ----------------------------------------
$appdir = Join-Path $env:LOCALAPPDATA 'AutomationReminder'
New-Item -ItemType Directory -Force -Path $appdir | Out-Null
$creds = Join-Path $appdir 'creds.txt'
if (-not (Test-Path $creds)) { "AM09511`r`nENTER-YOUR-PASSWORD-HERE" | Set-Content $creds -Encoding UTF8 }

# --- AUTOMATION bar: live vs. view-only mode --------------------------------
# Confirmed real bug this fixes: IsSource lives in @Resources\Settings.inc,
# which - unlike creds.txt/_taskdata.txt/_taskhist.txt (all machine-local,
# under %LOCALAPPDATA%, never part of this folder) - IS part of the skin
# folder itself. SETUP.md's documented "just give them the whole folder, run
# Setup.bat" flow implicitly promises a live install out of the box, but
# copying the folder (instead of sharing it the Syncthing way SETUP.md is
# actually designed around, where each PC keeps its own local Settings.inc)
# silently carries over whatever IsSource value was set on the PC it was
# copied FROM. If that was 0 (view-only), the new PC never queries its own
# Task Scheduler at all - it just displays whatever's already sitting in
# ITS OWN %LOCALAPPDATA%\AutomationReminder\ from any earlier install,
# frozen forever. That looks exactly like "stuck showing another PC's old
# tasks and history that never updates" - confirmed this is exactly what
# happened when this folder was copied to a second PC.
$settingsInc = [System.IO.Path]::GetFullPath((Join-Path $here '..\@Resources\Settings.inc'))
Say ""
Say "Should this PC show its OWN live Task Scheduler in the AUTOMATION bar?" 'Cyan'
Say "  Y = yes, this PC runs the real automation tasks (default - most people want this)"
Say "  N = no, this is a view-only copy of someone else's schedule (see SETUP.md section 5)"
$srcAnswer = Read-Host "Live source? [Y/n]"
$isSource = if ($srcAnswer -match '^[Nn]') { '0' } else { '1' }
if (Test-Path $settingsInc) {
    $settingsContent = Get-Content $settingsInc
    if ($settingsContent -match '^IsSource=') {
        $settingsContent -replace '^IsSource=.*', "IsSource=$isSource" | Set-Content $settingsInc -Encoding UTF8
    } else {
        Add-Content $settingsInc "IsSource=$isSource" -Encoding UTF8
    }
} else {
    Say "Settings.inc not found at $settingsInc - skipping (Rainmeter will create it with a default the first time the skin loads; re-run Setup after that to set this properly)." 'Yellow'
}
if ($isSource -eq '1') {
    # Clear any cached schedule data from a previous install on THIS pc so
    # nothing stale from before ever shows, even briefly, before the first
    # real refresh completes.
    Remove-Item (Join-Path $appdir '_taskdata.txt') -Force -ErrorAction SilentlyContinue
    Remove-Item (Join-Path $appdir '_taskhist.txt') -Force -ErrorAction SilentlyContinue
    Say "IsSource=1 - this PC will query its own Task Scheduler every minute." 'Green'
} else {
    Say "IsSource=0 - this PC will only display schedule data synced in from elsewhere (see SETUP.md section 5)." 'Yellow'
}

# --- scheduled task: every $IntervalMinutes minutes, hidden ----------------
$script = Join-Path $here 'AutoDownload.py'
$dlTaskOk = Register-TaskResilient -TaskName 'AM DataDownloader' -Exe $pyw -Argument "`"$script`"" `
    -AtTime '12:00am' -RepetitionMinutes $IntervalMinutes `
    -Description "Downloads Booking/Docket/Enquiry every $IntervalMinutes min (self-gates around UiPath)."
if ($dlTaskOk) { Say "  -> every $IntervalMinutes minutes (self-checks for a 5-min gap; overlaps are skipped)." }

# --- scheduled task: IDMS data-availability scan, once a day ---------------
$idmsScript = Join-Path $here 'IdmsDownload.py'
$scanTaskOk = Register-TaskResilient -TaskName 'AM IdmsAvailabilityScan' -Exe $pyw -Argument "`"$idmsScript`" --scan" `
    -AtTime '3:00am' -LongRunning `
    -Description "Refreshes the IDMS panel's per-report data-availability ranges once a day."
if ($scanTaskOk) { Say "  -> once daily at 3:00am (also runnable on demand from the REFRESH button in the IDMS panel)." }

# --- let the user enter the password ---------------------------------------
Say ""
Say "Opening creds.txt - line 1 = username, line 2 = password. Save and close it." 'Yellow'
Start-Process notepad $creds

Say ""
if ($dlTaskOk -and $scanTaskOk) {
    Say "DONE." 'Green'
} else {
    Say "DONE, with one exception noted above in red - Python, packages, and credentials are all set up correctly regardless." 'Yellow'
    Say "The panel's own SCHEDULE TASK / EMAIL buttons register their own separate tasks the same way, so they may hit the same issue if this PC's policy blocks it." 'Yellow'
}
Say "In Rainmeter: Refresh all, then load AutomationReminder\Downloads\Downloads.ini." 'Green'
Say "Drag the PORTAL DATA bar just under the main AUTOMATION bar, then click RUN NOW."
