# ============================================================================
#  IdmsMakeCmd.ps1  -  builds a portable, double-clickable IDMS .cmd
# ----------------------------------------------------------------------------
#  Invoked by IdmsEngine.lua's MakeCmd() (the download icon next to DOWNLOAD
#  in the IDMS panel) with a request file holding the current selection:
#  mode/dump/combine/report= lines, fixed_* dates, and show_*/name labels.
#
#  The .cmd it writes to this PC's Downloads folder is self-contained:
#    batch header       -> reads the PS section back out of itself and runs it
#    :::IDMS:PS:::      -> IdmsCmdLauncher.ps1, verbatim
#    :::IDMS:JOB:::     -> the request lines (no password, ever)
#    :::IDMS:PY:::      -> IdmsDownload.py, base64 (ASCII-safe, cmd never parses it)
#  so it can be copied to any PC and run there with nothing else installed.
#
#  Result -> <Request>.status.txt (status=OK|ERROR, message=, path=), polled
#  by the Lua, plus an Explorer window with the new file selected.
# ============================================================================

param([Parameter(Mandatory)][string]$Request)
$ErrorActionPreference = 'Stop'
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$statusFile = "$Request.status.txt"

function Write-Result($status, $msg, $path = '') {
    $lines = @("status=$status", "time=$([DateTimeOffset]::UtcNow.ToUnixTimeSeconds())", "message=$msg", "path=$path")
    [IO.File]::WriteAllLines($statusFile, $lines, (New-Object System.Text.UTF8Encoding($false)))
}

try {
    $req = @(Get-Content $Request -Encoding UTF8 | Where-Object { $_ -match '^[^=]+=' })
    if (-not ($req | Where-Object { $_ -match '^report=' })) { Write-Result 'ERROR' 'no reports selected'; exit 1 }

    # ASCII only: cmd.exe reads the header as ANSI, and the launcher section
    # must survive any codepage. Labels here are plain English anyway.
    $ascii = { param($s) ($s -replace '[^\x20-\x7E]', '') }
    $name = (& $ascii (($req | Where-Object { $_ -match '^name=' } | Select-Object -First 1) -replace '^name=', '')).Trim()
    if (-not $name) { $name = 'IDMS reports' }
    $fileBase = ($name -replace '[^A-Za-z0-9 +._()-]', '').Trim()
    if ($fileBase.Length -gt 90) { $fileBase = $fileBase.Substring(0, 90).Trim() }

    $job = @($req | ForEach-Object { & $ascii $_ })
    $job += "created=$(Get-Date -Format 'yyyy-MM-dd HH:mm') on $env:COMPUTERNAME"

    $launcher = [IO.File]::ReadAllText((Join-Path $here 'IdmsCmdLauncher.ps1'))
    $pyBytes  = [IO.File]::ReadAllBytes((Join-Path $here 'IdmsDownload.py'))
    $b64 = [Convert]::ToBase64String($pyBytes)
    $b64Lines = for ($i = 0; $i -lt $b64.Length; $i += 76) { $b64.Substring($i, [Math]::Min(76, $b64.Length - $i)) }

    $titleName = $fileBase -replace '[()]', ''
    $header = @(
        '@echo off',
        'setlocal',
        "title IDMS download - $titleName",
        'rem  Portable IDMS report download, made by the AutomationReminder IDMS panel.',
        'rem  Double-click to run on any Windows PC. First run installs Python and the',
        'rem  download tools if needed and asks for that PC''s IDMS login.',
        'rem  The reports are saved into the folder this file is in when you run it.',
        'set "IDMS_SELF=%~f0"',
        'powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "$t=[IO.File]::ReadAllText($env:IDMS_SELF); $m=[regex]::Match($t,''(?ms)^:::IDMS:PS:::\r?\n(.*?)(?=^:::IDMS:)''); & ([scriptblock]::Create($m.Groups[1].Value))"',
        'set "IDMS_RC=%ERRORLEVEL%"',
        'echo.',
        'if "%IDMS_RC%"=="0" (',
        '  echo Done - this window closes in 10 seconds. Press any key to close it now.',
        '  timeout /t 10 >nul',
        '  exit /b 0',
        ')',
        'echo Something needs attention - read the messages above.',
        'pause',
        'exit /b %IDMS_RC%'
    )

    $all = @()
    $all += $header
    $all += ':::IDMS:PS:::'
    $all += ($launcher -replace "`r`n", "`n" -split "`n")
    $all += ':::IDMS:JOB:::'
    $all += $job
    $all += ':::IDMS:PY:::'
    $all += $b64Lines
    $content = ($all -join "`r`n") + "`r`n"

    $dl = $null
    try { $dl = (New-Object -ComObject Shell.Application).NameSpace('shell:Downloads').Self.Path } catch {}
    if (-not $dl -or -not (Test-Path $dl)) { $dl = Join-Path $env:USERPROFILE 'Downloads' }
    $target = Join-Path $dl "IDMS - $fileBase.cmd"
    $n = 2
    while (Test-Path $target) { $target = Join-Path $dl "IDMS - $fileBase ($n).cmd"; $n++ }

    [IO.File]::WriteAllText($target, $content, [Text.Encoding]::ASCII)
    Write-Result 'OK' "Saved $(Split-Path $target -Leaf) to Downloads - move it into any folder and double-click it; the reports download into that folder" $target
    Start-Process explorer.exe "/select,`"$target`""
} catch {
    Write-Result 'ERROR' $_.Exception.Message
    exit 1
}
