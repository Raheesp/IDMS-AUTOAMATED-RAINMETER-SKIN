# ============================================================================
#  IdmsEmailScheduleTask.ps1  -  registers one real Windows Scheduled Task
#  for an IDMS "EMAIL" request with a real TIME=/REPEAT= (not TIME=NOW,
#  which sends immediately without ever going through Task Scheduler at
#  all - see FinishEmailTask() in IdmsEngine.lua). Invoked once from Lua at
#  the moment a scheduled email is confirmed.
# ----------------------------------------------------------------------------
#  Trigger-building logic is a straight copy of IdmsScheduleTask.ps1's (see
#  that file's header comment for the full reasoning on each REPEAT mode,
#  the monthly-via-COM workaround, and the COM path-trailing-backslash
#  quirk) - only the Action differs: it points straight at
#  IdmsSendEmail.ps1 (no python-resolving shim needed, this is pure
#  PowerShell + Outlook COM, nothing to resolve at firing time).
# ============================================================================

param([Parameter(Mandatory)][string]$JobFile)
$ErrorActionPreference = 'Stop'
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$regStatusFile = "$JobFile.regstatus.txt"

$DAY_MAP = @{
    'Mon' = 'Monday';    'Tue' = 'Tuesday';  'Wed' = 'Wednesday'; 'Thu' = 'Thursday'
    'Fri' = 'Friday';    'Sat' = 'Saturday'; 'Sun' = 'Sunday'
}

function Write-Result($status, $msg) {
    $lines = @("status=$status", "time=$([DateTimeOffset]::UtcNow.ToUnixTimeSeconds())", "message=$msg")
    [IO.File]::WriteAllLines($regStatusFile, $lines, (New-Object System.Text.UTF8Encoding($false)))
}

try {
    if (-not (Test-Path $JobFile)) { Write-Result 'ERROR' "email job file not found: $JobFile"; exit 1 }

    $meta = @{
        REPEAT = 'once'; TASKNAME = $null; TASKPATH = '\IDMS Scheduled\'; RUNAT = $null; DAYS = $null
        MONTHS = $null; DAYOFMONTH = $null; EVERY = $null
    }
    foreach ($l in Get-Content $JobFile) {
        if ($l -match '^(RUNAT|REPEAT|TASKNAME|TASKPATH|DAYS|MONTHS|DAYOFMONTH|EVERY)=(.*)$') { $meta[$matches[1]] = $matches[2] }
    }
    if (-not $meta.TASKNAME -or -not $meta.RUNAT) { Write-Result 'ERROR' 'email job file missing TASKNAME/RUNAT'; exit 1 }

    $runAt = [datetime]::ParseExact($meta.RUNAT, 'yyyy-MM-dd HH:mm:ss', $null)

    $existing = Get-ScheduledTask -TaskName $meta.TASKNAME -TaskPath $meta.TASKPATH -ErrorAction SilentlyContinue
    if ($existing) { Write-Result 'ERROR' "a task named '$($meta.TASKNAME)' already exists"; exit 1 }

    $sendScript = Join-Path $here 'IdmsSendEmail.ps1'
    $action = New-ScheduledTaskAction -Execute 'powershell.exe' `
        -Argument "-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File `"$sendScript`" -JobFile `"$JobFile`""

    $trigger = $null
    switch ($meta.REPEAT) {
        'daily' {
            $trigger = New-ScheduledTaskTrigger -Daily -At $runAt.ToString('HH:mm')
        }
        'weekly' {
            if (-not $meta.DAYS) { Write-Result 'ERROR' 'REPEAT=weekly needs DAYS= set (e.g. DAYS=Mon,Wed,Fri)'; exit 1 }
            $days = @()
            foreach ($d in ($meta.DAYS -split ',')) {
                $key = $d.Trim()
                if (-not $key) { continue }
                if (-not $DAY_MAP.ContainsKey($key)) {
                    Write-Result 'ERROR' "invalid day '$key' in DAYS= - use Mon,Tue,Wed,Thu,Fri,Sat,Sun"
                    exit 1
                }
                $days += $DAY_MAP[$key]
            }
            if ($days.Count -eq 0) { Write-Result 'ERROR' 'DAYS= had no valid days'; exit 1 }
            $trigger = New-ScheduledTaskTrigger -Weekly -DaysOfWeek $days -At $runAt.ToString('HH:mm')
        }
        'monthly' {
            # Handled via raw COM below - see IdmsScheduleTask.ps1's header
            # comment for why New-ScheduledTaskTrigger -Monthly can't be used.
        }
        'interval' {
            if (-not $meta.EVERY) { Write-Result 'ERROR' 'REPEAT=interval needs EVERY= set (minutes)'; exit 1 }
            $mins = 0
            if (-not [int]::TryParse($meta.EVERY, [ref]$mins) -or $mins -lt 5) { Write-Result 'ERROR' 'EVERY= must be a whole number of 5 or more (minutes)'; exit 1 }
            $trigger = New-ScheduledTaskTrigger -Daily -At $runAt.ToString('HH:mm')
            $trigger.Repetition = (New-ScheduledTaskTrigger -Once -At $runAt.ToString('HH:mm') `
                    -RepetitionInterval (New-TimeSpan -Minutes $mins) `
                    -RepetitionDuration (New-TimeSpan -Days 1)).Repetition
        }
        default {
            $trigger = New-ScheduledTaskTrigger -Once -At $runAt
        }
    }

    if ($meta.REPEAT -eq 'monthly') {
        if (-not $meta.MONTHS -or -not $meta.DAYOFMONTH) { Write-Result 'ERROR' 'REPEAT=monthly needs MONTHS= and DAYOFMONTH= set'; exit 1 }
        $n = 0; $day = 0
        if (-not [int]::TryParse($meta.MONTHS, [ref]$n) -or $n -lt 1) { Write-Result 'ERROR' 'MONTHS= must be a whole number of 1 or more'; exit 1 }
        if (-not [int]::TryParse($meta.DAYOFMONTH, [ref]$day) -or $day -lt 1 -or $day -gt 31) { Write-Result 'ERROR' 'DAYOFMONTH= must be between 1 and 31'; exit 1 }

        $svc = New-Object -ComObject "Schedule.Service"
        $svc.Connect()
        $rootFolder = $svc.GetFolder("\")
        $folderPath = '\' + $meta.TASKPATH.Trim('\')
        $idmsFolder = $null
        try { $idmsFolder = $svc.GetFolder($folderPath) } catch {}
        if (-not $idmsFolder) {
            try { $idmsFolder = $rootFolder.CreateFolder($meta.TASKPATH.Trim('\')) } catch { $idmsFolder = $svc.GetFolder($folderPath) }
        }

        $def = $svc.NewTask(0)
        $def.RegistrationInfo.Description = "IDMS scheduled report email (created $(Get-Date -Format 'yyyy-MM-dd HH:mm'))"
        $def.Settings.Enabled = $true
        $def.Settings.StartWhenAvailable = $true
        $def.Settings.DisallowStartIfOnBatteries = $false
        $def.Settings.StopIfGoingOnBatteries = $false
        $def.Settings.MultipleInstances = 2

        $TASK_TRIGGER_MONTHLY = 4
        $trig = $def.Triggers.Create($TASK_TRIGGER_MONTHLY)
        $trig.StartBoundary = $runAt.ToString("yyyy-MM-ddTHH:mm:ss")
        $trig.DaysOfMonth = [uint32]([math]::Pow(2, $day - 1))
        $MONTH_BITS = @(1,2,4,8,16,32,64,128,256,512,1024,2048)
        $startIdx = $runAt.Month - 1
        $bits = 0
        for ($i = 0; $i -lt 12; $i += $n) { $bits = $bits -bor $MONTH_BITS[($startIdx + $i) % 12] }
        $trig.MonthsOfYear = $bits
        $trig.Enabled = $true

        $TASK_ACTION_EXEC = 0
        $act = $def.Actions.Create($TASK_ACTION_EXEC)
        $act.Path = "powershell.exe"
        $act.Arguments = "-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File `"$sendScript`" -JobFile `"$JobFile`""

        $TASK_CREATE_OR_UPDATE = 6
        $TASK_LOGON_INTERACTIVE_TOKEN = 3
        $idmsFolder.RegisterTaskDefinition($meta.TASKNAME, $def, $TASK_CREATE_OR_UPDATE, $null, $null, $TASK_LOGON_INTERACTIVE_TOKEN) | Out-Null

        Write-Result 'OK' "scheduled email '$($meta.TASKNAME)' for $($meta.RUNAT) (monthly, every $n month(s), day $day)"
        exit 0
    }

    $settings = New-ScheduledTaskSettingsSet -MultipleInstances IgnoreNew -StartWhenAvailable `
        -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries

    Register-ScheduledTask -TaskName $meta.TASKNAME -TaskPath $meta.TASKPATH `
        -Action $action -Trigger $trigger -Settings $settings `
        -Description "IDMS scheduled report email (created $(Get-Date -Format 'yyyy-MM-dd HH:mm'))" | Out-Null

    Write-Result 'OK' "scheduled email '$($meta.TASKNAME)' for $($meta.RUNAT) ($($meta.REPEAT))"
} catch {
    # See IdmsScheduleTask.ps1's matching catch block for the full reasoning
    # - same fix, same access-denied scenario, same idempotent-retry-elevated
    # approach (this script builds the exact same trigger from the same
    # frozen $JobFile every time, so a clean re-run is safe).
    if ($_.Exception.Message -match 'Access is denied' -and $meta -and $meta.TASKNAME) {
        try {
            Start-Process powershell -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$($MyInvocation.MyCommand.Path)`" -JobFile `"$JobFile`"" -Verb RunAs -Wait -ErrorAction Stop
            if (Test-Path $regStatusFile) { exit 0 }
        } catch {
            # elevation itself was cancelled/denied - fall through below.
        }
    }
    Write-Result 'ERROR' ($_.Exception.Message -replace '[\r\n]+', ' ')
}
