# ============================================================================
#  IdmsSendEmail.ps1  -  downloads (fresh, every time) and sends one IDMS
#  report email via Outlook COM automation. Invoked either directly
#  (immediate "EMAIL" -> CONFIRM EMAIL with TIME=NOW) or as a registered
#  Scheduled Task's Action (recurring email delivery, registered by
#  IdmsEmailScheduleTask.ps1).
# ----------------------------------------------------------------------------
#  Reads TO=/CC=/SUBJECT=/BODY=/mode=/report=.../REPEAT=/TASKNAME= from the
#  job file IdmsEngine.lua writes (idms_email_<id>.txt). REPEAT/TASKNAME
#  are only used here to decide whether to self-unregister a one-shot task
#  on success - RUNAT/DAYS/EVERY/MONTHS/TASKPATH are only meaningful to
#  IdmsEmailScheduleTask.ps1 at registration time and ignored here.
#
#  Before composing anything, this ALWAYS triggers a fresh download of
#  every selected report - by passing this same job file straight to
#  IdmsDownload.py as its own --run-file (mode=/dump=0/combine=1/report=
#  lines make it directly valid for that; TO=/CC=/SUBJECT=/etc are just
#  unrecognized keys IdmsDownload.py's parser already ignores, same
#  "one frozen file, multiple readers" pattern used everywhere else in this
#  codebase). Confirmed real bug this fixes: emailing a fresh selection the
#  user had never separately clicked DOWNLOAD for used to silently skip
#  every one of those reports instead of just fetching them.
#
#  If that fresh download fails outright (most commonly: the portal login
#  didn't succeed even after IdmsDownload.py's own extended retry budget -
#  confirmed live to occasionally run several minutes past that), this does
#  NOT just give up. It copies (never moves - the master files in
#  idms_downloads are never touched) whatever previously-downloaded file
#  already exists for each selected report into a throwaway staging
#  folder under %TEMP% and sends those instead, with a clear red banner
#  prepended to the email body naming the reason and the as-of timestamp
#  of the data, so nobody mistakes a stale copy for a fresh one. Only
#  fails outright if not even one selected report has ever been downloaded
#  before. The staging folder is deleted after send regardless of outcome.
#
#  IdmsDownload.py's own portal-concurrency lock (_acquire_lock) already
#  covers this call for free - it's the exact same function every other
#  entry point (ad-hoc DOWNLOAD, scheduled downloads) goes through.
#
#  Always writes "$JobFile.status.txt" - polled directly by IdmsEngine.lua
#  for an immediate send, and read later by IdmsListEmails.ps1 for a
#  scheduled one (same convention IdmsDownload.py uses for its own
#  <schedule>.status.txt).
# ============================================================================

param([Parameter(Mandatory)][string]$JobFile)
$ErrorActionPreference = 'Stop'
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$statusFile = "$JobFile.status.txt"
$downloadsDir = Join-Path $env:LOCALAPPDATA 'AutomationReminder\idms_downloads'
$logoPath = Join-Path $here 'am_motors_logo.png'
$templatePath = Join-Path $here 'IdmsEmailTemplate.html'
$emailLockFile = Join-Path $env:LOCALAPPDATA 'AutomationReminder\idms_email_run.lock'
$EMAIL_LOCK_STALE_SECS = 30 * 60
$downloadIni = Join-Path $here 'Downloads.ini'

function Write-Status($status, $msg) {
    $lines = @("status=$status", "time=$([DateTimeOffset]::UtcNow.ToUnixTimeSeconds())", "message=$msg")
    [IO.File]::WriteAllLines($statusFile, $lines, (New-Object System.Text.UTF8Encoding($false)))
}

# Stale-safe lock so two emails (two schedules firing close together, or a
# schedule firing during an ad-hoc EMAIL click) never both drive Outlook COM
# at once - concurrent Outlook automation from separate processes is a known
# source of intermittent COM errors, same reasoning as IdmsDownload.py's
# _acquire_lock() for the portal (different resource, same shape of problem).
function Acquire-EmailLock {
    try {
        $fs = [System.IO.File]::Open($emailLockFile, [System.IO.FileMode]::CreateNew, [System.IO.FileAccess]::Write)
        $w = New-Object System.IO.StreamWriter($fs)
        $w.Write([string]$PID)
        $w.Flush(); $w.Close(); $fs.Close()
        return $true
    } catch {
        if (Test-Path $emailLockFile) {
            # Confirmed real bug this fixes: a process holding this lock
            # that gets hard-killed (e.g. by Rainmeter's own RunCommand
            # Timeout) never reaches its `finally` block, so the lock
            # never gets released through the normal path - it used to
            # just sit there blocking every other email for up to the
            # full 30-minute staleness window even though the owning
            # process was already long dead. Checking whether that PID is
            # still actually running reclaims a lock like that
            # immediately instead of making everyone wait out the clock.
            $ownerDead = $false
            $ownerPid = Get-Content $emailLockFile -ErrorAction SilentlyContinue
            if ($ownerPid -and -not (Get-Process -Id $ownerPid -ErrorAction SilentlyContinue)) {
                $ownerDead = $true
            }
            $age = (Get-Date) - (Get-Item $emailLockFile).LastWriteTime
            if ($ownerDead -or $age.TotalSeconds -gt $EMAIL_LOCK_STALE_SECS) {
                Remove-Item $emailLockFile -Force -ErrorAction SilentlyContinue
                return Acquire-EmailLock
            }
        }
        return $false
    }
}
function Release-EmailLock {
    Remove-Item $emailLockFile -Force -ErrorAction SilentlyContinue
}

function Format-Size($bytes) {
    if ($bytes -ge 1MB) { return "{0:N1} MB" -f ($bytes / 1MB) }
    return "{0:N0} KB" -f ([math]::Max(1, [math]::Round($bytes / 1KB)))
}

function HtmlEscape($s) {
    return $s.Replace('&', '&amp;').Replace('<', '&lt;').Replace('>', '&gt;')
}

# Most report keys produce exactly one file named "<key>.ext". A handful
# (currently only followups_all) are a combined multi-tab entry that
# IdmsDownload.py saves as several files instead - "<key>_<tab>.ext", one
# per tab (see process_report()'s tabs= branch, suffix="_" + tab.lower()).
# Confirmed real bug this fixes: EMAIL always reported followups_all as
# "no file available at all" even immediately after a successful fresh
# download of all three of its files, because this lookup only ever
# checked for the exact base name. Falls back to the "<key>_*.ext" pattern
# and attaches every match it finds instead of just the first.
function Find-ReportFiles($dir, $key) {
    $matches = Get-ChildItem -Path $dir -Filter "$key.*" -File -ErrorAction SilentlyContinue
    if (-not $matches) {
        $matches = Get-ChildItem -Path $dir -Filter "$key`_*.*" -File -ErrorAction SilentlyContinue
    }
    return $matches
}

# Same resolution IdmsRunSchedule.ps1 uses: re-read Downloads.ini's
# PythonExe= fresh on every firing (not baked in once), fall back to
# whatever's on PATH, so a later Python reinstall doesn't quietly break
# every existing schedule/email.
function Resolve-Pythonw {
    $pyw = $null
    if (Test-Path $downloadIni) {
        $line = Get-Content $downloadIni | Where-Object { $_ -match '^PythonExe=' } | Select-Object -First 1
        if ($line) { $pyw = ($line -split '=', 2)[1].Trim() }
    }
    if (-not $pyw -or -not (Test-Path $pyw)) {
        $cmd = Get-Command pythonw.exe -ErrorAction SilentlyContinue
        if ($cmd) { $pyw = $cmd.Source }
    }
    return $pyw
}

try {
    if (-not (Test-Path $JobFile)) { Write-Status 'ERROR' "email job file not found: $JobFile"; exit 1 }

    $job = @{ TO = ''; CC = ''; SUBJECT = ''; BODY = ''; REPEAT = 'once'; TASKNAME = $null; TASKPATH = '\IDMS Scheduled\' }
    $reports = New-Object System.Collections.Generic.List[string]
    foreach ($l in Get-Content $JobFile) {
        if ($l -match '^(TO|CC|SUBJECT|BODY|REPEAT|TASKNAME|TASKPATH)=(.*)$') { $job[$matches[1]] = $matches[2] }
        elseif ($l -match '^report=(.+)$') { $reports.Add($matches[1]) }
    }
    if (-not $job.TO) { Write-Status 'ERROR' 'job file missing TO='; exit 1 }
    if ($reports.Count -eq 0) { Write-Status 'ERROR' 'job file has no reports listed'; exit 1 }

    # Written immediately, before the (potentially several-minutes-long)
    # download/send work starts - confirmed real bug this prevents: this
    # script previously wrote NOTHING until its very last line, so if the
    # whole run ever got killed or crashed anywhere along the way (e.g. the
    # Rainmeter RunCommand measure's own Timeout expiring), no status file
    # ever existed at all and IdmsEngine.lua's poll - which just returns
    # and tries again if the file isn't there yet - was stuck showing
    # "Sending... opening Outlook..." forever with no way to ever recover
    # on its own, even though the email had, in that case, actually sent.
    Write-Status 'RUNNING' 'downloading reports before sending...'

    # --- fresh download of every selected report, every time ---------------
    # The job file already contains mode=/dump=0/combine=1/report= lines
    # (written by FinishEmailTask()), so it's directly usable as-is - BUT
    # passed under a DIFFERENT run_file path (a filtered copy), not
    # $JobFile itself, for two independent reasons:
    #  1. IdmsDownload.py derives its own status filename by appending
    #     ".status.txt" to whatever run_file it's given - using $JobFile
    #     directly would make that the exact same file this script's own
    #     Write-Status writes the FINAL email result to ($statusFile),
    #     which IdmsEngine.lua's poll watches continuously. A mid-download
    #     "RUNNING" line landing there would be misread as a
    #     failed/finished result while the download is still in progress.
    #  2. A SCHEDULED email's job file carries its own REPEAT=/TASKNAME=/
    #     TASKPATH= (pointing at \IDMS Email Scheduled\, for the email's
    #     own task). If those lines were copied through, IdmsDownload.py's
    #     run() would see REPEAT=once + a real TASKNAME= and self-unregister
    #     the EMAIL's scheduled task right after the download step - before
    #     the email has even been sent, silently defeating the "only
    #     remove on confirmed success" rule for a step that isn't the real
    #     success yet. So those three fields are stripped from the copy;
    #     self-unregistration only ever happens from this script's own
    #     logic below, after Send() has actually completed.
    $pyw = Resolve-Pythonw
    if (-not $pyw) {
        Write-Status 'ERROR' 'pythonw.exe could not be found - re-run Setup.ps1'
        exit 1
    }
    $dlRunFile = "$JobFile.dl.txt"
    Get-Content $JobFile | Where-Object { $_ -notmatch '^(REPEAT|TASKNAME|TASKPATH)=' } |
        Set-Content $dlRunFile -Encoding UTF8
    $dlStatusFile = "$dlRunFile.status.txt"
    Remove-Item $dlStatusFile -Force -ErrorAction SilentlyContinue
    $idmsDownloadPy = Join-Path $here 'IdmsDownload.py'
    Start-Process -FilePath $pyw -ArgumentList "`"$idmsDownloadPy`" --run-file `"$dlRunFile`"" -WindowStyle Hidden -Wait

    $dlStatus = @{ status = 'ERROR'; message = 'download did not report a result' }
    if (Test-Path $dlStatusFile) {
        $dl = @{}
        foreach ($l in Get-Content $dlStatusFile) {
            if ($l -match '^([^=]+)=(.*)$') { $dl[$matches[1]] = $matches[2] }
        }
        $dlStatus.status = $dl.status
        $dlStatus.message = $dl.message
    }
    Remove-Item $dlRunFile, $dlStatusFile -Force -ErrorAction SilentlyContinue

    # --- fallback: fresh download failed outright (most commonly a portal
    # login blip that outlasted even do_login()'s extended retry budget) ---
    # Rather than failing the whole email, fall back to whatever's already
    # sitting in the main Downloads folder for the selected reports - a
    # previous copy is far more useful to the recipient than nothing, as
    # long as it's clearly labelled as not-fresh so nobody mistakes it for
    # live data. Copies (never moves) into a throwaway staging folder so
    # the master files in $downloadsDir are never disturbed.
    $usedFallback = $false
    $fallbackNote = $null
    $stagingDir = $null
    $sourceDir = $downloadsDir
    if ($dlStatus.status -ne 'OK') {
        $stagingDir = Join-Path $env:TEMP ("idms_email_fallback_" + [guid]::NewGuid().ToString('N').Substring(0, 8))
        New-Item -ItemType Directory -Force -Path $stagingDir | Out-Null
        $anyFallback = $false
        foreach ($key in $reports) {
            $srcs = Find-ReportFiles $downloadsDir $key
            foreach ($src in $srcs) {
                Copy-Item $src.FullName -Destination $stagingDir -Force
                $anyFallback = $true
            }
        }
        if (-not $anyFallback) {
            Write-Status 'ERROR' "could not download reports before sending ($($dlStatus.message)), and no previously-downloaded copy exists for any selected report"
            Remove-Item $stagingDir -Recurse -Force -ErrorAction SilentlyContinue
            exit 1
        }
        $usedFallback = $true
        $fallbackNote = $dlStatus.message
        $sourceDir = $stagingDir
    }

    # --- locate the file(s) for each selected report (fresh, or fallback copy) -
    $found = New-Object System.Collections.Generic.List[System.IO.FileInfo]
    $missing = New-Object System.Collections.Generic.List[string]
    foreach ($key in $reports) {
        $matches = Find-ReportFiles $sourceDir $key
        if ($matches) { foreach ($m in $matches) { $found.Add($m) } } else { $missing.Add($key) }
    }
    if ($found.Count -eq 0) {
        Write-Status 'ERROR' "download reported success but no files were found for: $($missing -join ', ')"
        if ($stagingDir) { Remove-Item $stagingDir -Recurse -Force -ErrorAction SilentlyContinue }
        exit 1
    }

    if (-not (Acquire-EmailLock)) {
        Write-Status 'ERROR' 'another email is currently being sent - try again shortly'
        if ($stagingDir) { Remove-Item $stagingDir -Recurse -Force -ErrorAction SilentlyContinue }
        exit 1
    }
    Write-Status 'RUNNING' 'downloads done - composing and sending via Outlook...'
    try {

    # --- build the HTML body from the template ------------------------------
    if (-not (Test-Path $templatePath)) { Write-Status 'ERROR' "email template not found: $templatePath"; exit 1 }
    $template = Get-Content $templatePath -Raw

    $subject = if ($job.SUBJECT) { $job.SUBJECT } else { 'IDMS DATA' }
    $bodyText = if ($job.BODY) { $job.BODY } else { 'Please find the attached report(s) below.' }
    $paragraphs = ($bodyText -split '\|') | ForEach-Object { "<p style=`"margin:0 0 14px 0;`">$(HtmlEscape $_)</p>" }
    if ($usedFallback) {
        # Prepended, not appended, same "lead with what matters" reasoning
        # as the SKIPPED message ordering below - a recipient scanning the
        # email should see immediately that this isn't live data.
        $oldest = ($found | Sort-Object LastWriteTime | Select-Object -First 1).LastWriteTime
        $staleP = "<p style=`"margin:0 0 14px 0; padding:10px 12px; background-color:#FBEAEA; border-left:3px solid #B23B3B; color:#7A2222; font-weight:600;`">Note: the IDMS portal could not be reached just now ($(HtmlEscape $fallbackNote)), so this email uses the most recently downloaded copy of each report (as of $($oldest.ToString('dd-MMM-yyyy HH:mm')) or earlier) rather than freshly downloaded data.</p>"
        $paragraphs = @($staleP) + $paragraphs
    }
    $bodyHtml = [string]::Join("`r`n      ", $paragraphs)

    $rows = foreach ($f in $found) {
        $sizeStr = Format-Size $f.Length
        "<tr><td style=`"padding:10px 14px; font-family:'Segoe UI', Arial, Helvetica, sans-serif; font-size:13px; color:#1E2733; border-top:1px solid #EEF1F4;`"><span style=`"display:inline-block; width:8px; height:8px; background-color:#2E6FD9; margin-right:9px;`">&nbsp;</span>$(HtmlEscape $f.Name)</td><td align=`"right`" style=`"padding:10px 14px; font-family:'Segoe UI', Arial, Helvetica, sans-serif; font-size:12px; color:#67727E; font-variant-numeric:tabular-nums; border-top:1px solid #EEF1F4; white-space:nowrap;`">$sizeStr</td></tr>"
    }
    $attachmentRows = [string]::Join("`r`n        ", $rows)

    # --- Outlook COM: reuse a running instance, or launch one of our own ---
    $startedOutlook = $false
    $outlook = $null
    try { $outlook = [Runtime.InteropServices.Marshal]::GetActiveObject('Outlook.Application') } catch { $outlook = $null }
    if (-not $outlook) {
        $outlook = New-Object -ComObject 'Outlook.Application'
        $startedOutlook = $true
        Start-Sleep -Seconds 2   # give Outlook a moment to finish initializing before CreateItem
    }

    $senderName = 'A.M. Motors'
    try { $senderName = $outlook.Session.CurrentUser.Name } catch {}

    $filled = $template
    $filled = $filled.Replace('{{SUBJECT}}', (HtmlEscape $subject))
    $filled = $filled.Replace('{{REPORT_TITLE}}', (HtmlEscape $subject))
    $filled = $filled.Replace('{{REPORT_DATE}}', (Get-Date -Format 'dd-MMM-yyyy'))
    $filled = $filled.Replace('{{GREETING}}', 'Hello Team,')
    $filled = $filled.Replace('{{BODY_TEXT}}', $bodyHtml)
    $filled = $filled.Replace('{{ATTACHMENT_ROWS}}', $attachmentRows)
    $filled = $filled.Replace('{{CTA_BLOCK}}', '')
    $filled = $filled.Replace('{{SENDER_NAME}}', (HtmlEscape $senderName))
    $filled = $filled.Replace('{{YEAR}}', (Get-Date).Year.ToString())

    $olMailItem = 0
    $mail = $outlook.CreateItem($olMailItem)
    $mail.To = ($job.TO -replace ',', ';')
    if ($job.CC) { $mail.CC = ($job.CC -replace ',', ';') }
    $mail.Subject = $subject

    # Logo first, as a hidden inline attachment referenced by cid: in the
    # HTML body - must be attached BEFORE HTMLBody is assigned so Outlook
    # links the Content-ID correctly.
    if (Test-Path $logoPath) {
        $logoAttach = $mail.Attachments.Add($logoPath)
        $PR_ATTACH_CONTENT_ID = 'http://schemas.microsoft.com/mapi/proptag/0x3712001E'
        $PR_ATTACHMENT_HIDDEN = 'http://schemas.microsoft.com/mapi/proptag/0x7FFE000B'
        $logoAttach.PropertyAccessor.SetProperty($PR_ATTACH_CONTENT_ID, 'am_motors_logo')
        $logoAttach.PropertyAccessor.SetProperty($PR_ATTACHMENT_HIDDEN, $true)
    }
    foreach ($f in $found) { $mail.Attachments.Add($f.FullName) | Out-Null }

    $mail.HTMLBody = $filled
    $mail.Send()

    # --- wait until it actually leaves the Outbox, don't just assume Send() means sent ---
    $sentOk = $false
    $deadline = (Get-Date).AddSeconds(30)
    while ((Get-Date) -lt $deadline) {
        Start-Sleep -Seconds 2
        try {
            $outbox = $outlook.Session.GetDefaultFolder(4)   # olFolderOutbox
            if ($outbox.Items.Count -eq 0) { $sentOk = $true; break }
        } catch { break }
    }

    if ($startedOutlook) {
        try { $outlook.Quit() } catch {}
    }
    [Runtime.InteropServices.Marshal]::ReleaseComObject($mail) | Out-Null
    [Runtime.InteropServices.Marshal]::ReleaseComObject($outlook) | Out-Null
    [GC]::Collect(); [GC]::WaitForPendingFinalizers()

    $sentList = ($found | ForEach-Object { $_.Name }) -join ', '
    # SKIPPED leads the message, not trails it - the Rainmeter status line
    # is narrow and clips long text from the end, so a trailing "skipped"
    # note could silently never be seen. Confirmed live: exactly this
    # happened - a 2-of-3-reports-missing send showed only "...with..." and
    # gave no visible indication anything was skipped.
    $msg = "sent '$subject' to $($job.TO) with $($found.Count) file(s): $sentList"
    if ($usedFallback) { $msg = "used previously-downloaded copies (fresh download failed: $fallbackNote) - " + $msg }
    if ($missing.Count -gt 0) { $msg = "skipped (no file available at all): $($missing -join ', ') - " + $msg }
    if (-not $sentOk) { $msg = "queued (still in Outbox after 30s, may send shortly): $msg" }
    Write-Status 'OK' $msg

    # Self-unregister a one-shot scheduled email, same as IdmsDownload.py
    # does for one-shot downloads - never on failure, so a failed attempt
    # isn't silently erased and can be retried/inspected.
    if ($job.REPEAT -eq 'once' -and $job.TASKNAME) {
        try {
            powershell -NoProfile -Command "Unregister-ScheduledTask -TaskName '$($job.TASKNAME)' -TaskPath '$($job.TASKPATH)' -Confirm:`$false" | Out-Null
        } catch {}
    }

    } finally {
        Release-EmailLock
        if ($stagingDir) { Remove-Item $stagingDir -Recurse -Force -ErrorAction SilentlyContinue }
    }
} catch {
    Write-Status 'ERROR' ($_.Exception.Message -replace '[\r\n]+', ' ')
}
