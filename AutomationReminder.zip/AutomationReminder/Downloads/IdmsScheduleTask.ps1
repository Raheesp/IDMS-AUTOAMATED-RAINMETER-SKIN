# ============================================================================
#  IdmsScheduleTask.ps1  -  registers one real Windows Scheduled Task for an
#  IDMS "SCHEDULE TASK" request, invoked once from IdmsEngine.lua at the
#  moment a schedule is created.
# ----------------------------------------------------------------------------
#  Reads RUNAT=/REPEAT=/TASKNAME=/TASKPATH=/DAYS= from the same frozen
#  per-schedule file IdmsDownload.py's read_selection()/read_schedule_meta()
#  already parse (mode=/dump=/combine=/report=/outdir= lines are ignored
#  here - this script only cares about the scheduling fields).
#
#  REPEAT=once    -> New-ScheduledTaskTrigger -Once -At <RUNAT>
#  REPEAT=daily   -> New-ScheduledTaskTrigger -Daily -At <time-of-day>
#  REPEAT=weekly  -> New-ScheduledTaskTrigger -Weekly -DaysOfWeek <DAYS> -At <time-of-day>
#                    DAYS= is a comma list of 3-letter abbreviations
#                    (Mon,Tue,Wed,Thu,Fri,Sat,Sun) - mapped to the full
#                    day names -DaysOfWeek actually expects.
#  REPEAT=monthly -> New-ScheduledTaskTrigger -Monthly -DaysOfMonth <DAYOFMONTH> -Months <list> -At <time-of-day>
#                    Windows Task Scheduler has no native "every N months"
#                    concept - -Monthly only accepts an explicit list of
#                    named months. Emulated by building that list: starting
#                    at the schedule's own month, step by MONTHS= all the
#                    way around a 12-month cycle (e.g. MONTHS=2 starting in
#                    August -> Aug,Oct,Dec,Feb,Apr,Jun), which then repeats
#                    every year. For MONTHS= values that don't evenly
#                    divide 12 (5, 7, ...) the yearly cycle won't land on
#                    a perfectly even interval - acceptable, same
#                    limitation every Windows GUI "every N months" task has.
#
#  No admin elevation - matches Setup.ps1's existing AM DataDownloader /
#  AM IdmsAvailabilityScan tasks exactly (runs as the interactive user).
#  Deliberately NO -Force on Register-ScheduledTask: a task-name collision
#  should be structurally impossible (unique id suffix baked in by the Lua
#  side) - if one ever happens anyway, fail loudly rather than silently
#  clobber a different schedule.
# ============================================================================

param([Parameter(Mandatory)][string]$ScheduleFile)
$ErrorActionPreference = 'Stop'
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$regStatusFile = "$ScheduleFile.regstatus.txt"

$DAY_MAP = @{
    'Mon' = 'Monday';    'Tue' = 'Tuesday';  'Wed' = 'Wednesday'; 'Thu' = 'Thursday'
    'Fri' = 'Friday';    'Sat' = 'Saturday'; 'Sun' = 'Sunday'
}

function Write-Result($status, $msg) {
    $lines = @("status=$status", "time=$([DateTimeOffset]::UtcNow.ToUnixTimeSeconds())", "message=$msg")
    [IO.File]::WriteAllLines($regStatusFile, $lines, (New-Object System.Text.UTF8Encoding($false)))
}

try {
    if (-not (Test-Path $ScheduleFile)) { Write-Result 'ERROR' "schedule file not found: $ScheduleFile"; exit 1 }

    $meta = @{
        REPEAT = 'once'; TASKNAME = $null; TASKPATH = '\IDMS Scheduled\'; RUNAT = $null; DAYS = $null
        MONTHS = $null; DAYOFMONTH = $null; EVERY = $null
    }
    foreach ($l in Get-Content $ScheduleFile) {
        if ($l -match '^(RUNAT|REPEAT|TASKNAME|TASKPATH|DAYS|MONTHS|DAYOFMONTH|EVERY)=(.*)$') { $meta[$matches[1]] = $matches[2] }
    }
    if (-not $meta.TASKNAME -or -not $meta.RUNAT) { Write-Result 'ERROR' 'schedule file missing TASKNAME/RUNAT'; exit 1 }

    $runAt = [datetime]::ParseExact($meta.RUNAT, 'yyyy-MM-dd HH:mm:ss', $null)

    $existing = Get-ScheduledTask -TaskName $meta.TASKNAME -TaskPath $meta.TASKPATH -ErrorAction SilentlyContinue
    if ($existing) { Write-Result 'ERROR' "a task named '$($meta.TASKNAME)' already exists"; exit 1 }

    $shim = Join-Path $here 'IdmsRunSchedule.ps1'
    $action = New-ScheduledTaskAction -Execute 'powershell.exe' `
        -Argument "-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File `"$shim`" -ScheduleFile `"$ScheduleFile`""

    $trigger = $null
    switch ($meta.REPEAT) {
        'daily' {
            $trigger = New-ScheduledTaskTrigger -Daily -At $runAt.ToString('HH:mm')
        }
        'weekly' {
            if (-not $meta.DAYS) { Write-Result 'ERROR' 'REPEAT=weekly needs DAYS= set (e.g. DAYS=Mon,Wed,Fri)'; exit 1 }
            $days = @()
            foreach ($d in ($meta.DAYS -split ',')) {
                $key = $d.Trim()
                if (-not $key) { continue }
                if (-not $DAY_MAP.ContainsKey($key)) {
                    Write-Result 'ERROR' "invalid day '$key' in DAYS= - use Mon,Tue,Wed,Thu,Fri,Sat,Sun"
                    exit 1
                }
                $days += $DAY_MAP[$key]
            }
            if ($days.Count -eq 0) { Write-Result 'ERROR' 'DAYS= had no valid days'; exit 1 }
            $trigger = New-ScheduledTaskTrigger -Weekly -DaysOfWeek $days -At $runAt.ToString('HH:mm')
        }
        'monthly' {
            # Registered separately below via the raw Task Scheduler COM API,
            # not through this switch's shared Register-ScheduledTask path -
            # see the dedicated block right after this switch statement for
            # why (New-ScheduledTaskTrigger has no -Monthly parameter set on
            # this PowerShell version, and the WMI/CIM DaysOfMonth property
            # is capped at UInt16 - confirmed empirically to silently refuse
            # any day past 16). Falls through with $trigger left $null;
            # handled immediately below before the generic Register call.
        }
        'interval' {
            if (-not $meta.EVERY) { Write-Result 'ERROR' 'REPEAT=interval needs EVERY= set (minutes)'; exit 1 }
            $mins = 0
            if (-not [int]::TryParse($meta.EVERY, [ref]$mins) -or $mins -lt 5) { Write-Result 'ERROR' 'EVERY= must be a whole number of 5 or more (minutes)'; exit 1 }
            # Same idiom Setup.ps1 already uses for AM DataDownloader: a Daily
            # trigger starting at RUNAT's time-of-day, repeating every EVERY
            # minutes for the rest of that day, every day thereafter.
            $trigger = New-ScheduledTaskTrigger -Daily -At $runAt.ToString('HH:mm')
            $trigger.Repetition = (New-ScheduledTaskTrigger -Once -At $runAt.ToString('HH:mm') `
                    -RepetitionInterval (New-TimeSpan -Minutes $mins) `
                    -RepetitionDuration (New-TimeSpan -Days 1)).Repetition
        }
        default {
            $trigger = New-ScheduledTaskTrigger -Once -At $runAt
        }
    }

    if ($meta.REPEAT -eq 'monthly') {
        if (-not $meta.MONTHS -or -not $meta.DAYOFMONTH) { Write-Result 'ERROR' 'REPEAT=monthly needs MONTHS= and DAYOFMONTH= set'; exit 1 }
        $n = 0; $day = 0
        if (-not [int]::TryParse($meta.MONTHS, [ref]$n) -or $n -lt 1) { Write-Result 'ERROR' 'MONTHS= must be a whole number of 1 or more'; exit 1 }
        if (-not [int]::TryParse($meta.DAYOFMONTH, [ref]$day) -or $day -lt 1 -or $day -gt 31) { Write-Result 'ERROR' 'DAYOFMONTH= must be between 1 and 31'; exit 1 }

        $svc = New-Object -ComObject "Schedule.Service"
        $svc.Connect()
        $rootFolder = $svc.GetFolder("\")
        # COM's GetFolder/CreateFolder reject a trailing backslash (unlike
        # Register-ScheduledTask's -TaskPath, which wants one) - confirmed
        # empirically: '\IDMS Scheduled\' throws E_INVALIDARG, '\IDMS
        # Scheduled' does not.
        $folderPath = '\' + $meta.TASKPATH.Trim('\')
        $idmsFolder = $null
        try { $idmsFolder = $svc.GetFolder($folderPath) } catch {}
        if (-not $idmsFolder) {
            try { $idmsFolder = $rootFolder.CreateFolder($meta.TASKPATH.Trim('\')) } catch { $idmsFolder = $svc.GetFolder($folderPath) }
        }

        $def = $svc.NewTask(0)
        $def.RegistrationInfo.Description = "IDMS scheduled report download (created $(Get-Date -Format 'yyyy-MM-dd HH:mm'))"
        $def.Settings.Enabled = $true
        $def.Settings.StartWhenAvailable = $true
        $def.Settings.DisallowStartIfOnBatteries = $false
        $def.Settings.StopIfGoingOnBatteries = $false
        $def.Settings.MultipleInstances = 2   # TASK_INSTANCES_IGNORE_NEW

        $TASK_TRIGGER_MONTHLY = 4
        $trig = $def.Triggers.Create($TASK_TRIGGER_MONTHLY)
        $trig.StartBoundary = $runAt.ToString("yyyy-MM-ddTHH:mm:ss")
        $trig.DaysOfMonth = [uint32]([math]::Pow(2, $day - 1))
        $MONTH_BITS = @(1,2,4,8,16,32,64,128,256,512,1024,2048)
        $startIdx = $runAt.Month - 1
        $bits = 0
        for ($i = 0; $i -lt 12; $i += $n) { $bits = $bits -bor $MONTH_BITS[($startIdx + $i) % 12] }
        $trig.MonthsOfYear = $bits
        $trig.Enabled = $true

        $TASK_ACTION_EXEC = 0
        $act = $def.Actions.Create($TASK_ACTION_EXEC)
        $act.Path = "powershell.exe"
        $act.Arguments = "-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File `"$shim`" -ScheduleFile `"$ScheduleFile`""

        $TASK_CREATE_OR_UPDATE = 6
        $TASK_LOGON_INTERACTIVE_TOKEN = 3
        $idmsFolder.RegisterTaskDefinition($meta.TASKNAME, $def, $TASK_CREATE_OR_UPDATE, $null, $null, $TASK_LOGON_INTERACTIVE_TOKEN) | Out-Null

        Write-Result 'OK' "scheduled '$($meta.TASKNAME)' for $($meta.RUNAT) (monthly, every $n month(s), day $day)"
        exit 0
    }

    $settings = New-ScheduledTaskSettingsSet -MultipleInstances IgnoreNew -StartWhenAvailable `
        -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries

    Register-ScheduledTask -TaskName $meta.TASKNAME -TaskPath $meta.TASKPATH `
        -Action $action -Trigger $trigger -Settings $settings `
        -Description "IDMS scheduled report download (created $(Get-Date -Format 'yyyy-MM-dd HH:mm'))" | Out-Null

    Write-Result 'OK' "scheduled '$($meta.TASKNAME)' for $($meta.RUNAT) ($($meta.REPEAT))"
} catch {
    # Confirmed real bug this fixes: on a PC whose security policy restricts
    # who can register scheduled tasks (seen live - HRESULT 0x80070005
    # "Access is denied" from Setup.ps1's own task registrations on such a
    # machine; this script hits the exact same wall), SCHEDULE TASK / a
    # scheduled EMAIL used to just fail outright with no recourse. Since
    # this whole script is idempotent for a given -ScheduleFile (it always
    # builds the same trigger from the same frozen file), retrying it once
    # via a UAC-elevated child process is a safe, simple fix - no need to
    # duplicate any of the REPEAT-mode trigger-building logic above.
    if ($_.Exception.Message -match 'Access is denied' -and $meta -and $meta.TASKNAME) {
        try {
            Start-Process powershell -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$($MyInvocation.MyCommand.Path)`" -ScheduleFile `"$ScheduleFile`"" -Verb RunAs -Wait -ErrorAction Stop
            # the elevated child writes its own $regStatusFile - if it got
            # far enough to do that, trust it and don't overwrite below.
            if (Test-Path $regStatusFile) { exit 0 }
        } catch {
            # elevation itself was cancelled/denied - fall through to the
            # normal error report below.
        }
    }
    Write-Result 'ERROR' ($_.Exception.Message -replace '[\r\n]+', ' ')
}
