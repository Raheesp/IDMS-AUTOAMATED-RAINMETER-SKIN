import sys
sys.path.insert(0, r"e:\ibnd\AutomationReminder\Downloads")
import IdmsDownload as idms

def main():
    user, pw = idms.read_creds()
    from playwright.sync_api import sync_playwright
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=True)
        ctx = browser.new_context(accept_downloads=True)
        page = ctx.new_page()
        page.goto(idms.LOGIN_URL, timeout=30000)
        idms.try_fill(page, idms.SEL_USER, user)
        idms.try_fill(page, idms.SEL_PASS, pw)
        page.click(idms.SEL_LOGIN, timeout=8000)
        page.wait_for_load_state("networkidle", timeout=20000)
        if idms.LOGIN_MARKER in page.url.lower():
            print("LOGIN FAILED")
            return

        checks = [
            ("booking", "2025-02-01", "2025-02-28", "boundary month claimed to have data"),
            ("docket_cancellation", "2024-07-01", "2024-07-31", "boundary month claimed to have data"),
            ("docket_cancellation", "2025-05-01", "2025-05-31", "known-gap month (Apr-Jul 2025 404s in real testing)"),
        ]
        for key, d_from, d_to, note in checks:
            cfg = idms.REPORTS[key]
            idms.goto_report(page, cfg)
            idms.try_fill(page, cfg["df"], d_from)
            idms.try_fill(page, cfg["dt"], d_to)
            idms.click_text(page, cfg["filt"], timeout=6000)
            rows = page.locator("table tbody tr")
            deadline_text = ""
            for _ in range(30):
                page.wait_for_timeout(1000)
                c = rows.count()
                deadline_text = rows.first.inner_text()[:60] if c else ""
                if c and "loading" not in deadline_text.lower():
                    break
            c = rows.count()
            print(f"{key} {d_from}..{d_to} ({note}): rows={c} first_row={deadline_text!r}")
        browser.close()

if __name__ == "__main__":
    main()
