# ============================================================================
#  RefreshTasks.ps1  -  live feed for the AutomationReminder Rainmeter skin
# ----------------------------------------------------------------------------
#  Queries the real Windows Task Scheduler for every task under
#  \Uipath Automation\ and writes the feed to %LOCALAPPDATA%\AutomationReminder\
#  (a machine-local folder, NOT the synced skin folder - see .stignore).
#  Rainmeter runs this once a minute; the Lua reads the file every second.
#
#  Output: one task per line, pipe-separated
#     nextEpoch | lastEpoch | lastResult | state | taskName
#  epochs are Unix UTC seconds (0 = none). lastResult is the task exit code
#  (0 = success). state = Ready / Running / Queued.
#
#  You can run this by hand to see what the widget sees:  powershell -File RefreshTasks.ps1
# ============================================================================

param([string]$Folder = '\Uipath Automation\')

$ErrorActionPreference = 'SilentlyContinue'

# Task-tree folder is configurable from the .ini (#TaskFolder#). Normalise it so
# it always ends in a backslash, which Get-ScheduledTask expects for a folder.
if ($Folder -notmatch '\\$') { $Folder += '\' }
$folder = $Folder

# Write the live feed to a MACHINE-LOCAL folder, never into the (Syncthing-)
# synced skin folder. Each PC has its own Task Scheduler, so its feed is local
# only - this stops the minute-by-minute churn and .sync-conflict files.
$dataDir = if ($env:LOCALAPPDATA) { Join-Path $env:LOCALAPPDATA 'AutomationReminder' } else { $PSScriptRoot }
if (-not (Test-Path $dataDir)) { New-Item -ItemType Directory -Path $dataDir -Force | Out-Null }
$out = Join-Path $dataDir '_taskdata.txt'

function ToEpoch($dt) {
    if ($null -eq $dt) { return 0 }
    try { return [int]([datetimeoffset]$dt).ToUnixTimeSeconds() } catch { return 0 }
}

$lines = New-Object System.Collections.Generic.List[string]

$tasks = Get-ScheduledTask -TaskPath $folder -ErrorAction SilentlyContinue
foreach ($t in $tasks) {
    # Show ENABLED tasks only - skip anything disabled in Task Scheduler.
    if ([string]$t.State -eq 'Disabled') { continue }

    $info  = $t | Get-ScheduledTaskInfo -ErrorAction SilentlyContinue
    $nextE = ToEpoch $info.NextRunTime
    $lastE = ToEpoch $info.LastRunTime
    $state = [string]$t.State          # Ready / Running / Queued
    $name  = $t.TaskName
    $result = 0                         # last exit code (0 = success)
    if ($null -ne $info.LastTaskResult) { $result = [int64]$info.LastTaskResult }
    $lines.Add(('{0}|{1}|{2}|{3}|{4}' -f $nextE, $lastE, $result, $state, $name))
}

# Write atomically (temp then move) so Lua never reads a half-written file.
$tmp = "$out.tmp"
[IO.File]::WriteAllLines($tmp, $lines, (New-Object System.Text.UTF8Encoding($false)))
Move-Item -Path $tmp -Destination $out -Force

# ============================================================================
#  RUN HISTORY  ->  _taskhist.txt   (start | durationSec | taskName, newest 1st)
# ----------------------------------------------------------------------------
#  Pulls the Task Scheduler operational log, pairs each run's "started" (100)
#  and "completed" (102) event by its correlation id to get the duration, and
#  keeps the most recent runs under \Uipath Automation\. Needs task history to
#  be ON (Task Scheduler -> Enable All Tasks History). If it is off or the log
#  is empty, the file is written empty and the dashboard shows a hint instead.
# ============================================================================
$histOut   = Join-Path $dataDir '_taskhist.txt'
$histLines = New-Object System.Collections.Generic.List[string]
try {
    $since  = (Get-Date).AddHours(-48)
    $events = Get-WinEvent -FilterHashtable @{
        LogName   = 'Microsoft-Windows-TaskScheduler/Operational'
        Id        = 100, 102
        StartTime = $since
    } -MaxEvents 500 -ErrorAction Stop

    $runs = @{}   # correlationId -> @{ name; start; end }
    foreach ($e in $events) {
        if ($null -eq $e.ActivityId) { continue }
        $key = $e.ActivityId.ToString()
        $tn  = $null
        try {
            $x = [xml]$e.ToXml()
            foreach ($d in $x.Event.EventData.Data) {
                if ($d.Name -eq 'TaskName') { $tn = [string]$d.'#text' }
            }
        } catch { }
        if (-not $tn -or ($tn -notlike "$folder*")) { continue }
        if (-not $runs.ContainsKey($key)) { $runs[$key] = @{ name = $tn } }
        if ($e.Id -eq 100) {
            $runs[$key].start = $e.TimeCreated
        }
        elseif ($e.Id -eq 102) {
            $runs[$key].end = $e.TimeCreated
            $rc = 0
            foreach ($d in $x.Event.EventData.Data) { if ($d.Name -eq 'ResultCode') { $rc = [int64]$d.'#text' } }
            $runs[$key].result = $rc
        }
    }

    $entries =
        foreach ($r in $runs.Values) {
            if ($null -ne $r.start) {
                if ($null -ne $r.end) { $dur = [int]([timespan]($r.end - $r.start)).TotalSeconds }
                else                  { $dur = -1 }   # started but no completion yet = running
                $res = 0
                if ($null -ne $r.result) { $res = $r.result }
                [pscustomobject]@{
                    start  = (ToEpoch $r.start)
                    dur    = $dur
                    result = $res
                    name   = ($r.name -split '\\')[-1]
                }
            }
        }

    foreach ($en in ($entries | Sort-Object start -Descending | Select-Object -First 200)) {
        $histLines.Add(('{0}|{1}|{2}|{3}' -f $en.start, $en.dur, $en.result, $en.name))
    }
} catch {
    # history disabled / log unavailable - leave the file empty
}

$htmp = "$histOut.tmp"
[IO.File]::WriteAllLines($htmp, $histLines, (New-Object System.Text.UTF8Encoding($false)))
Move-Item -Path $htmp -Destination $histOut -Force
