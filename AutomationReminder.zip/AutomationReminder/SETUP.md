# AutomationReminder + IDMS Report Downloader - Setup Guide

This is a Rainmeter desktop widget for AM Motors staff. It shows the live
UiPath task schedule, auto-downloads Booking/Docket/Enquiry counts every 15
minutes, and now includes an **IDMS** panel that can download any of 32
report types on `sos.ammotors.in` on demand, with quick date-range filters,
plus scheduling and emailing those reports on a timer. (4 more exist on the
site but are temporarily removed from the panel - see "Known limitations"
below.)

## What you need

- **Rainmeter** installed (https://www.rainmeter.net) - free, takes a minute.
- This whole `AutomationReminder` folder, copied or synced to your PC.
- Your IDMS login (username + password) for `sos.ammotors.in`.

## 1. Install

1. Open the `Downloads` folder inside `AutomationReminder`.
2. Double-click **`Setup.bat`** (right-click -> "Run as administrator" if you
   can - it installs Python and a scheduled task).
3. It will:
   - Install a real Python (not the Microsoft Store stub) if you don't
     already have one, plus the `playwright`, `pandas`, `openpyxl` packages
     and a Chromium browser for it to drive.
   - **Ask "Should this PC show its OWN live Task Scheduler?"** - press
     Enter (or type `Y`) if this is the PC that actually runs the real
     automation and should show its own live schedule (the normal case for
     a fresh copy). Only type `N` if this is deliberately a view-only copy
     of *someone else's* schedule (see section 5) - answering wrong here is
     exactly what makes the AUTOMATION bar look stuck on old/frozen data
     that never updates, so when in doubt, press Enter.
   - Create a scheduled task ("AM DataDownloader") that refreshes Booking /
     Docket / Enquiry counts every 15 minutes in the background.
   - Open **Notepad** with a credentials file - `creds.txt`.
     **Line 1 = your IDMS username, line 2 = your password.** Type your
     password over the placeholder text, save (Ctrl+S), and close Notepad.

That's it - setup only needs to be run once per PC.

## 2. Load the widget in Rainmeter

1. Copy (or symlink) the `AutomationReminder` folder into your Rainmeter
   skins folder - normally `Documents\Rainmeter\Skins\`.
2. Right-click the Rainmeter tray icon -> **Manage**.
3. Under Skins, find `AutomationReminder` and load `AutomationReminder.ini`.
4. Then load `AutomationReminder\Downloads\Downloads.ini` the same way.
5. Drag the two bars wherever you like on your desktop (the PORTAL DATA bar
   is meant to sit just under the main AUTOMATION bar).

## 3. Using it day to day

**The two bars:**
- **AUTOMATION** - live UiPath task schedule, countdown to the next run.
  Click the brand to open Task Scheduler. Click **ALL TASKS** to expand the
  full schedule + run history dashboard.
- **PORTAL DATA** - live Booking/Docket/Enquiry row counts, refreshed every
  15 minutes automatically. Click **RUN NOW** to force an immediate refresh.

**The IDMS panel** (click **IDMS v** in the top-right of the PORTAL DATA
bar):
1. Tick any of the 33 report checkboxes (or click **ALL** / **NONE**).
   Follow Ups is split into four separate picks - **Current**, **Overdue**,
   **Upcoming**, and **All 3** (grabs all three as separate files in one
   click) - so you're not stuck downloading all three every time.
2. Pick a date range:
   - **AS-IS** (default) - downloads immediately with whatever date range
     each report page already shows, no filtering. Fastest option.
   - **TODAY** - sets every report's range to today.
   - **THIS MONTH** - 1st of this month through today.
   - **LAST MONTH** - the full previous calendar month.
   - **LAST 2 MONTHS** - 1st of two months ago through today.
   - **LAST 3 MONTHS** - 1st of three months ago through today.
   - **CUSTOM DATES...** - opens `idms_range.txt` in Notepad; edit the
     `FROM=` / `TO=` lines (format `YYYY-MM-DD`), save, close, then click
     DOWNLOAD.
   - **LAST N MONTHS...** - opens `idms_months_custom.txt` in Notepad; edit
     `MONTHS=` to however many months back you want (e.g. `MONTHS=4` or
     `MONTHS=5`), save, close, then click DOWNLOAD. This is dynamic - the
     starting month is worked out fresh from today every time it actually
     runs, so a saved SCHEDULE TASK or EMAIL using this option always covers
     "the last N months as of whenever it fires," not a frozen date range.
3. Click **DOWNLOAD**. The status line shows live progress
   ("Downloading 5/12: Docket Report...") and a final summary.
4. Click **OPEN FOLDER** to jump straight to the downloaded files -
   `%LOCALAPPDATA%\AutomationReminder\idms_downloads\`.

If any report can't be downloaded, it's skipped (not the whole batch) and
listed in `0_FAILED_REPORTS.txt` inside that same downloads folder, with the
reason. **AS-IS** is the one option that gets a real fallback: if the
report's own default view comes back empty, it's retried once with last
month's 1st through today, and that substitution is called out explicitly
in the status line and in `0_USED_WIDER_DATE_RANGE.txt`. Every other
date-range choice you make on purpose - TODAY, THIS MONTH, LAST MONTH, LAST
2/3 MONTHS, LAST N MONTHS, CUSTOM DATES - is never swapped for a different
range; a miss there (almost always the portal's export click not firing,
not genuinely empty data) is retried against the exact same range up to
twice more before being marked failed, so a transient miss doesn't cost you
the data you actually asked for.

**Knowing what date range to pick - data availability:** hover over any
report's checkbox and a tooltip shows the actual date range that report has
real data for (e.g. "Data available: 04 Aug 2025 to 24 Jul 2026"), so you
know before you download whether your chosen range will return anything.
This is checked automatically once a day in the background (a scheduled
task, "AM IdmsAvailabilityScan", set up by `Setup.bat`), or click **REFRESH
AVAILABILITY** at the bottom of the panel to re-check on demand - it logs in
and probes each report for its earliest and latest real data, which takes a
while (roughly 20-40 minutes across all the date-filterable reports) since it's checking
actual exports, not guessing. The status line above the button shows live
progress and, once done, when it was last checked.

**If login starts failing** (password changed): click **UPDATE PASSWORD** -
it opens `creds.txt` in Notepad. Fix line 2, save, close, then click
DOWNLOAD (or RUN NOW) again.

## 4. Sharing this with someone else

Just give them the whole `AutomationReminder` folder (or add them to the
same sync) and point them at this file - step 1 (`Setup.bat`) is exactly
the same for anyone; it detects their own Python install and asks for
their own IDMS password, so no personal credentials ever need to travel
with the folder itself.

**AS-IS** gets one specific safety net: if the report's own default view
comes back empty, it's retried once with last calendar month's 1st through
today - a real, clearly different window, since AS-IS has no range of its
own to retry. If that's what delivers the data, the status line and a
`0_USED_WIDER_DATE_RANGE.txt` marker file say so explicitly.

Every other date-range choice is never silently swapped for a different one
- a miss there is retried against the *exact same* range up to twice more
(almost always the portal's export click not firing, not genuinely zero
data), so a transient miss doesn't cost you the range you actually asked
for. A report only ends up in `0_FAILED_REPORTS.txt` once those retries are
exhausted with your chosen range still coming back empty.

## 5. Sharing the live schedule with your team (view-only)

If teammates just want to *see* the AUTOMATION bar's live schedule (next
run, countdown, run history) without running their own copy of the real
UiPath tasks, don't sync the Task Scheduler folder and don't sync your
whole `%LOCALAPPDATA%\AutomationReminder\` folder - both cause real
problems:

- **Syncing the Windows Task Scheduler folder (`C:\Windows\System32\Tasks`)
  doesn't work for this.** Task Scheduler doesn't watch that folder and
  auto-import changes - dropping XML files into it on someone else's PC
  doesn't register anything, and even if it somehow did, that PC's own
  Task Scheduler would track its *own* (nonexistent) run history, not
  yours. This is why teammates were seeing stale data. Remove that
  Syncthing share - it isn't helping and a system folder needing elevated
  access to sync is best avoided anyway.
- **Don't sync the whole `%LOCALAPPDATA%\AutomationReminder\` folder.**
  Alongside the two feed files it also contains `creds.txt` (your IDMS
  password, in plain text) and every report your account has downloaded.
  Syncing the whole folder would hand that to everyone it's shared with.

**What actually works:**

1. In Syncthing, share only two files from that folder - `_taskdata.txt`
   and `_taskhist.txt` - not the folder itself. Add
   `%LOCALAPPDATA%\AutomationReminder\` as a folder in Syncthing, then set
   its **Ignore Patterns** to an allow-list so nothing else in that folder
   (creds, downloads, selection files) ever leaves your PC:
   ```
   *
   !_taskdata.txt
   !_taskhist.txt
   ```
2. On **your** PC (the one actually running the real tasks), set that
   Syncthing folder's type to **Send Only**.
3. On **each teammate's** PC, set it to **Receive Only**, pointed at their
   own `%LOCALAPPDATA%\AutomationReminder\`. This guarantees your data is
   never overwritten by anything on their end, and nothing they do locally
   can create a `.sync-conflict` file.
4. On each teammate's PC, open `AutomationReminder\@Resources\Settings.inc`
   and add (or change) the line `IsSource=0`. This is the important part -
   without it, their own copy of the skin re-queries *their own* (empty)
   Task Scheduler every 60 seconds and overwrites the file Syncthing just
   delivered, which is the exact flicker-back-to-stale-data problem you
   ran into. `IsSource=0` stops that PC from ever touching its own Task
   Scheduler - it just displays whatever the synced files say. This file
   is machine-local and excluded from any skin-folder sync, so it's a
   one-time, one-line edit that never conflicts with anyone else's copy.
5. The `AutomationReminder` skin folder itself (the `.ini`/`.lua`/theme
   files) can still be shared normally the way step 4 above describes -
   that part was already conflict-safe (see `.stignore`).

After that: your PC pushes `_taskdata.txt`/`_taskhist.txt` out, teammates'
PCs only ever receive them, and nobody's local skin overwrites what came
in. Same pattern applies to `_downloads.txt` (the PORTAL DATA bar's
Booking/Docket/Enquiry counts) if you want teammates to see that too - add
it to the same allow-list.

## Known limitations (as of 2026-07-24)

Four reports exist on `sos.ammotors.in` but are **temporarily removed from
the panel** (not shown in the checkbox list at all, for now) because they're
broken on the site's own backend - verified across multiple full test runs,
with real login and real network tracing, not guesses. Re-adding them is a
small change (a few lines in `IdmsEngine.lua` and `Downloads.ini`) whenever
the site side gets fixed - the download logic for all four is still intact
in `IdmsDownload.py`, just not exposed in the UI:

- **Price View List** - the export endpoint returns a server error (HTTP
  500), even with Model/Variant/Colour explicitly set to "All".
- **Event Request Report** - the export link returns "not found" (HTTP 404),
  even with the required "Date type" dropdown set.
- **Delivery Completed** - the export endpoint returns a server error
  (HTTP 500), confirmed via direct network trace with a filter applied.
- **Cancelled Booking** - the export works, but returns zero rows in every
  window tested (including a full month); worth checking by hand if you
  expect data there.

**CRM Enquiry** used to be on this list (the single old entry silently
always grabbed whichever tab was active by default) - it's now fixed and
split into two working, independently-selectable reports, **CRM Enquiry -
Active** and **CRM Enquiry - Lost**. A third tab on that same page,
**Incomplete Booking**, was investigated and confirmed to have no
Excel/export button anywhere on the page itself (checked with real data
loaded and paginated) - a genuine gap in the site, not something this
automation can work around, so it was deliberately left out rather than
offering a button that would always fail.

**Follow Ups - Upcoming** - this is the largest of the 33 reports (usually
1-2 MB) and can occasionally time out if it's part of a huge batch (e.g.
selecting everything at once) with little time left in the run. It
downloads reliably when selected on its own or with a handful of other
reports. If it's missing from a big batch, just select it again by itself
and click DOWNLOAD.

Every other report downloaded successfully end-to-end across repeated full
test runs, including the trickier flows: Follow Ups' three tabs (each
genuinely different data - verified by distinct file sizes), popup-based
exports, "Apply Filters"/"Download Excel" wording, and pages with unset
Model/Branch/Variant filter dropdowns (now auto-set to "All" before download).
If a report fails or comes back empty: AS-IS gets a real substitution (last
month through today, called out explicitly if used); every other date-range
choice gets up to two retries against the exact same range instead (never a
different one), since a miss there is almost always the export click not
firing rather than genuinely no data.
