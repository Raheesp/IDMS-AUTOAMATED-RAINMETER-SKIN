# ============================================================================
#  CheckInstall.ps1  -  "is this PC really running the current version?"
# ----------------------------------------------------------------------------
#  Double-click CheckInstall.bat (next to this file). Setup.ps1 also runs it at
#  the end. It checks, and fixes what it safely can:
#
#    1. WHERE Rainmeter loads skins from. Windows can move Documents into
#       OneDrive, and then Rainmeter reads a DIFFERENT AutomationReminder
#       folder than the one you copied - the classic "nothing changed" cause.
#       If so, it offers to copy this folder there (that PC's own
#       @Resources\Settings.inc is kept).
#    2. Every shipped file against @Resources\manifest.txt (fingerprints made
#       on the PC the update came from): missing or old files are listed.
#    3. Rainmeter version, Settings.inc, Python + packages, scheduled tasks,
#       and recent Rainmeter log errors for these skins.
#    4. Refreshes Rainmeter so it re-reads every skin, and saves a report to
#       CheckInstall_report.txt (paste it back if anything is still wrong).
#
#  CheckInstall.ps1 -MakeManifest   (maintainer) rewrites the manifest from
#  this folder - run it after changing any file, before copying to other PCs.
# ============================================================================
param([switch]$MakeManifest, [switch]$NoPause, [switch]$NoPrompt)

$ErrorActionPreference = 'Continue'
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$manifest = Join-Path $here '@Resources\manifest.txt'
$report = New-Object System.Collections.Generic.List[string]
$fails = 0; $warns = 0

function Out-Line($level, $msg) {
    $color = @{ OK = 'Green'; WARN = 'Yellow'; FAIL = 'Red'; INFO = 'Gray'; HEAD = 'Cyan' }[$level]
    $text = if ($level -eq 'HEAD') { "`n== $msg" } else { "  [$level] $msg" }
    Write-Host $text -ForegroundColor $color
    $report.Add($text)
    if ($level -eq 'FAIL') { $script:fails++ }
    if ($level -eq 'WARN') { $script:warns++ }
}

# Files that differ per PC on purpose, or aren't part of the product.
$SKIP = @('^@Resources\\Settings\.inc$', '^@Resources\\Themes\\Custom\.inc$', '^@Resources\\manifest\.txt$',
          '^CheckInstall_report\.txt$', '\\__pycache__\\', '\.pyc$', '^\.st', '^_taskdata\.txt$', '^_taskhist\.txt$',
          '\.sync-conflict-', '\\test_[^\\]*\.py$', '\\rescan_two\.py$')

# Text files are compared by CONTENT: BOM and line endings don't count, and
# Downloads.ini's PythonExe= line is ignored (Setup rewrites it per PC).
function Get-Fingerprint($path, $rel) {
    $bytes = [IO.File]::ReadAllBytes($path)
    if ($rel -match '\.(ini|inc|lua|py|ps1|bat|md|html|txt)$') {
        $t = [Text.Encoding]::UTF8.GetString($bytes)
        if ($t.Length -gt 0 -and $t[0] -eq [char]0xFEFF) { $t = $t.Substring(1) }
        $t = $t -replace "`r`n", "`n"
        if ($rel -eq 'Downloads\Downloads.ini') { $t = $t -replace '(?m)^PythonExe=.*\n', '' }
        $bytes = [Text.Encoding]::UTF8.GetBytes($t)
    }
    $sha = [Security.Cryptography.SHA256]::Create()
    return ([BitConverter]::ToString($sha.ComputeHash($bytes)) -replace '-', '').Substring(0, 16)
}

function Get-ShippedFiles($root) {
    Get-ChildItem $root -Recurse -File | ForEach-Object {
        $rel = $_.FullName.Substring($root.Length).TrimStart('\')
        if (-not ($SKIP | Where-Object { $rel -match $_ })) { [pscustomobject]@{ Rel = $rel; Full = $_.FullName } }
    }
}

# ---------------------------------------------------------------- manifest ---
if ($MakeManifest) {
    $lines = Get-ShippedFiles $here | Sort-Object Rel | ForEach-Object { "$(Get-Fingerprint $_.Full $_.Rel)  $($_.Rel)" }
    $stamp = "# AutomationReminder manifest - $(Get-Date -Format 'yyyy-MM-dd HH:mm') from $env:COMPUTERNAME - $(@($lines).Count) files"
    [IO.File]::WriteAllLines($manifest, @($stamp) + $lines, (New-Object Text.UTF8Encoding($false)))
    Write-Host "manifest written: $(@($lines).Count) files -> $manifest" -ForegroundColor Green
    exit 0
}

Out-Line HEAD "AutomationReminder install check - $env:COMPUTERNAME - $(Get-Date -Format 'yyyy-MM-dd HH:mm')"
Out-Line INFO "this folder: $here"

# ------------------------------------------------ 1. where Rainmeter looks ---
Out-Line HEAD "1. Which folder Rainmeter actually uses"
$rmIni = Join-Path $env:APPDATA 'Rainmeter\Rainmeter.ini'
$skinPath = $null
if (Test-Path $rmIni) {
    $sp = Select-String $rmIni -Pattern '^SkinPath=(.+)$' | Select-Object -First 1
    if ($sp) { $skinPath = $sp.Matches[0].Groups[1].Value.Trim() }
}
if (-not $skinPath) {
    $docs = [Environment]::GetFolderPath('MyDocuments')     # follows OneDrive redirection
    $skinPath = Join-Path $docs 'Rainmeter\Skins'
    Out-Line INFO "Rainmeter uses its default skin folder: $skinPath"
} else {
    Out-Line INFO "Rainmeter.ini sets SkinPath=$skinPath"
}
$target = Join-Path $skinPath.TrimEnd('\') 'AutomationReminder'
$same = ([IO.Path]::GetFullPath($target).TrimEnd('\') -ieq [IO.Path]::GetFullPath($here).TrimEnd('\'))
if ($same) {
    Out-Line OK "Rainmeter loads THIS folder."
} else {
    Out-Line FAIL "Rainmeter loads $target - NOT this folder. That's why the update doesn't show."
    $ans = if ($NoPrompt) { 'n' } else { Read-Host "  Copy this updated folder to $target now? (that PC's Settings.inc is kept) [Y/n]" }
    if ($ans -notmatch '^[Nn]') {
        New-Item -ItemType Directory -Force -Path $target | Out-Null
        $keep = Join-Path $target '@Resources\Settings.inc'
        $xf = @('CheckInstall_report.txt')
        if (Test-Path $keep) { $xf += 'Settings.inc' }
        robocopy $here $target /E /XF $xf /XD __pycache__ /NFL /NDL /NJH /NJS /NP | Out-Null
        if ($LASTEXITCODE -lt 8) {
            Out-Line OK "copied to $target (Settings.inc there kept). Checking that copy now..."
            & (Join-Path $target 'CheckInstall.ps1') -NoPause:$NoPause -NoPrompt
            exit $LASTEXITCODE
        }
        Out-Line FAIL "copy failed (robocopy code $LASTEXITCODE)"
    }
}
foreach ($alt in @("$env:USERPROFILE\Documents\Rainmeter\Skins\AutomationReminder", "$env:USERPROFILE\OneDrive\Documents\Rainmeter\Skins\AutomationReminder")) {
    if ((Test-Path $alt) -and ([IO.Path]::GetFullPath($alt).TrimEnd('\') -ine [IO.Path]::GetFullPath($target).TrimEnd('\'))) {
        Out-Line WARN "another copy exists at $alt - Rainmeter does NOT use it; delete it to avoid confusion"
    }
}

# ------------------------------------------------------------- 2. files ------
Out-Line HEAD "2. Files vs the update's manifest"
if (-not (Test-Path $manifest)) {
    Out-Line FAIL "@Resources\manifest.txt is missing - the @Resources folder was not copied completely"
} else {
    $m = Get-Content $manifest
    Out-Line INFO ($m[0] -replace '^# ', '')
    $want = @{}; foreach ($l in $m | Select-Object -Skip 1) { if ($l -match '^(\w{16})  (.+)$') { $want[$matches[2]] = $matches[1] } }
    $missing = @(); $old = @()
    foreach ($rel in $want.Keys) {
        $p = Join-Path $here $rel
        if (-not (Test-Path -LiteralPath $p)) { $missing += $rel }
        elseif ((Get-Fingerprint $p $rel) -ne $want[$rel]) { $old += $rel }
    }
    if (-not $missing -and -not $old) { Out-Line OK "all $($want.Count) files present and current" }
    foreach ($f in ($missing | Sort-Object | Select-Object -First 25)) { Out-Line FAIL "missing: $f" }
    foreach ($f in ($old | Sort-Object | Select-Object -First 25)) { Out-Line FAIL "different/old: $f" }
    if ($missing.Count + $old.Count -gt 50) { Out-Line INFO "(list cut at 25 each)" }
}

# ----------------------------------------------------------- 3. rainmeter ----
Out-Line HEAD "3. Rainmeter"
$rmExe = (Get-Process Rainmeter -ErrorAction SilentlyContinue | Select-Object -First 1).Path
if (-not $rmExe) { foreach ($c in "$env:ProgramFiles\Rainmeter\Rainmeter.exe", "${env:ProgramFiles(x86)}\Rainmeter\Rainmeter.exe") { if (Test-Path $c) { $rmExe = $c } } }
if ($rmExe) {
    $ver = (Get-Item $rmExe).VersionInfo.FileVersion
    if ([version]($ver -replace '[^\d.].*$', '') -ge [version]'4.5') { Out-Line OK "Rainmeter $ver" } else { Out-Line FAIL "Rainmeter $ver is too old - install 4.5 or newer from rainmeter.net" }
    if (-not (Get-Process Rainmeter -ErrorAction SilentlyContinue)) { Out-Line WARN "Rainmeter is not running" }
} else { Out-Line FAIL "Rainmeter is not installed" }

$settings = Join-Path $here '@Resources\Settings.inc'
if (Test-Path $settings) {
    $kv = @{}; foreach ($l in Get-Content $settings) { if ($l -match '^(\w+)=(.*)$') { $kv[$matches[1]] = $matches[2] } }
    Out-Line INFO ("Settings.inc: Theme={0}  Design={1}  IsSource={2}" -f $kv['Theme'], $(if ($kv['Design']) { $kv['Design'] } else { 'Classic (default)' }), $kv['IsSource'])
    if ($kv['Theme'] -and -not (Test-Path (Join-Path $here "@Resources\Themes\$($kv['Theme']).inc"))) { Out-Line FAIL "theme '$($kv['Theme'])' has no file in @Resources\Themes" }
    if ($kv['Design'] -and -not (Test-Path (Join-Path $here "@Resources\Designs\$($kv['Design']).inc"))) { Out-Line FAIL "design '$($kv['Design'])' has no file in @Resources\Designs" }
} else { Out-Line WARN "@Resources\Settings.inc missing - Rainmeter will use defaults (Sunset, Classic)" }

if (Test-Path $rmIni) {
    $cur = ''; $act = @{}
    foreach ($l in Get-Content $rmIni) { if ($l -match '^\[(.+)\]$') { $cur = $matches[1] } elseif ($cur -like 'AutomationReminder*' -and $l -match '^Active=(\d+)') { $act[$cur] = [int]$matches[1] } }
    foreach ($c in 'AutomationReminder', 'AutomationReminder\Downloads', 'AutomationReminder\NetWatch', 'AutomationReminder\MainSystem') {
        Out-Line INFO ("{0,-30} {1}" -f $c, $(if ($act[$c] -gt 0) { 'loaded' } else { 'not loaded' }))
    }
}
$log = Join-Path $env:APPDATA 'Rainmeter\Rainmeter.log'
if (Test-Path $log) {
    $errs = Get-Content $log -Tail 400 | Where-Object { $_ -match '^(ERRO|WARN)' -and $_ -match 'AutomationReminder' -and $_ -notmatch 'is not active|already active' }
    if ($errs) { Out-Line WARN "recent Rainmeter log problems:"; $errs | Select-Object -Last 12 | ForEach-Object { Out-Line INFO $_ } }
    else { Out-Line OK "no recent Rainmeter errors for these skins" }
} else { Out-Line INFO "Rainmeter logging is off (Manage > Settings > Log to file) - skipped" }

# -------------------------------------------------------------- 4. python ----
Out-Line HEAD "4. Python + download tools"
$pyw = $null
$dl = Join-Path $here 'Downloads\Downloads.ini'
if (Test-Path $dl) { $l = Select-String $dl -Pattern '^PythonExe=(.+)$' | Select-Object -First 1; if ($l) { $pyw = $l.Matches[0].Groups[1].Value.Trim() } }
if ($pyw -and (Test-Path $pyw)) {
    $py = Join-Path (Split-Path $pyw) 'python.exe'
    $o = & $py -c "import playwright, pandas, openpyxl; from importlib.metadata import version as v; print('playwright', v('playwright'), '- pandas', v('pandas'), '- openpyxl', v('openpyxl'))" 2>&1
    if ($LASTEXITCODE -eq 0) { Out-Line OK "$o" } else { Out-Line FAIL "packages broken - run Downloads\Setup.bat again ($o)" }
    $sp = Join-Path (Split-Path $pyw) 'Lib\site-packages'
    Get-ChildItem $sp -Directory -Filter '~*' -ErrorAction SilentlyContinue | ForEach-Object { Out-Line WARN "leftover from an interrupted pip upgrade: $($_.FullName) - safe to delete when no download is running" }
} else { Out-Line FAIL "PythonExe in Downloads.ini not found ($pyw) - run Downloads\Setup.bat" }

Out-Line HEAD "5. Scheduled tasks"
foreach ($t in 'AM DataDownloader', 'AM IdmsAvailabilityScan') {
    $st = Get-ScheduledTask -TaskName $t -ErrorAction SilentlyContinue
    if (-not $st) { Out-Line WARN "$t not registered - run Downloads\Setup.bat"; continue }
    $arg = $st.Actions[0].Arguments
    if ($arg -like "*$here*") { Out-Line OK "$t -> this folder ($($st.State))" } else { Out-Line FAIL "$t points elsewhere: $arg - run Downloads\Setup.bat from THIS folder" }
}

# ----------------------------------------------------------- 5. refresh ------
Out-Line HEAD "6. Refresh"
if ($rmExe -and (Get-Process Rainmeter -ErrorAction SilentlyContinue)) {
    & $rmExe '!RefreshApp'
    Out-Line OK "Rainmeter refreshed - every skin re-read from disk"
}
Out-Line HEAD ("RESULT: {0} problem(s), {1} warning(s)" -f $fails, $warns)
if ($fails -eq 0) {
    Out-Line INFO "Where the new options are: DESIGN < name > + THEME dots in the AUTOMATION dashboard (click ALL TASKS),"
    Out-Line INFO "at the bottom of the IDMS panel (click IDMS v), in the NetWatch window, and on the compact bar (click it)."
    Out-Line INFO "The .cmd download icon is next to DOWNLOAD in the IDMS panel. Right-click the main or PORTAL bar for the same options."
}
$rep = Join-Path $here 'CheckInstall_report.txt'
[IO.File]::WriteAllLines($rep, $report, (New-Object Text.UTF8Encoding($false)))
Write-Host "`nReport saved: $rep" -ForegroundColor Gray
if (-not $NoPause) { Read-Host "`nPress Enter to close" | Out-Null }
exit $fails
