# =============================================================================
#  PowerScan.ps1  -  power / session event dump for NetWatchEngine.lua
# -----------------------------------------------------------------------------
#  Rainmeter's Lua cannot read the Windows event log, so this script does it and
#  leaves the result where the engine can pick it up:
#
#      %LOCALAPPDATA%\AutomationReminder\_pwrevents_<COMPUTERNAME>.txt
#
#  One event per line, "epochSeconds|id", oldest first, plus two synthetic ids
#  of our own:
#
#      900  the last System-log event before an UNEXPLAINED boot (one with no
#           shutdown behind it) - the last moment the machine is known to have
#           been alive. When the power is cut Windows never logs a shutdown, so
#           this is the only evidence of when the electricity actually went.
#      999  written last, timestamped: the "file is complete" marker. The engine
#           ignores a dump that lacks it, so a half-written file is never parsed.
#
#  The real ids, and what they mean to the engine (see NetWatchEngine.lua):
#      12 / 6005 / 107 / 1   machine came UP   (boot, log service start, resume)
#      13 / 6006 / 42        machine went DOWN (kernel stop, log stop, sleep)
#      1074                  a clean shutdown / restart was requested
#      41 / 6008             the LAST shutdown was NOT clean - power loss or crash
#
#  Every query is pinned to its provider, because ids like 1 and 12 are also
#  used by unrelated sources in the System log.
#
#  Runs as a normal user (the System log is world-readable; only the Security
#  log needs admin), touches nothing, and writes one small text file. If it
#  cannot run at all, the engine still records power-offs from its own
#  heartbeat - it just cannot tell a power cut from a clean shutdown.
# =============================================================================
param([int]$Days = 6)

$ErrorActionPreference = 'SilentlyContinue'

# Same machine-local folder the rest of the skin family writes to, and the same
# per-host filename rule as the Lua, so a synced skin folder never mixes two
# machines' histories.
$dir = Join-Path $env:LOCALAPPDATA 'AutomationReminder'
if (-not (Test-Path -LiteralPath $dir)) {
    New-Item -ItemType Directory -Path $dir -Force | Out-Null
}
$tag = ($env:COMPUTERNAME -replace '[^A-Za-z0-9_\-]', '')
if (-not $tag) { $tag = 'local' }
$out = Join-Path $dir ("_pwrevents_{0}.txt" -f $tag)
$tmp = "$out.tmp"

$epoch = [datetime]::SpecifyKind([datetime]'1970-01-01', 'Utc')
function ToEpoch([datetime]$t) {
    [int64][math]::Floor(($t.ToUniversalTime() - $epoch).TotalSeconds)
}

$start = (Get-Date).AddDays(-$Days)
$rows  = New-Object System.Collections.ArrayList

foreach ($q in @(
    @{ LogName = 'System'; ProviderName = 'Microsoft-Windows-Kernel-General';         Id = @(12, 13);         StartTime = $start },
    @{ LogName = 'System'; ProviderName = 'Microsoft-Windows-Kernel-Power';           Id = @(41, 42, 107);    StartTime = $start },
    @{ LogName = 'System'; ProviderName = 'EventLog';                                 Id = @(6005, 6006, 6008); StartTime = $start },
    @{ LogName = 'System'; ProviderName = 'User32';                                   Id = @(1074);           StartTime = $start },
    @{ LogName = 'System'; ProviderName = 'Microsoft-Windows-Power-Troubleshooter';   Id = @(1);              StartTime = $start }
)) {
    foreach ($e in (Get-WinEvent -FilterHashtable $q -ErrorAction SilentlyContinue)) {
        [void]$rows.Add([pscustomobject]@{ T = (ToEpoch $e.TimeCreated); Id = [int]$e.Id })
    }
}

# --- boot clusters, and which of them are unexplained -------------------------
# A boot writes several up-events a few seconds apart (12 then 6005, and on a
# resume 107 then 1); they are ONE boot. A down-event ends the cluster, which is
# what keeps two restarts a minute apart from collapsing into one.
#
# A boot with NO down-event behind it is the signature of a power cut: the
# machine simply stopped, so Windows never got to log a shutdown. Those are the
# only boots we have to date by hand, below.
$UP    = @(12, 6005, 107, 1)
$BREAK = @(13, 6006, 42, 1074)
$CLUSTER = 90
$sorted  = @($rows | Sort-Object T, Id)
$orphans = @()
$prevUp  = $null
$sawDown = $false
foreach ($r in $sorted) {
    if ($UP -contains $r.Id) {
        if (($null -eq $prevUp) -or (($r.T - $prevUp) -gt $CLUSTER)) {
            if (-not $sawDown) { $orphans += $r.T }
            $sawDown = $false
        }
        $prevUp = $r.T
    } elseif ($BREAK -contains $r.Id) {
        $prevUp  = $null
        $sawDown = $true
    }
}

# The newest System event before an unexplained boot - the last moment the
# machine is known to have been alive, and so our only estimate of when the
# electricity went. One cheap query per power cut, and there are rarely any.
foreach ($b in $orphans) {
    $before = $epoch.AddSeconds($b).ToLocalTime()
    $prev = Get-WinEvent -FilterHashtable @{ LogName = 'System'; EndTime = $before } -MaxEvents 1 -ErrorAction SilentlyContinue
    if ($null -ne $prev) {
        [void]$rows.Add([pscustomobject]@{ T = (ToEpoch $prev.TimeCreated); Id = 900 })
    }
}

# --- write, oldest first, via a temp file so a reader never sees a half dump --
$sb = New-Object System.Text.StringBuilder
foreach ($r in ($rows | Sort-Object T, Id)) {
    [void]$sb.AppendLine(('{0}|{1}' -f $r.T, $r.Id))
}
[void]$sb.AppendLine(('{0}|999' -f (ToEpoch (Get-Date))))
[System.IO.File]::WriteAllText($tmp, $sb.ToString(), [System.Text.Encoding]::ASCII)
Move-Item -LiteralPath $tmp -Destination $out -Force
