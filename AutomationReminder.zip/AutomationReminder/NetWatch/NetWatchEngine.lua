-- ============================================================================
--  NetWatchEngine.lua  -  engine for the INTERNET bar
-- ----------------------------------------------------------------------------
--  It keeps TWO histories, in the same shape, and shows them side by side:
--  the link going down, and the machine going down. Together they answer the
--  real question - "was it the internet, or was the PC simply not on?"
--
--  1) THE LINK.  Watches the PingPlugin measures in NetWatch.ini and records
--     every drop / recovery to a rolling 5-day log:
--
--         %LOCALAPPDATA%\AutomationReminder\_netlog_<PC>.txt
--         downEpoch | upEpoch | durationSec | flag
--           downEpoch  Unix UTC seconds the connection was declared DOWN
--           upEpoch    when it came back (0 = still down right now)
--           flag       0 = clean recovery, 1 = unresolved (see below)
--
--     UNRESOLVED (flag 1): if Rainmeter / the PC stops while the line is down,
--     that outage never gets its recovery timestamp. Rather than guess, the
--     open line is heartbeated with its elapsed duration every HEARTBEAT_SEC
--     while down, so on the next start we close it at the last duration we
--     actually observed and mark it "1". Those rows render with a leading
--     ">=" - the outage was AT LEAST that long; we just weren't running to
--     see it end. A power cut is the usual reason, and the power log below
--     now names it.
--
--  2) THE MACHINE.  Records every stretch where this PC was not running at
--     all - mains failure, shutdown, restart, sleep:
--
--         %LOCALAPPDATA%\AutomationReminder\_pwrlog_<PC>.txt
--         offEpoch | onEpoch | durationSec | cause | src | est
--           cause  0 shut down   1 power cut   2 asleep   3 unknown
--           src    0 worked out here   1 read from the Windows event log
--           est    0 exact start   1 estimated start   2 start unknown
--
--     Two independent sources feed it, so it works on any machine:
--
--       * PowerScan.ps1 (fired by MeasurePowerScan, every SCAN_SEC) dumps the
--         System event log's boot / shutdown / sleep / "that shutdown was
--         unexpected" records. Only the event log can tell a POWER CUT from a
--         clean SHUT DOWN, and it also back-fills history from before this
--         skin was ever installed.
--       * our own heartbeat, which needs nothing installed: _alive_<PC>.txt is
--         stamped every ALIVE_SEC, so a gap in it that a fresh boot explains
--         is recorded even where PowerShell is blocked by policy.
--
--     Where the two disagree the event log wins - it is exact and it knows the
--     cause - see addPwr(). Nothing is ever invented: an interval we cannot
--     date is either dropped or shown as "unknown", never guessed.
--
--  Both logs are machine-local on purpose (same folder as _taskdata.txt), so
--  nothing runtime-generated lands in the synced skin folder - see .stignore.
--  Theme-aware: every neutral colour is read from the ACTIVE theme in
--  Initialize(); the status and power accents are fixed, because they carry
--  meaning rather than style.
-- ============================================================================

local DOWN_STRIKES  = 6       -- seconds of ALL targets failing before OFFLINE
local UP_STRIKES    = 2       -- seconds of any target answering before ONLINE
local RETAIN_DAYS   = 5       -- how much history to keep (the brief)
local HEARTBEAT_SEC = 30      -- how often an in-progress outage is written out
local TIMEOUT_VALUE = 9999    -- must match TimeoutValue= in NetWatch.ini
local SLOW_MS       = 400     -- latency above this reads as "slow" (amber)
local PROBES        = 3       -- MeasurePing1..3 in the .ini

local ALIVE_SEC     = 30      -- how often the "still running" stamp is written
local GAP_MIN       = 90      -- a gap this long in our own ticks = PC not running
local CLUSTER       = 90      -- event-log clustering / matching window
local SCAN_SEC      = 1800    -- how often the event log is re-read
local SCAN_SOON     = 3       -- ...and how soon after a start / a gap
local MARK_MIN      = 60      -- ignore a "last sign of life" closer than this to
                              -- the boot it belongs to: it is almost certainly
                              -- FROM that boot and would invent a 0-second cut

local LOG_ROWS      = 10      -- log row meters defined in the .ini (shared pool)
local DAY_ROWS      = 5       -- daily-timeline rows (= RETAIN_DAYS)
local MARKS_NET     = 8       -- internet blocks drawable per timeline row
local MARKS_PWR     = 6       -- PC-off blocks drawable per timeline row
local SCROLL_STEP   = 3       -- rows moved per mouse-wheel notch
local FPS           = 20      -- skin ticks per second (Update=50 in the .ini)
local PING_KEEP     = 90      -- ping samples kept for re-fitting the trace scale
local RESCALE_SEC   = 5       -- how often the trace's min/max is re-fitted

-- orb geometry (centre + the two ring radii), mirrored from the .ini
local ORB_X, ORB_Y = 29, 28
local R_OUT, R_IN  = 13, 9
local PIP_X, PIP_Y = 203, 28  -- the power pip, left of the chevron
local TAU = math.pi * 2

-- timeline geometry - must match the meters in NetWatch.ini
local TRACK_X, TRACK_W = 76, 286
local DAY_Y0, DAY_PITCH, TRACK_H = 172, 22, 8
-- Every daily row is ONE Shape meter. Slots, in draw order:
--   Shape                        the empty track
--   Shape2 .. Shape7             PC-off blocks
--   Shape8 .. Shape15            internet outage blocks, over them
--   Shape16                      the "now" tick
local PWR_SLOT, NET_SLOT, NOW_SLOT = 1, 7, 16
-- legend swatches
local LEG_Y = 272
local LEG_X = { 23, 115, 200, 285 }
-- the two log tabs and the underline that follows the active one
local TAB_UY = 308
local TAB_X  = { 23, 103 }
local TAB_W  = { 64, 58 }
-- log duration bars / rows / scrollbar
local BAR_X, BAR_W = 300, 74
local ROW_Y0, ROW_PITCH = 332, 18
local SCROLL_TRACK_Y, SCROLL_TRACK_H = 332, 180

local DAY = 86400

-- Palette.
--   NEUTRALS (Dim / RowText / Faint / Bright) are pulled from the SHARED theme
--   in Initialize(), so this bar's dark background and text match the big bar
--   and PORTAL DATA, and follow the theme picker in the main bar's dropdown.
--   The literals here are only a fallback if a variable is ever missing.
--   STATUS ACCENTS stay fixed on purpose: green / amber / red carry meaning,
--   not style, so a theme swap must never make "offline" stop reading as red.
local ACCENT  = "34,222,124"
local DIM     = "122,138,148"
local ROWTEXT = "214,226,232,225"
local FAINT   = "255,255,255,20"
local BRIGHT  = "236,244,248"
local OKC     = "34,222,124"     -- online
local SLOWC   = "255,180,80"     -- degraded
local FAILC   = "255,80,80"      -- offline

-- POWER accents. Deliberately outside the green/amber/red family: a block on
-- the daily track has to say "the PC was not even on" at a glance, which is a
-- completely different fact from "the internet failed".
local PWR_CUT = "255,138,58"     -- power cut / unexpected stop  (orange)
local PWR_OFF = "132,146,255"    -- clean shutdown or restart    (indigo)
local PWR_SLP = "118,132,158"    -- sleep, or the widget frozen  (slate)

local C_SHUT, C_CUT, C_SLEEP, C_UNK = 0, 1, 2, 3
local CAUSE_TXT = { [0] = "SHUT DOWN", [1] = "POWER CUT", [2] = "ASLEEP", [3] = "PC OFF" }
local CAUSE_COL = { [0] = PWR_OFF,     [1] = PWR_CUT,     [2] = PWR_SLP,  [3] = PWR_OFF }

-- Windows System-log ids, by what they tell us. PowerScan.ps1 pins each one to
-- its provider, so these numbers can never collide with an unrelated source.
local UPID   = { [12] = true, [6005] = true, [107] = true, [1] = true }   -- came up
local DOWNID = { [13] = true, [6006] = true, [42]  = true }               -- went down
local BADID  = { [41] = true, [6008] = true }                             -- and not cleanly

-- Per-state accent: { orb / ring / trace colour, bright dot colour }
local PALETTE = {
  ONLINE   = { "45,232,130", "200,255,225" },
  SLOW     = { "255,190,90", "255,235,200" },
  OFFLINE  = { "255,86,86",  "255,215,215" },
  CHECKING = { "150,170,185","225,235,242" },
}

local logFile   = nil
local pwrFile   = nil     -- the power history
local aliveFile = nil     -- the 30-second "still running" stamp
local evFile    = nil     -- PowerScan.ps1's raw event dump
local outages   = {}      -- newest first: { down, up, dur, flag }
local power     = {}      -- newest first: { off, on, dur, cause, src, est }
local online    = true    -- current debounced state
local badRun, goodRun = 0, 0
local warmed    = false   -- true once a probe has returned anything definite
local sinceTS   = nil     -- when the current state began
local lastBeat  = 0       -- last time an open outage was flushed to disk
local lastStamp = 0       -- last time the alive stamp was written
local lastTick  = nil     -- last second we actually ran (a hole = PC not running)
local lastAlive = nil     -- the stamp we found at startup, from the last session
local scanAt    = 0       -- when the event log is next read
local bootDone  = false   -- the one-off "did we miss a boot?" check has run
local tab       = 0       -- 0 = outage log, 1 = power log
local scrollT   = { [0] = 0, [1] = 0 }   -- one scroll offset per tab
local lastPing  = -1      -- best latency from the most recent cycle
local longest   = 0       -- longest outage in window (scales the row bars)
local pwrLongest = 0      -- ...and the same for the power log
local lastPaint = nil     -- last state we repainted colours for
local accentNow = OKC     -- live accent: every green element follows this
local pipKey    = nil     -- last power pip we drew (so we redraw only on change)
local legendOn  = false   -- legend swatches are static: paint them once
local scrollDirty = false -- a wheel notch is waiting to be drawn
local frame     = 0       -- animation tick (FPS per second)
local pingHist  = {}      -- recent latencies, for auto-fitting the trace scale
local lastFit   = -99     -- second of the last trace rescale

-- ---------------------------------------------------------------- helpers ---

local function setOpt(meter, opt, val) SKIN:Bang('!SetOption', meter, opt, val) end

local function fmtClock(tt) return (os.date("%I:%M %p", tt):gsub("^0", "")) end

-- 65 -> "1m 05s" | 3725 -> "1h 02m" | 90000 -> "1d 1h"
local function fmtDur(sec)
  if sec == nil or sec < 0 then return "-" end
  if sec < 60 then return string.format("%ds", sec) end
  if sec < 3600 then return string.format("%dm %02ds", math.floor(sec / 60), sec % 60) end
  if sec < DAY then return string.format("%dh %02dm", math.floor(sec / 3600), math.floor(sec % 3600 / 60)) end
  return string.format("%dd %dh", math.floor(sec / DAY), math.floor(sec % DAY / 3600))
end

-- The same span in as few characters as possible: 45s / 12m / 2.5h / 1.2d.
-- Only for the daily rows, where two figures have to share one narrow column.
local function fmtShort(sec)
  if sec < 60 then return sec .. "s" end
  if sec < 3600 then return math.floor(sec / 60) .. "m" end
  if sec < DAY then return (string.format("%.1fh", sec / 3600):gsub("%.0h", "h")) end
  return (string.format("%.1fd", sec / DAY):gsub("%.0d", "d"))
end

-- "Today 11:20 AM" / "Yesterday 4:07 PM" / "Tue 26 9:15 AM"
local function fmtWhen(tt, now)
  local d0 = os.date("*t", now)
  d0.hour, d0.min, d0.sec = 0, 0, 0
  local midnight = os.time(d0)
  if tt >= midnight then return "Today " .. fmtClock(tt) end
  if tt >= midnight - DAY then return "Yesterday " .. fmtClock(tt) end
  return os.date("%a %d ", tt) .. fmtClock(tt)
end

-- ------------------------------------------------------------- the logs ---

local function readLog()
  local list = {}
  local f = io.open(logFile, "r")
  if not f then return list end
  for line in f:lines() do
    local d, u, dur, flag = line:match("^(%d+)|(%d+)|(%-?%d+)|(%d+)")
    if d then
      list[#list + 1] = {
        down = tonumber(d), up = tonumber(u),
        dur  = tonumber(dur), flag = tonumber(flag),
      }
    end
  end
  f:close()
  -- newest first, which is the order both the log table and the stats want
  table.sort(list, function(a, b) return a.down > b.down end)
  return list
end

-- Rewrite the whole file (it holds at most a handful of lines) and drop
-- anything that fell out of the RETAIN_DAYS window while we are here.
local function writeLog(now)
  local cutoff = now - RETAIN_DAYS * DAY
  local keep = {}
  for _, o in ipairs(outages) do
    if o.down >= cutoff then keep[#keep + 1] = o end
  end
  outages = keep
  local f = io.open(logFile, "w")
  if not f then return end
  -- oldest first on disk; readLog re-sorts on the way back in
  for i = #outages, 1, -1 do
    local o = outages[i]
    f:write(string.format("%d|%d|%d|%d\n", o.down, o.up, o.dur, o.flag))
  end
  f:close()
end

-- The power history, kept exactly like the outage one: same rolling window,
-- same "rewrite the lot, it is tiny" approach, sorted newest first.
local function readPwr()
  local list = {}
  local f = io.open(pwrFile, "r")
  if not f then return list end
  for line in f:lines() do
    local a, b, d, c, s, e = line:match("^(%d+)|(%d+)|(%-?%d+)|(%d+)|(%d+)|(%d+)")
    if not a then                                   -- tolerate a 4-field line
      a, b, d, c = line:match("^(%d+)|(%d+)|(%-?%d+)|(%d+)")
      s, e = "0", "0"
    end
    if a then
      list[#list + 1] = {
        off = tonumber(a), on = tonumber(b), dur = tonumber(d),
        cause = tonumber(c), src = tonumber(s), est = tonumber(e),
      }
    end
  end
  f:close()
  table.sort(list, function(x, y) return x.on > y.on end)
  return list
end

local function writePwr(now)
  local cutoff = now - RETAIN_DAYS * DAY
  local keep = {}
  for _, p in ipairs(power) do
    if p.on >= cutoff then keep[#keep + 1] = p end
  end
  power = keep
  local f = io.open(pwrFile, "w")
  if not f then return end
  for i = #power, 1, -1 do
    local p = power[i]
    f:write(string.format("%d|%d|%d|%d|%d|%d\n", p.off, p.on, p.dur, p.cause, p.src, p.est))
  end
  f:close()
end

-- Files the size of a tweet, but written every ALIVE_SEC forever, so both
-- halves stay deliberately dumb: one number, no parsing to get wrong.
local function readAlive()
  local f = io.open(aliveFile, "r")
  if not f then return nil end
  local line = f:read("*l") or ""
  f:close()
  return tonumber(line:match("%d+") or "")
end

local function stampAlive(now)
  local f = io.open(aliveFile, "w")
  if not f then return end
  f:write(tostring(now))
  f:close()
end

-- Files an interval into the power history, or reconciles it with one we
-- already hold. The same shutdown reaches us twice by design - once worked out
-- from our heartbeat within seconds, once from the event log up to half an
-- hour later - and the two must never both appear. They are the same event if
-- they end at about the same moment, or if they overlap at all; when they do,
-- the better record wins: the event log (src 1) over our own arithmetic, and a
-- known start over an estimated or missing one.
local function addPwr(iv)
  iv.dur = iv.on - iv.off
  if iv.dur < 0 then return end
  for i, p in ipairs(power) do
    -- Two records from the SAME source are never the same event: parseEvents
    -- has already clustered its boots, and the local checks fire once each.
    -- Only across sources do we have to reconcile, and there the two clocks
    -- differ by seconds - our boot estimate against the event log's - so
    -- "ends at about the same time, or overlaps at all" is the test. Keeping
    -- it that narrow is what lets two real restarts a minute apart survive as
    -- two rows instead of collapsing into one.
    local same = (p.on == iv.on)
    if (not same) and p.src ~= iv.src then
      same = (math.abs(p.on - iv.on) <= CLUSTER) or (p.off < iv.on and iv.off < p.on)
    end
    if same then
      if iv.src > p.src or (iv.src == p.src and iv.est < p.est) then power[i] = iv end
      return
    end
  end
  power[#power + 1] = iv
  table.sort(power, function(x, y) return x.on > y.on end)
end

-- Turns PowerScan.ps1's event dump into PC-off intervals. The shape of the
-- problem, and why the code looks like this:
--
--   * one boot writes SEVERAL up-events a few seconds apart (12 then 6005; on
--     a resume 107 then 1). They are ONE boot, so consecutive ups are
--     clustered - but a down-event ENDS the cluster, which is what stops two
--     restarts a minute apart from collapsing into one.
--   * the machine actually stops at the LAST strong down-event before a boot.
--     1074 is only the moment a shutdown was REQUESTED, and an app can hold
--     that open for minutes, so it names the cause but never the time.
--   * a power cut leaves NO down-event at all - the lights went out mid-
--     sentence. That absence is precisely how we recognise one; PowerScan
--     then hands us id 900, the last thing Windows managed to log, as the
--     only honest estimate of when it happened.
local function parseEvents(now)
  local f = io.open(evFile, "r")
  if not f then return false end
  local ev, complete = {}, false
  for line in f:lines() do
    local t, id = line:match("^(%d+)|(%d+)")
    if t then
      t, id = tonumber(t), tonumber(id)
      if id == 999 then complete = true else ev[#ev + 1] = { t = t, id = id } end
    end
  end
  f:close()
  -- 999 is written last. Without it we caught the dump mid-write; leave it for
  -- the next scan rather than reading half a history.
  if not complete then return false end
  table.sort(ev, function(a, b)
    if a.t == b.t then return a.id < b.id end
    return a.t < b.t
  end)

  local boots, prevUp = {}, nil
  for _, e in ipairs(ev) do
    if UPID[e.id] then
      if (not prevUp) or (e.t - prevUp) > CLUSTER then boots[#boots + 1] = e.t end
      prevUp = e.t
    elseif DOWNID[e.id] or e.id == 1074 then
      prevUp = nil
    end
  end

  local cutoff = now - RETAIN_DAYS * DAY
  for i, b in ipairs(boots) do
    local lo = boots[i - 1] or (b - RETAIN_DAYS * DAY)
    local offT, mark, clean, sleepy, bad = nil, nil, false, false, false
    for _, e in ipairs(ev) do
      if e.t > lo and e.t <= b then
        if DOWNID[e.id] then
          offT = e.t
          if e.id == 42 then sleepy = true else clean = true end
        elseif e.id == 1074 then
          clean = true
        elseif e.id == 900 then
          mark = e.t
        end
      end
      -- "the last shutdown was not clean" is logged BY the boot that follows
      -- it, so look around the boot, not before it.
      if BADID[e.id] and e.t >= (b - CLUSTER) and e.t <= (b + CLUSTER * 3) then bad = true end
    end

    local cause = bad and C_CUT or (clean and C_SHUT or (sleepy and C_SLEEP or C_UNK))
    local est = 0
    if not offT then
      if mark and (b - mark) >= MARK_MIN then offT, est = mark, 1 else offT, est = b, 2 end
    end
    -- A boot with nothing behind it at all - no shutdown, no last sign of
    -- life, not even a complaint about the previous shutdown - is almost
    -- always just the oldest boot still in the event log, whose shutdown fell
    -- off the end. Recording a zero-length "something happened" would be
    -- noise, so only a known power cut earns a row without a start time.
    if b >= cutoff and not (est == 2 and cause ~= C_CUT) then
      addPwr({ off = offT, on = b, cause = cause, src = 1, est = est })
    end
  end
  return true
end

-- Called by MeasurePowerScan's FinishAction, i.e. the moment PowerShell exits
-- and the dump is complete on disk.
function PowerScanDone()
  local now = os.time()
  if parseEvents(now) then writePwr(now) end
end

-- --------------------------------------------------------------- animation ---
-- Runs on EVERY skin tick (20x/sec). Deliberately cheap: six !SetOption bangs,
-- no file access, no allocation beyond the format strings. All the real work
-- lives in Update()'s once-per-second block.
local function animate()
  local pal = PALETTE[lastPaint or 'CHECKING']
  local orb, dotc = pal[1], pal[2]
  local t = frame / FPS

  -- halos breathe
  local puls = 0.5 + 0.5 * math.sin(t * 1.7)
  setOpt('MeterOrbGlowB', 'Shape', string.format(
    'Ellipse %d,%d,%.1f | Fill Color %s,%d', ORB_X, ORB_Y, 8.2 + 1.6 * puls, orb, math.floor(9 + 11 * puls)))
  setOpt('MeterOrbGlowA', 'Shape', string.format(
    'Ellipse %d,%d,%.1f | Fill Color %s,%d', ORB_X, ORB_Y, 6.7 + 1.1 * puls, orb, math.floor(22 + 16 * puls)))

  -- the core breathes very slightly, in step with the halos
  setOpt('MeterOrbCore', 'Shape', string.format(
    'Ellipse %d,%d,%.1f | Fill Color %s,255', ORB_X, ORB_Y, 6.3 + 0.4 * puls, orb))

  -- two rings counter-rotate, each with a dot riding its leading edge
  local a1 = (t * 0.55) % TAU
  local a2 = (-t * 0.85) % TAU
  setOpt('MeterOrbRing',  'StartAngle', string.format('%.4f', a1))
  setOpt('MeterOrbRing2', 'StartAngle', string.format('%.4f', a2))
  setOpt('MeterOrbDot', 'Shape', string.format('Ellipse %.1f,%.1f,1.8 | Fill Color %s,255',
    ORB_X + R_OUT * math.cos(a1), ORB_Y + R_OUT * math.sin(a1), dotc))
  setOpt('MeterOrbDot2', 'Shape', string.format('Ellipse %.1f,%.1f,1.3 | Fill Color %s,190',
    ORB_X + R_IN * math.cos(a2), ORB_Y + R_IN * math.sin(a2), dotc))
end

local EMPTY = 'Rectangle 0,0,0,0 | StrokeWidth 0'

-- One duration bar in the log's RELATIVE LENGTH column.
local function setBar(j, d, scale, col)
  local w = (scale > 0) and math.floor(BAR_W * d / scale) or 0
  if w < 2 then w = 2 end
  setOpt('MeterLogBar' .. j, 'Shape', 'Rectangle ' .. BAR_X .. ',' ..
    (ROW_Y0 + (j - 1) * ROW_PITCH + 5) .. ',' .. w .. ',5,2 | Fill Color ' .. col .. ',150 | StrokeWidth 0')
end

-- Draws whichever list the tabs have selected, and sizes the panel to it.
-- Split out of Update() so Scroll() and Tab() can trigger a redraw on the next
-- animation tick (<=50ms) rather than leaving the click unresponsive until the
-- next 1Hz pass.
--
-- ONE pool of row meters serves both histories - same columns, same bars, same
-- scrollbar - which is the whole point: an internet outage and a power cut are
-- the same kind of fact about the same five days, so they should be read the
-- same way.
local function renderLog(now)
  local pwr    = (tab == 1)
  local list   = pwr and power or outages
  local n      = #list
  local scale  = pwr and pwrLongest or longest
  local accent = pwr and PWR_CUT or accentNow

  local scroll = scrollT[tab]
  local maxoff = n - LOG_ROWS
  if maxoff < 0 then maxoff = 0 end
  if scroll > maxoff then scroll = maxoff end
  if scroll < 0 then scroll = 0 end
  scrollT[tab] = scroll

  -- the tabs, and the underline sliding under the active one
  setOpt('MeterTabNet', 'FontColor', (not pwr) and (BRIGHT .. ',255') or (DIM .. ',170'))
  setOpt('MeterTabPwr', 'FontColor', pwr and (BRIGHT .. ',255') or (DIM .. ',170'))
  setOpt('MeterTabLine', 'Shape', 'Rectangle ' .. TAB_X[tab + 1] .. ',' .. TAB_UY .. ',' ..
    TAB_W[tab + 1] .. ',2,1 | Fill Color ' .. accent .. ',210 | StrokeWidth 0')

  -- the column headers say the same thing in each list's own words
  setOpt('MeterHeadWhen', 'Text', pwr and 'WENT OFF'  or 'WENT DOWN')
  setOpt('MeterHeadBack', 'Text', pwr and 'CAME BACK' or 'BACK AT')
  setOpt('MeterHeadDur',  'Text', pwr and 'OFF FOR'   or 'DOWN FOR')
  setOpt('MeterHeadDur',  'FontColor', accent .. ',200')
  setOpt('MeterHeadTag',  'Text', pwr and 'CAUSE' or '')

  for j = 1, LOG_ROWS do
    local o = list[scroll + j]
    if o and pwr then
      local col = CAUSE_COL[o.cause]
      local unknown = (o.est == 2)
      setOpt('MeterLogWhen' .. j, 'Text', unknown and 'unknown' or fmtWhen(o.off, now))
      setOpt('MeterLogWhen' .. j, 'FontColor', unknown and (DIM .. ',180') or ROWTEXT)
      setOpt('MeterLogBack' .. j, 'Text', fmtClock(o.on))
      setOpt('MeterLogBack' .. j, 'FontColor', DIM .. ',235')
      -- "~" = the start was estimated from the last sign of life, so the
      -- length is the closest we can honestly get.
      setOpt('MeterLogDur' .. j, 'Text',
        unknown and '-' or ((o.est == 1 and '~' or '') .. fmtDur(o.dur)))
      setOpt('MeterLogDur' .. j, 'FontColor', col .. ',235')
      setOpt('MeterLogTag' .. j, 'Text', CAUSE_TXT[o.cause])
      setOpt('MeterLogTag' .. j, 'FontColor', col .. ',210')
      setBar(j, o.dur, scale, col)
    elseif o then
      local d = (o.up > 0) and o.dur or (now - o.down)
      local ongoing = (o.up == 0)
      local col = (o.flag == 1) and SLOWC or FAILC
      setOpt('MeterLogWhen' .. j, 'Text', fmtWhen(o.down, now))
      setOpt('MeterLogWhen' .. j, 'FontColor', ROWTEXT)
      setOpt('MeterLogBack' .. j, 'Text', ongoing and 'still down' or fmtClock(o.up))
      setOpt('MeterLogBack' .. j, 'FontColor', (ongoing and FAILC or DIM) .. ',235')
      setOpt('MeterLogDur' .. j, 'Text', (o.flag == 1 and '>=' or '') .. fmtDur(d))
      setOpt('MeterLogDur' .. j, 'FontColor', col .. ',235')
      setOpt('MeterLogTag' .. j, 'Text', '')
      setBar(j, d, scale, col)
    else
      setOpt('MeterLogWhen' .. j, 'Text', '')
      setOpt('MeterLogBack' .. j, 'Text', '')
      setOpt('MeterLogDur' .. j, 'Text', '')
      setOpt('MeterLogTag' .. j, 'Text', '')
      setOpt('MeterLogBar' .. j, 'Shape', EMPTY)
    end
  end

  -- Empty state gets its own full-width meter: the WENT DOWN column is
  -- narrow and ClipString'd, which would truncate the message mid-word.
  local empty = ''
  if n == 0 then
    empty = pwr
      and ('This PC has not lost power, been shut down or slept in ' .. RETAIN_DAYS .. ' days.')
      or  ('No outages recorded in the last ' .. RETAIN_DAYS .. ' days.')
  end
  setOpt('MeterLogEmpty', 'Text', empty)
  setOpt('MeterLogEmpty', 'FontColor', accent .. ',225')

  -- scrollbar + "showing X-Y of N"
  local noun = pwr and 'power event' or 'outage'
  if n > LOG_ROWS then
    local f, l = scroll + 1, scroll + LOG_ROWS
    if l > n then l = n end
    setOpt('MeterLogInfo', 'Text', 'showing ' .. f .. '-' .. l .. ' of ' .. n .. '   -   scroll for more')
    local th = math.floor(SCROLL_TRACK_H * LOG_ROWS / n)
    if th < 20 then th = 20 end
    local ty = SCROLL_TRACK_Y + math.floor((SCROLL_TRACK_H - th) * (maxoff > 0 and scroll / maxoff or 0))
    setOpt('MeterLogTrack', 'Shape', 'Rectangle 450,' .. SCROLL_TRACK_Y .. ',2,' .. SCROLL_TRACK_H ..
      ',1 | Fill Color ' .. FAINT .. ' | StrokeWidth 0')
    setOpt('MeterLogThumb', 'Shape', 'Rectangle 449,' .. ty .. ',4,' .. th ..
      ',2 | Fill Color ' .. accent .. ',160 | StrokeWidth 0')
  else
    setOpt('MeterLogInfo', 'Text', n .. ' ' .. noun .. (n == 1 and '' or 's') ..
      ' in the last ' .. RETAIN_DAYS .. ' days')
    setOpt('MeterLogTrack', 'Shape', EMPTY)
    setOpt('MeterLogThumb', 'Shape', EMPTY)
  end

  -- --- panel: shrink to fit ----------------------------------------------
  -- The rows are a fixed pool of LOG_ROWS meters; with only a couple of
  -- entries the rest render blank, so size the card to the rows actually in
  -- use instead of leaving a tall empty box hanging under the list.
  local rowsShown = n
  if rowsShown < 1 then rowsShown = 1 end
  if rowsShown > LOG_ROWS then rowsShown = LOG_ROWS end
  local infoY = ROW_Y0 + rowsShown * ROW_PITCH + 6
  setOpt('MeterLogInfo', 'Y', infoY)
  setOpt('MeterPanelBG', 'Shape', 'Rectangle 5,56,460,' .. (infoY - 34) ..
    ',12 | Fill LinearGradient PanelGrad | StrokeWidth 0')
end

-- The legend under the daily rows. Static, so it is painted once - but painted
-- HERE rather than hard-coded in the .ini, so the colours can only ever be
-- defined in one place: the palette above.
local function paintLegend()
  local cols = { FAILC, PWR_CUT, PWR_OFF, PWR_SLP }
  for i = 1, 4 do
    setOpt('MeterLegend', 'Shape' .. ((i == 1) and '' or i),
      'Rectangle ' .. LEG_X[i] .. ',' .. (LEG_Y + 3) .. ',10,5,2 | Fill Color ' ..
      cols[i] .. ',225 | StrokeWidth 0')
  end
end


-- ------------------------------------------------------------ the stages ---
-- Update() is split into four, and not for tidiness: Lua 5.1 - the one
-- Rainmeter embeds - allows a function only 60 upvalues, and a single
-- function touching every constant and every piece of state in this file
-- sails past that and will not even load. Each stage below stays well under.

-- Everything about THIS MACHINE being up or down. Runs once a second.
local function machineWatch(now)
  -- Did we miss a boot? Runs once, on the first pass, when MeasureUptime has
  -- a value. lastAlive is where the previous session stopped; if this Windows
  -- session started AFTER that, the PC genuinely was off in between, and the
  -- boot time is when it came back.
  --
  -- The test is one-directional on purpose. Rainmeter being closed while the
  -- PC kept running looks identical from the heartbeat alone, so a gap only
  -- counts when a boot explains it. And Windows "fast startup" can leave the
  -- uptime counter running across a shutdown, which makes this check MISS a
  -- real power cut - never invent one. The event-log scan then fills it in.
  if not bootDone then
    bootDone = true
    local um = SKIN:GetMeasure('MeasureUptime')
    local up = um and um:GetValue() or 0
    if lastAlive and up > 0 then
      local boot = now - math.floor(up)
      if boot > lastAlive and (boot - lastAlive) >= GAP_MIN then
        addPwr({ off = lastAlive, on = boot, cause = C_UNK, src = 0, est = 1 })
        writePwr(now)
      end
    end
  end

  -- A hole in our OWN ticks means this PC was not running: it slept, it
  -- hibernated, or the whole machine was frozen. Both ends are known exactly,
  -- so this one needs no guesswork - but ask the event log anyway, since it
  -- can name the cause and we cannot.
  if lastTick and (now - lastTick) >= GAP_MIN then
    addPwr({ off = lastTick, on = now, cause = C_SLEEP, src = 0, est = 0 })
    writePwr(now)
    scanAt = now + SCAN_SOON
    -- the probes are stale and the state clock is meaningless across a gap
    sinceTS = now
    badRun, goodRun, pingHist = 0, 0, {}
  end
  lastTick = now

  if (now - lastStamp) >= ALIVE_SEC then
    lastStamp = now
    stampAlive(now)
  end

  if now >= scanAt then
    scanAt = now + SCAN_SEC
    SKIN:Bang('!CommandMeasure', 'MeasurePowerScan', 'Run')
  end
end

-- Everything about THE LINK: read the probes, debounce, record. Runs once a
-- second and owns `online`, `warmed`, `sinceTS` and the outage list.
local function probeLink(now)
  -- PingPlugin reports 0 before its first result, TIMEOUT_VALUE on failure,
  -- and the round-trip in ms on success. Online if ANY target answers.
  local best, anyResult = nil, false
  for i = 1, PROBES do
    local m = SKIN:GetMeasure('MeasurePing' .. i)
    if m then
      local v = m:GetValue()
      if v and v > 0 then
        anyResult = true
        if v < TIMEOUT_VALUE and (best == nil or v < best) then best = v end
      end
    end
  end

  if anyResult then
    warmed = true
    lastPing = best or -1
    if best then
      goodRun, badRun = goodRun + 1, 0
    else
      badRun, goodRun = badRun + 1, 0
    end
  end

  -- --- feed the ping trace, and re-fit its scale to the recent range ----
  -- A steady link would otherwise draw a flat line against a fixed scale;
  -- fitting min/max to the last PING_KEEP samples makes real jitter visible.
  if online and lastPing >= 0 then
    pingHist[#pingHist + 1] = lastPing
    if #pingHist > PING_KEEP then table.remove(pingHist, 1) end
  end
  local sec = math.floor(frame / FPS)
  if #pingHist >= 3 and (sec - lastFit) >= RESCALE_SEC then
    lastFit = sec
    local lo, hi = math.huge, 0
    for _, v in ipairs(pingHist) do
      if v < lo then lo = v end
      if v > hi then hi = v end
    end
    local span = hi - lo
    if span < 4 then span = 4 end
    local minv = lo - span * 0.7
    if minv < 0 then minv = 0 end
    SKIN:Bang('!SetOption', 'MeasureGraph', 'MinValue', string.format('%.1f', minv))
    SKIN:Bang('!SetOption', 'MeasureGraph', 'MaxValue', string.format('%.1f', hi + span * 0.7))
  end

  -- --- debounced state transitions --------------------------------------
  if warmed then
    if online and badRun >= DOWN_STRIKES then
      online  = false
      sinceTS = now - badRun          -- credit the drop to the first failure
      table.insert(outages, 1, { down = sinceTS, up = 0, dur = 0, flag = 0 })
      writeLog(now)
      lastBeat = now
    elseif (not online) and goodRun >= UP_STRIKES then
      online  = true
      sinceTS = now
      local o = outages[1]
      if o and o.up == 0 then
        o.up, o.dur, o.flag = now, now - o.down, 0
      end
      writeLog(now)
    end
  end

  -- Heartbeat an in-progress outage so a crash / shutdown / power cut still
  -- leaves a truthful "at least this long" duration behind.
  if (not online) and outages[1] and outages[1].up == 0 and (now - lastBeat) >= HEARTBEAT_SEC then
    outages[1].dur = now - outages[1].down
    writeLog(now)
    lastBeat = now
  end
end

-- The card, the window header and the two summary lines. Also totals `longest`
-- and `pwrLongest`, which renderLog() uses to scale its bars.
local function renderStatus(now)
  local slow = online and lastPing >= 0 and lastPing > SLOW_MS
  local statusColor = online and (slow and SLOWC or OKC) or FAILC
  local label = 'CHECKING'
  if warmed then
    label = online and (slow and 'SLOW' or 'ONLINE') or 'OFFLINE'
  end

  -- Colours only change when the STATE changes, so the per-second update does
  -- not push ~20 redundant !SetOption bangs at Rainmeter.
  if label ~= lastPaint then
    lastPaint = label
    local orb = PALETTE[label][1]

    -- the ring pair and the trace take the state colour; the halos, core and
    -- dots are repainted every frame by animate().
    accentNow = statusColor
    setOpt('MeterOrbRing',  'LineColor', orb .. ',255')
    setOpt('MeterOrbRing2', 'LineColor', orb .. ',150')
    setOpt('MeterGraph',    'LineColor', orb .. ',255')

    -- the big word: near-white while healthy, state-coloured when not
    setOpt('MeterState', 'FontColor',
      (label == 'ONLINE') and (BRIGHT .. ',255') or (statusColor .. ',255'))

    -- the window echoes the same state (the DOWN FOR column follows the
    -- active tab instead, so renderLog owns that one)
    setOpt('MeterPanelDot', 'Shape',  'Ellipse 27,74,4 | Fill Color ' .. statusColor .. ',255')
    setOpt('MeterPanelDot', 'Shape2', 'Ellipse 27,74,7 | StrokeWidth 1 | Stroke Color ' .. statusColor .. ',70')
    setOpt('MeterPanelState', 'FontColor', statusColor .. ',255')
  end

  setOpt('MeterState', 'Text', label)
  setOpt('MeterPanelState', 'Text', label)
  -- The card's time slot shows when the CURRENT state began - visually the
  -- same as the reference's clock, but it actually means something.
  setOpt('MeterTime', 'Text', warmed and fmtClock(sinceTS) or '--:-- --')

  -- ---- the five-day sums, for the link and for the machine -------------
  local windowStart = now - RETAIN_DAYS * DAY
  local drops, totalDown = 0, 0
  longest = 0
  for _, o in ipairs(outages) do
    if o.down >= windowStart then
      local d = (o.up > 0) and o.dur or (now - o.down)
      drops = drops + 1
      totalDown = totalDown + d
      if d > longest then longest = d end
    end
  end

  local cuts, shuts, sleeps, pcOff = 0, 0, 0, 0
  pwrLongest = 0
  for _, p in ipairs(power) do
    -- clip to the window, so an interval that began before it only counts
    -- for the part that falls inside
    local s = (p.off > windowStart) and p.off or windowStart
    if p.on > s then pcOff = pcOff + (p.on - s) end
    if p.dur > pwrLongest then pwrLongest = p.dur end
    if p.cause == C_CUT then cuts = cuts + 1
    elseif p.cause == C_SLEEP then sleeps = sleeps + 1
    else shuts = shuts + 1 end
  end

  -- Uptime is measured against OBSERVED time: hours where this PC was off are
  -- taken out of the divisor rather than counted as connected. Otherwise a
  -- power cut - the one event most likely to take the internet with it -
  -- would quietly IMPROVE the figure, because nothing was there to see it.
  local observed = RETAIN_DAYS * DAY - pcOff
  if observed < 60 then observed = 60 end
  local avail = 100 * (1 - totalDown / observed)
  if avail < 0 then avail = 0 end
  setOpt('MeterPanelStats', 'Text', string.format(
    '%d drop%s   -   %s total downtime   -   longest %s   -   %.3f%% up',
    drops, drops == 1 and '' or 's', fmtDur(totalDown),
    drops > 0 and fmtDur(longest) or '-', avail))

  -- --- the live line, the power line, the tooltip and the pip ------------
  local sinceTxt = warmed
    and ((online and 'stable for ' or 'down for ') .. fmtDur(now - sinceTS))
    or  'probing connection...'
  local pingTxt = (online and lastPing >= 0) and string.format('%d ms', lastPing)
    or (online and '--' or 'no route')

  local last = outages[1]
  local lastTxt
  if last and last.up > 0 then
    lastTxt = 'last drop ' .. fmtWhen(last.down, now) ..
      ' (' .. (last.flag == 1 and '>=' or '') .. fmtDur(last.dur) .. ')'
  elseif last then
    lastTxt = 'down since ' .. fmtClock(last.down)
  else
    lastTxt = 'no drops in ' .. RETAIN_DAYS .. ' days'
  end

  setOpt('MeterPanelLive', 'Text', sinceTxt .. '   -   ' .. pingTxt .. '   -   ' .. lastTxt)
  setOpt('MeterPanelLive', 'FontColor', (online and ROWTEXT or (FAILC .. ',255')))

  -- The power line, built the same way: the counts, the total, then the
  -- latest event. That last clause is dropped rather than allowed to run past
  -- the edge of the panel.
  local p1 = power[1]
  local pwrTxt, pwrCol, pipTxt
  if not p1 then
    pwrTxt = 'this PC stayed on the whole time - no power cuts, shutdowns or sleep'
    pwrCol = DIM .. ',200'
    pipTxt = 'PC on continuously for ' .. RETAIN_DAYS .. ' days'
  else
    local parts = {}
    if cuts   > 0 then parts[#parts + 1] = cuts   .. (cuts   == 1 and ' power cut' or ' power cuts') end
    if shuts  > 0 then parts[#parts + 1] = shuts  .. (shuts  == 1 and ' shutdown'  or ' shutdowns')  end
    if sleeps > 0 then parts[#parts + 1] = sleeps .. (sleeps == 1 and ' sleep'     or ' sleeps')     end
    local short = { [C_SHUT] = 'shutdown', [C_CUT] = 'power cut', [C_SLEEP] = 'sleep', [C_UNK] = 'off' }
    local more = '   -   last ' .. short[p1.cause] .. ', back ' .. fmtWhen(p1.on, now)
    pwrTxt = table.concat(parts, ' + ') .. '   -   ' .. fmtDur(pcOff) .. ' off'
    if (#pwrTxt + #more) <= 82 then pwrTxt = pwrTxt .. more end
    pwrCol = (cuts > 0) and (PWR_CUT .. ',235') or (DIM .. ',235')
    pipTxt = 'PC was off (' .. CAUSE_TXT[p1.cause]:lower() .. ') - back ' .. fmtWhen(p1.on, now) ..
      ', ' .. ((p1.est == 2) and 'length unknown' or
              (((p1.est == 1) and '~' or '') .. fmtDur(p1.dur) .. ' off'))
  end
  setOpt('MeterPanelPower', 'Text', pwrTxt)
  setOpt('MeterPanelPower', 'FontColor', pwrCol)

  -- The pip exists only when there is something to say, and is only redrawn
  -- when that something changes.
  local key = p1 and (p1.on .. ':' .. p1.cause) or 'none'
  if key ~= pipKey then
    pipKey = key
    setOpt('MeterPwrPip', 'Shape', p1
      and ('Ellipse ' .. PIP_X .. ',' .. PIP_Y .. ',2 | Fill Color ' .. CAUSE_COL[p1.cause] .. ',235')
      or  EMPTY)
  end

  -- hovering the card answers the question without opening the window
  setOpt('MeterCard', 'ToolTipText', label .. '  -  ' .. sinceTxt .. '#CRLF#' ..
    pingTxt .. '#CRLF#' .. lastTxt .. '#CRLF#' .. pipTxt ..
    '#CRLF##CRLF#Click for details  -  right-click for network settings')
end

-- The five daily rows: one 24h track each, carrying both histories.
local function renderDays(now)
  local t0 = os.date("*t", now)
  t0.hour, t0.min, t0.sec = 0, 0, 0
  local todayMid = os.time(t0)

  for r = 1, DAY_ROWS do
    local dayStart = todayMid - (r - 1) * DAY
    local dayEnd   = dayStart + DAY
    local meter    = 'MeterDay' .. r
    local y        = DAY_Y0 + (r - 1) * DAY_PITCH

    setOpt('MeterDayLbl' .. r, 'Text',
      (r == 1) and 'Today' or ((r == 2) and 'Yesterday' or os.date("%a %d", dayStart)))

    setOpt(meter, 'Shape', 'Rectangle ' .. TRACK_X .. ',' .. y .. ',' .. TRACK_W ..
      ',' .. TRACK_H .. ',2 | Fill Color ' .. FAINT .. ' | StrokeWidth 0')

    -- one block on this day's track, clipped to it
    local function block(slot, cs, ce, col, alpha)
      local mx = TRACK_X + math.floor(TRACK_W * (cs - dayStart) / DAY)
      local mw = math.floor(TRACK_W * (ce - cs) / DAY)
      if mw < 2 then mw = 2 end
      if mx + mw > TRACK_X + TRACK_W then mw = TRACK_X + TRACK_W - mx end
      if mw < 1 then mw = 1 end
      setOpt(meter, 'Shape' .. slot, 'Rectangle ' .. mx .. ',' .. y .. ',' .. mw ..
        ',' .. TRACK_H .. ',2 | Fill Color ' .. col .. ',' .. alpha .. ' | StrokeWidth 0')
    end

    -- PC-off blocks go down FIRST so the internet ones sit on top of them.
    -- They rarely collide - while the PC is off nothing is watching the link -
    -- but where they do, the link is the more specific fact.
    local ps, dayOff = 0, 0
    for _, p in ipairs(power) do
      if p.on > dayStart and p.off < dayEnd then
        local cs = (p.off > dayStart) and p.off or dayStart
        local ce = (p.on  < dayEnd)   and p.on  or dayEnd
        dayOff = dayOff + (ce - cs)
        if ps < MARKS_PWR then
          ps = ps + 1
          block(PWR_SLOT + ps, cs, ce, CAUSE_COL[p.cause], 225)
        end
      end
    end
    for k = ps + 1, MARKS_PWR do setOpt(meter, 'Shape' .. (PWR_SLOT + k), EMPTY) end

    local ns, dayDown = 0, 0
    for _, o in ipairs(outages) do
      local s = o.down
      local e = (o.up > 0) and o.up or now
      -- clip to this day so a midnight-spanning drop draws on both rows
      if e > dayStart and s < dayEnd then
        local cs = (s > dayStart) and s or dayStart
        local ce = (e < dayEnd) and e or dayEnd
        dayDown = dayDown + (ce - cs)
        if ns < MARKS_NET then
          ns = ns + 1
          block(NET_SLOT + ns, cs, ce, FAILC, 235)
        end
      end
    end
    for k = ns + 1, MARKS_NET do setOpt(meter, 'Shape' .. (NET_SLOT + k), EMPTY) end

    if r == 1 then
      local nx = TRACK_X + math.floor(TRACK_W * (now - dayStart) / DAY)
      setOpt(meter, 'Shape' .. NOW_SLOT, 'Rectangle ' .. nx .. ',' .. (y - 2) .. ',1,' ..
        (TRACK_H + 4) .. ' | Fill Color ' .. accentNow .. ',120 | StrokeWidth 0')
    else
      setOpt(meter, 'Shape' .. NOW_SLOT, EMPTY)
    end

    -- The right-hand figure. One number gets the full form; two have to share
    -- a narrow column, so both drop to the short one rather than clipping.
    local vtxt, vcol
    if dayDown > 0 and dayOff > 0 then
      vtxt = fmtShort(dayDown) .. ' net  ' .. fmtShort(dayOff) .. ' off'
      vcol = FAILC .. ',235'
    elseif dayDown > 0 then
      vtxt, vcol = fmtDur(dayDown), FAILC .. ',235'
    elseif dayOff > 0 then
      vtxt, vcol = fmtDur(dayOff) .. ' off', PWR_OFF .. ',225'
    else
      vtxt, vcol = 'no drops', DIM .. ',150'
    end
    setOpt('MeterDayVal' .. r, 'Text', vtxt)
    setOpt('MeterDayVal' .. r, 'FontColor', vcol)
  end
end

-- ------------------------------------------------------------------ hooks ---

function Initialize()
  -- Neutral tones follow the shared theme (see the palette note above); the
  -- status and power accents deliberately do not.
  local function themeVar(name, fallback)
    local v = SKIN:GetVariable(name)
    if v == nil or v == '' then return fallback end
    return v
  end
  DIM     = themeVar('Dim',     DIM)
  ROWTEXT = themeVar('RowText', ROWTEXT)
  FAINT   = themeVar('Faint',   FAINT)
  BRIGHT  = themeVar('Text',    BRIGHT)

  -- Same machine-local folder the rest of the skin family writes to.
  local la = os.getenv('LOCALAPPDATA')
  local base = la and (la .. '\\AutomationReminder\\') or SKIN:GetVariable('CURRENTPATH')

  -- The filenames are scoped to THIS machine on purpose. That folder is a
  -- Syncthing root on this setup (it carries a .stfolder marker and dozens of
  -- .sync-conflict copies), and this history is inherently per-PC: two
  -- machines sharing one log would overwrite each other's history and breed
  -- conflict files. A hostname suffix gives each PC its own set, so syncing
  -- the folder stays harmless and nobody's history is lost. PowerScan.ps1
  -- derives the same name the same way - keep the two in step.
  local host = (os.getenv('COMPUTERNAME') or 'local'):gsub('[^%w%-_]', '')
  if host == '' then host = 'local' end
  logFile   = base .. '_netlog_'    .. host .. '.txt'
  pwrFile   = base .. '_pwrlog_'    .. host .. '.txt'
  aliveFile = base .. '_alive_'     .. host .. '.txt'
  evFile    = base .. '_pwrevents_' .. host .. '.txt'

  -- One-time carry-over from the older shared filename, so upgrading does not
  -- silently drop the history already recorded on this machine.
  local function exists(path)
    local f = io.open(path, 'r')
    if f then f:close() return true end
    return false
  end
  local legacy = base .. '_netlog.txt'
  if (not exists(logFile)) and exists(legacy) then
    local src = io.open(legacy, 'r')
    if src then
      local data = src:read('*a')
      src:close()
      local dst = io.open(logFile, 'w')
      if dst then dst:write(data) dst:close() end
    end
  end

  -- Lua cannot create directories, and io.open() fails silently on a missing
  -- one, so a fresh PC would record nothing at all. Probe the path; if it is
  -- not writable, have Rainmeter create the folder once.
  local probe = io.open(logFile, 'a')
  if probe then
    probe:close()
  else
    SKIN:Bang('!CommandMeasure', 'MeasureEnsureDir', 'Run')
  end

  outages = readLog()
  local now = os.time()

  -- An outage still marked open means we stopped while it was down. Close it
  -- at the last duration we actually observed and flag it unresolved (see the
  -- header) rather than inventing a recovery time.
  local top = outages[1]
  if top and top.up == 0 then
    top.up   = top.down + (top.dur > 0 and top.dur or 0)
    top.flag = 1
    writeLog(now)
  end

  -- The power side. lastAlive has to be read BEFORE the first stamp overwrites
  -- it - it is the last thing the previous session knew, and Update()'s one-off
  -- boot check compares it against this session's boot time.
  power     = readPwr()
  lastAlive = readAlive()
  -- Whatever the last scan left on disk is already history we can show, so use
  -- it now rather than waiting SCAN_SOON seconds for a fresh one.
  parseEvents(now)
  writePwr(now)
  scanAt = now + SCAN_SOON

  -- Only a CLEAN recovery time can be trusted as "stable since". An
  -- unresolved outage (flag 1) was closed at a guessed duration, so using it
  -- would claim an uptime we never actually observed - start from now instead.
  local first = outages[1]
  sinceTS = (first and first.up > 0 and first.flag == 0) and first.up or now
end

function Update()
  frame = frame + 1
  animate()

  -- a wheel notch or a tab click redraws the list immediately, without
  -- waiting for the 1Hz pass
  if scrollDirty then
    scrollDirty = false
    renderLog(os.time())
  end
  -- Everything below is the real work and stays on a 1-per-second cadence:
  -- the probe strike counters, the bookkeeping and the panel all assume they
  -- are called once a second.
  if (frame % FPS) ~= 1 then return 1 end

  local now = os.time()
  if not legendOn then legendOn = true; paintLegend() end

  machineWatch(now)
  probeLink(now)

  -- writeLog()/writePwr() prune, but they only run on a change. Without this,
  -- an entry that ages past the window while nothing happens would keep
  -- showing in the log and the daily timelines indefinitely. Both lists are
  -- sorted newest-first, so the oldest entry is the one at the end.
  local cutoff = now - RETAIN_DAYS * DAY
  local oldest = outages[#outages]
  if oldest and oldest.down < cutoff then writeLog(now) end
  local oldestP = power[#power]
  if oldestP and oldestP.on < cutoff then writePwr(now) end

  renderStatus(now)
  renderDays(now)
  renderLog(now)

  return 1
end

-- Called by the panel's mouse-wheel bangs (!CommandMeasure MScript "Scroll(1)").
-- Each tab keeps its own position, so switching lists does not lose your place.
-- renderLog() re-clamps against the live count on the next tick / redraw.
function Scroll(dir)
  scrollT[tab] = scrollT[tab] + dir * SCROLL_STEP
  if scrollT[tab] < 0 then scrollT[tab] = 0 end
  scrollDirty = true
  SKIN:Bang('!Redraw')
end

-- Called by the tab headers (!CommandMeasure MScript "Tab(1)").
function Tab(i)
  if i == tab then return end
  tab = i
  scrollDirty = true
  SKIN:Bang('!Redraw')
end
