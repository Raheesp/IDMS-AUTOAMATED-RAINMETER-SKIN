# Generates NetWatch.ini. All geometry derives from the constants in LAYOUT,
# so resizing the card is a one-number change (CARD_W / CARD_H) rather than a
# hunt through 120 meter definitions.
import io, os

# Writes NetWatch.ini next to this script, so the pair travels together
# and works from wherever the skin folder is installed.
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "NetWatch.ini")

# ------------------------------- LAYOUT -----------------------------------
PAD    = 5                     # gap around the card (and above the panel)
CARD_W, CARD_H = 220, 46       # slim bar, smaller again
CARD_R = 10

ORB_CX = PAD + 24              # orb centre
ORB_CY = PAD + CARD_H // 2
R_OUTER   = 17                 # faint outer disc
R_RING1   = 13                 # outer rotating ring (mid-radius)
R_RING2   = 9                  # inner counter-rotating ring (mid-radius)
R_CORE    = 6.5                # solid core
RING_PAD  = 2                  # bbox slack so the stroke is never clipped

# Bar layout runs left to right: orb | state+label | ping trace | time | chevron
TX      = 52                   # left edge of the type block
Y_STATE = 14                   # "ONLINE"
Y_LBL   = 30                   # "STATUS"
GX      = 112                  # ping trace
Y_GRAPH, H_GRAPH, W_GRAPH = 18, 18, 52
TMX     = 170                  # the time
Y_TIME  = 22
FS_STATE, FS_LBL, FS_TIME = 10, 5.5, 6

PIP_X, PIP_Y = 203, 28         # power pip: lit when the PC itself went down

CHEV_X, CHEV_Y, CHEV_W, CHEV_H = 210, 25, 9, 5

# --------------------------- PANEL LAYOUT ---------------------------------
PT      = PAD + CARD_H + PAD   # panel top
PW      = 460                  # panel width
PL      = PAD                  # panel left
M       = 18                   # panel inner margin
CL      = PL + M               # content left
CR      = PL + PW - M          # content right (for right-aligned text)
HAIR_W  = CR - CL

# 24h timeline track. It stops well short of CR so the per-day figure on the
# right has room for BOTH numbers ("12m net - 2h off") without clipping.
TRACK_X, TRACK_W = 76, 286
COL_BACK, COL_DUR, COL_BAR, W_BAR = 150, 225, 300, 74
DAY_Y0, DAY_PITCH = PT + 116, 22
LEG_Y   = PT + 216             # legend strip under the daily rows
LEG_X   = (CL, 115, 200, 285)  # swatch x: net down / power cut / shut down / asleep
TAB_Y   = 240                  # OUTAGE LOG | POWER LOG tabs (offset from PT)
TAB_UY  = PT + 252             # accent underline beneath the active tab
TAB1_X, TAB1_W = CL, 64
TAB2_X, TAB2_W = CL + 80, 58
ROW_Y0, ROW_PITCH = PT + 276, 18
SCROLL_X = PL + PW - 15


def y(off):
    return PT + off


head = rf'''; =============================================================================
;  INTERNET  -  small animated ONLINE / OFFLINE card, 5-day outage history
;               AND a matching 5-day power-cut / PC-off history.
;  Part of the AutomationReminder family (big bar / PORTAL DATA / this).
;
;  THE CARD   {CARD_W}x{CARD_H}, borderless. A breathing orb with two counter-rotating
;             scanner rings, the state in large type, a STATUS label, a LIVE
;             PING TRACE that moves like a heart monitor, and the time the
;             current state began. Click it to open the details window.
;             Hover for a summary; right-click for network settings.
;             One extra dot sits left of the chevron - the POWER PIP. It is
;             invisible unless the machine itself went down inside the window,
;             and takes the colour of the most recent reason.
;
;  COLOUR     EVERY accent follows the state - orb, both rings, the trace, the
;             type, and in the window the header, the "DOWN FOR" column, the
;             today marker and the scrollbar. Green ONLINE, red OFFLINE,
;             amber SLOW. Nothing stays green while the link is down.
;             The power colours are deliberately NOT green/amber/red: orange
;             POWER CUT, indigo SHUT DOWN, slate ASLEEP, so at a glance you can
;             tell "the internet failed" from "this PC was not even on".
;
;  ANIMATION  the skin ticks at 20fps (Update=50) purely so the orb and the
;             trace move smoothly. NetWatchEngine.lua does its real work - the
;             probing, the bookkeeping, the panel - only on every 20th tick,
;             i.e. still once per second. See FPS in the Lua.
;
;  HOW IT WATCHES THE LINK
;    Three PingPlugin measures (Google / Cloudflare / Quad9 DNS). The
;    connection counts as UP while ANY of the three answers, so one blocked or
;    flaky target never fakes an outage. Ping 1 runs every second (it also
;    feeds the trace); the other two every three seconds.
;
;  HOW IT WATCHES THE POWER
;    Two independent sources, so it works on every machine:
;      1. PowerScan.ps1 reads the Windows System event log - boot, shutdown,
;         sleep, resume, and "the last shutdown was unexpected". That last one
;         is what separates a POWER CUT from a clean SHUT DOWN, and it also
;         back-fills history from before this skin was ever installed. Runs
;         hidden as a normal user (no admin), ~0.5s, every 30 minutes.
;      2. the engine's own heartbeat, which needs nothing installed: it stamps
;         %LOCALAPPDATA%\AutomationReminder\_alive_<PC>.txt every 30 seconds,
;         so a gap in that stamp which a fresh boot explains is recorded as a
;         PC OFF period even if PowerShell is blocked by policy.
;    The event log wins wherever the two disagree - it is exact and it knows
;    the cause; the heartbeat is the safety net.
;
;  WHAT IT RECORDS   (%LOCALAPPDATA%\AutomationReminder\, machine-local, same
;                     folder as _taskdata.txt - never the synced skin folder)
;      _netlog_<PC>.txt   one line per internet outage
;      _pwrlog_<PC>.txt   one line per power cut / shutdown / sleep
;      _alive_<PC>.txt    the 30-second heartbeat stamp
;      _pwrevents_<PC>.txt  raw event-log dump, rewritten by each scan
;    All of it survives skin refreshes, Rainmeter restarts and reboots.
;
;  GEOMETRY   this file is GENERATED by _layout.py, sitting next to it in this
;             folder. The whole layout derives from CARD_W / CARD_H there, so
;             resize by editing those and re-running "python _layout.py" -
;             not by hand-editing 120 meters. Keep the mirrored constants at
;             the top of NetWatchEngine.lua in step (the script prints them).
;
;  PORTABILITY  nothing here is tied to one machine or user:
;             - no absolute paths. The theme is reached via #CURRENTPATH#..\,
;               the history via %LOCALAPPDATA%, the scanner via #CURRENTPATH#.
;               Keep this folder at Skins\AutomationReminder\NetWatch\ and it
;               just works.
;             - needs Rainmeter 4.1+ (Shape meters, StrokeStartCap/EndCap) and
;               PingPlugin.dll + RunCommand.dll, both of which ship with every
;               standard Rainmeter install.
;             - the right-click "ms-settings:network" shortcut is Windows 10/11
;               only; on older Windows that one action simply does nothing.
;             - history is per-machine BY DESIGN - each PC records its own
;               outages, in files named after it. Never sync them.
; =============================================================================

[Rainmeter]
Update=50
AccurateText=1
DynamicWindowSize=1
MiddleMouseUpAction=[!Refresh]
OnRefreshAction=[!HideMeterGroup Panel]

[Metadata]
Name=Internet Status
Author=Rahees
Information=Animated online/offline card with a live ping trace, a rolling 5-day outage history and a matching power-cut / PC-off log.
Version=7.0
License=Personal use

[Variables]
; default theme, overridden by Settings.inc below (insurance so the bar is
; never left un-themed if Settings.inc can't be read for a moment).
Theme=Sunset
; Share the SAME theme + settings as the parent AutomationReminder skin, so
; this bar's dark background matches the big bar and PORTAL DATA, and follows
; the theme picker in the main bar's dropdown. #CURRENTPATH# is this skin's
; folder; one ".." up lands in the parent, where @Resources actually lives.
; Only the BACKGROUND and the neutral text tones are themed - the status
; accents (green / amber / red, and the power colours) stay fixed in the Lua,
; because they carry meaning rather than style.
@IncludeSettings=#CURRENTPATH#..\@Resources\Settings.inc
@IncludeTheme=#CURRENTPATH#..\@Resources\Themes\#Theme#.inc
Font=Segoe UI

; ============================= PROBES ========================================
; UpdateRate is in measure updates. The skin ticks 20x/sec, so UpdateRate=20
; is one ping per second. TimeoutValue MUST match TIMEOUT_VALUE in the Lua.
[MeasurePing1]
Measure=Plugin
Plugin=PingPlugin
DestAddress=8.8.8.8
UpdateRate=20
Timeout=2000
TimeoutValue=9999

[MeasurePing2]
Measure=Plugin
Plugin=PingPlugin
DestAddress=1.1.1.1
UpdateRate=60
Timeout=2000
TimeoutValue=9999

[MeasurePing3]
Measure=Plugin
Plugin=PingPlugin
DestAddress=9.9.9.9
UpdateRate=60
Timeout=2000
TimeoutValue=9999

; Feeds the ping trace. MinValue/MaxValue are re-fitted to the recent ping
; range by the Lua every few seconds, so a steady connection still shows its
; real jitter instead of flatlining against a fixed scale.
[MeasureGraph]
Measure=Calc
Formula=MeasurePing1
MinValue=0
MaxValue=80
DynamicVariables=1

; Pins the orb's arc rings to a full sweep.
[MeasureFull]
Measure=Calc
Formula=1
MinValue=0
MaxValue=1

; Seconds since this Windows session started. The engine reads it once, to
; corroborate a gap in its own heartbeat: if the machine booted AFTER our last
; stamp, the PC really was off and we know exactly when it came back.
; Evidence only, never used alone - Windows "fast startup" leaves this counter
; running across a shutdown, so a LARGE value proves nothing. A small one is
; still proof of a recent boot, and that is all we ask of it.
[MeasureUptime]
Measure=Uptime

; Ensures %LOCALAPPDATA%\AutomationReminder\ exists. Lua cannot create
; directories and io.open() fails SILENTLY on a missing folder, so on a PC
; that has never run Setup.bat or the main AUTOMATION bar, every write would
; quietly do nothing and no outage would ever be recorded. The Lua fires this
; once, and only when the folder is genuinely missing. State=Hide keeps the
; console window from flashing. %VARS% pass through Rainmeter untouched (it
; uses #Var# syntax), so cmd expands them itself.
[MeasureEnsureDir]
Measure=Plugin
Plugin=RunCommand
Program=cmd
Parameter=/c if not exist "%LOCALAPPDATA%\AutomationReminder" mkdir "%LOCALAPPDATA%\AutomationReminder"
State=Hide

; Dumps the Windows System event log's power records where the engine can read
; them - Lua has no way to query the event log itself. Hidden, no admin, about
; half a second, fired by the Lua at start and then every 30 minutes.
; FinishAction tells the engine the dump is complete. If PowerShell is blocked
; by policy this measure simply never produces a file, and the engine falls
; back to its own heartbeat - see HOW IT WATCHES THE POWER above.
[MeasurePowerScan]
Measure=Plugin
Plugin=RunCommand
Program=powershell
Parameter=-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "#CURRENTPATH#PowerScan.ps1"
State=Hide
FinishAction=[!CommandMeasure MScript "PowerScanDone()"]

[MScript]
Measure=Script
ScriptFile=#CURRENTPATH#NetWatchEngine.lua

; ============================= THE CARD ======================================
; Borderless by request: no stroke, no outer glow rings - just the dark card.
[MeterCard]
Meter=Shape
Shape=Rectangle {PAD},{PAD},{CARD_W},{CARD_H},{CARD_R} | Fill LinearGradient CardGrad | StrokeWidth 0
CardGrad=90 | #CardTop# ; 0.0 | #CardBot# ; 1.0
LeftMouseUpAction=[!ToggleMeterGroup Panel][!UpdateMeterGroup Panel][!Redraw]
RightMouseUpAction=["ms-settings:network"]
ToolTipText=Checking connection...

[MeterSheen]
Meter=Shape
Shape=Rectangle {PAD+2},{PAD+2},{CARD_W-4},{CARD_H//3},{CARD_R-2} | Fill LinearGradient SheenGrad | StrokeWidth 0
SheenGrad=90 | #GlossA# ; 0.0 | #GlossB# ; 1.0

; --- the orb ----------------------------------------------------------------
; Halo radii/alpha, ring angles, dot positions and every colour are animated
; by NetWatchEngine.lua - the values here are just the first frame.
[MeterOrbOuter]
Meter=Shape
Shape=Ellipse {ORB_CX},{ORB_CY},{R_OUTER} | Fill Color 255,255,255,7 | StrokeWidth 1 | Stroke Color 255,255,255,20

[MeterOrbGlowB]
Meter=Shape
Shape=Ellipse {ORB_CX},{ORB_CY},{R_CORE*1.35:.1f} | Fill Color 34,222,124,14

[MeterOrbGlowA]
Meter=Shape
Shape=Ellipse {ORB_CX},{ORB_CY},{R_CORE*1.1:.1f} | Fill Color 34,222,124,30

[MeterOrbRing]
Meter=Roundline
MeasureName=MeasureFull
DynamicVariables=1
X={ORB_CX-R_RING1-RING_PAD}
Y={ORB_CY-R_RING1-RING_PAD}
W={(R_RING1+RING_PAD)*2}
H={(R_RING1+RING_PAD)*2}
StartAngle=4.4506
RotationAngle=5.1487
LineStart={R_RING1-0.8:.1f}
LineLength={R_RING1+0.8:.1f}
Solid=1
LineColor=34,222,124,255
AntiAlias=1

; inner ring, shorter arc, spins the OTHER way - the counter-rotation is what
; sells the "instrument" look at this size.
[MeterOrbRing2]
Meter=Roundline
MeasureName=MeasureFull
DynamicVariables=1
X={ORB_CX-R_RING2-RING_PAD}
Y={ORB_CY-R_RING2-RING_PAD}
W={(R_RING2+RING_PAD)*2}
H={(R_RING2+RING_PAD)*2}
StartAngle=1.2
RotationAngle=2.4435
LineStart={R_RING2-0.7:.1f}
LineLength={R_RING2+0.7:.1f}
Solid=1
LineColor=34,222,124,150
AntiAlias=1

[MeterOrbDot]
Meter=Shape
Shape=Ellipse {ORB_CX},{ORB_CY-R_RING1},2 | Fill Color 200,255,225,255

[MeterOrbDot2]
Meter=Shape
Shape=Ellipse {ORB_CX},{ORB_CY-R_RING2},1.5 | Fill Color 200,255,225,190

[MeterOrbCore]
Meter=Shape
Shape=Ellipse {ORB_CX},{ORB_CY},{R_CORE} | Fill Color 45,232,130,255

; --- the type block ---------------------------------------------------------
[MeterState]
Meter=String
Text=CHECKING
X={TX}
Y={Y_STATE}
FontFace=#Font#
FontSize={FS_STATE}
FontWeight=700
FontColor=#Text#,255
AntiAlias=1

[MeterStatusLbl]
Meter=String
Text=STATUS
X={TX+1}
Y={Y_LBL}
FontFace=#Font#
FontSize={FS_LBL}
FontWeight=600
FontColor=#Dim#,255
AntiAlias=1

; --- the live ping trace ----------------------------------------------------
; UpdateDivider=20 so it appends exactly one sample per second: {W_GRAPH} px wide
; = a rolling ~{W_GRAPH} seconds of latency history.
[MeterGraph]
Meter=Line
MeasureName=MeasureGraph
UpdateDivider=20
X={GX}
Y={Y_GRAPH}
W={W_GRAPH}
H={H_GRAPH}
LineCount=1
LineWidth=1.2
LineColor=34,222,124,255
AutoScale=0
HorizontalLines=0
Solid=0
GraphStart=Right
AntiAlias=1

[MeterTime]
Meter=String
Text=
X={TMX}
Y={Y_TIME}
FontFace=#Font#
FontSize={FS_TIME}
FontWeight=500
FontColor=#RowText#
AntiAlias=1

; The POWER PIP. Drawn by the Lua ONLY when the machine itself went down inside
; the window, in the colour of the most recent reason. Nothing to report means
; nothing drawn, and the card looks exactly as it always did.
[MeterPwrPip]
Meter=Shape
Shape=Rectangle 0,0,0,0 | StrokeWidth 0

[MeterChevron]
Meter=Shape
Shape=Line {CHEV_X},{CHEV_Y},{CHEV_X+CHEV_W//2},{CHEV_Y+CHEV_H} | StrokeWidth 1.2 | Stroke Color 190,205,215,210 | StrokeStartCap Round | StrokeEndCap Round
Shape2=Line {CHEV_X+CHEV_W//2},{CHEV_Y+CHEV_H},{CHEV_X+CHEV_W},{CHEV_Y} | StrokeWidth 1.2 | Stroke Color 190,205,215,210 | StrokeStartCap Round | StrokeEndCap Round

; ============================= DETAILS WINDOW ================================
[MeterPanelBG]
Meter=Shape
Group=Panel
Shape=Rectangle {PL},{PT},{PW},302,12 | Fill LinearGradient PanelGrad | StrokeWidth 0
PanelGrad=90 | #PanelTop# ; 0.0 | #PanelBot# ; 1.0
MouseScrollUpAction=[!CommandMeasure MScript "Scroll(-1)"]
MouseScrollDownAction=[!CommandMeasure MScript "Scroll(1)"]

[MeterPanelDot]
Meter=Shape
Group=Panel
Shape=Ellipse {CL+4},{y(18)},4 | Fill Color 34,222,124,255
Shape2=Ellipse {CL+4},{y(18)},7 | StrokeWidth 1 | Stroke Color 34,222,124,70

[MeterPanelState]
Meter=String
Group=Panel
Text=
X={CL+18}
Y={y(7)}
FontFace=#Font#
FontSize=12
FontWeight=700
FontColor=#Text#,255
AntiAlias=1

[MeterPanelTitleSub]
Meter=String
Group=Panel
Text=rolling 5 days
X={CR}
Y={y(12)}
StringAlign=Right
FontFace=#Font#
FontSize=8
FontWeight=500
FontColor=#Dim#,150
AntiAlias=1

[MeterPanelLive]
Meter=String
Group=Panel
Text=
X={CL}
Y={y(32)}
FontFace=#Font#
FontSize=9
FontWeight=500
FontColor=#RowText#
AntiAlias=1

[MeterPanelStats]
Meter=String
Group=Panel
Text=
X={CL}
Y={y(50)}
FontFace=#Font#
FontSize=9
FontWeight=500
FontColor=#Dim#,235
AntiAlias=1
ToolTipText=The link, over the full 5-day window.#CRLF##CRLF#Uptime is measured against OBSERVED time: any stretch where this PC was#CRLF#off or asleep is taken OUT of the sum rather than counted as connected,#CRLF#so a power cut can no longer flatter the percentage.

; The same five days, but for the MACHINE rather than the link.
[MeterPanelPower]
Meter=String
Group=Panel
Text=
X={CL}
Y={y(68)}
FontFace=#Font#
FontSize=9
FontWeight=500
FontColor=#Dim#,235
AntiAlias=1
ToolTipText=POWER CUT - the machine stopped without a shutdown: mains loss, a hard#CRLF#reset or a crash. Windows never got to log the moment it died, so the start#CRLF#is estimated from the last sign of life and the length is shown with a "~".#CRLF##CRLF#SHUT DOWN - a normal shutdown or restart.#CRLF#ASLEEP - sleep, hibernate, or any stretch where the widget was frozen.

[MeterHeadDaily]
Meter=String
Group=Panel
Text=DAILY
X={CL}
Y={y(94)}
FontFace=#Font#
FontSize=8
FontWeight=700
FontColor=#Dim#,200
AntiAlias=1

'''

scale = ""
for i, lbl in enumerate(("00:00", "06:00", "12:00", "18:00", "24:00")):
    scale += """[MeterScale%s]
Meter=String
Group=Panel
Text=%s
X=%d
Y=%d
FontFace=#Font#
FontSize=7
FontWeight=500
FontColor=#Dim#,140
AntiAlias=1
""" % (lbl[:2], lbl, TRACK_X + i * TRACK_W // 4, y(95))

mid = rf'''
[MeterHeadLineTop]
Meter=Shape
Group=Panel
Shape=Rectangle {CL},{y(108)},{HAIR_W},1 | Fill Color #Faint# | StrokeWidth 0

; --- 5 daily rows : label | 24h track | day totals ---------------------------
; MeterDay{{n}} is one meter carrying a whole row, all of it placed by the Lua:
;   Shape        the empty 24h track
;   Shape2..7    PC-OFF blocks   (power cut / shut down / asleep)
;   Shape8..15   INTERNET outage blocks, drawn on top of them
;   Shape16      the "now" tick, today's row only
; The two kinds rarely overlap - while the PC is off nothing is watching the
; link - so one track can honestly carry both, and the legend below says which
; colour is which.
'''
for r in range(1, 6):
    ry = DAY_Y0 + (r - 1) * DAY_PITCH
    mid += """[MeterDayLbl%d]
Meter=String
Group=Panel
Text=
X=%d
Y=%d
FontFace=#Font#
FontSize=9
FontWeight=600
FontColor=#RowText#
AntiAlias=1
[MeterDay%d]
Meter=Shape
Group=Panel
Shape=Rectangle 0,0,0,0 | StrokeWidth 0
[MeterDayVal%d]
Meter=String
Group=Panel
Text=
X=%d
Y=%d
StringAlign=Right
FontFace=#Font#
FontSize=8
FontWeight=600
FontColor=#Dim#,150
AntiAlias=1

""" % (r, CL, ry - 2, r, r, CR, ry - 1)

mid += """; --- legend for those tracks (swatches painted by the Lua, so the colours
; --- can only ever be defined in one place) ---------------------------------
[MeterLegend]
Meter=Shape
Group=Panel
Shape=Rectangle 0,0,0,0 | StrokeWidth 0

"""
for i, txt in enumerate(("internet down", "power cut", "shut down", "asleep")):
    mid += """[MeterLegendTxt%d]
Meter=String
Group=Panel
Text=%s
X=%d
Y=%d
FontFace=#Font#
FontSize=7
FontWeight=500
FontColor=#Dim#,170
AntiAlias=1
""" % (i + 1, txt, LEG_X[i] + 14, LEG_Y - 1)

mid += rf'''
[MeterHeadLineMid]
Meter=Shape
Group=Panel
Shape=Rectangle {CL},{y(232)},{HAIR_W},1 | Fill Color #Faint# | StrokeWidth 0

; --- the two log tabs -------------------------------------------------------
; ONE pool of rows serves both lists, so the window is the same size whichever
; you are reading and the two logs are literally the same table. The Lua paints
; the active tab and slides the underline under it.
[MeterTabNet]
Meter=String
Group=Panel
Text=OUTAGE LOG
X={TAB1_X}
Y={y(TAB_Y)}
FontFace=#Font#
FontSize=8
FontWeight=700
FontColor=#Dim#,200
AntiAlias=1
LeftMouseUpAction=[!CommandMeasure MScript "Tab(0)"]
ToolTipText=Every time the INTERNET dropped while this widget was running.

[MeterTabPwr]
Meter=String
Group=Panel
Text=POWER LOG
X={TAB2_X}
Y={y(TAB_Y)}
FontFace=#Font#
FontSize=8
FontWeight=700
FontColor=#Dim#,200
AntiAlias=1
LeftMouseUpAction=[!CommandMeasure MScript "Tab(1)"]
ToolTipText=Every time THIS PC went down - power cut, shutdown, restart or sleep.#CRLF#Read from the Windows event log, so it covers time before the skin ran too.

[MeterTabLine]
Meter=Shape
Group=Panel
Shape=Rectangle 0,0,0,0 | StrokeWidth 0

; --- column headers : the wording follows the active tab, set by the Lua ----
[MeterHeadWhen]
Meter=String
Group=Panel
Text=WENT DOWN
X={CL}
Y={y(258)}
FontFace=#Font#
FontSize=7
FontWeight=700
FontColor=#Dim#,180
AntiAlias=1
[MeterHeadBack]
Meter=String
Group=Panel
Text=BACK AT
X={COL_BACK}
Y={y(258)}
FontFace=#Font#
FontSize=7
FontWeight=700
FontColor=#Dim#,180
AntiAlias=1
[MeterHeadDur]
Meter=String
Group=Panel
Text=DOWN FOR
X={COL_DUR}
Y={y(258)}
FontFace=#Font#
FontSize=7
FontWeight=700
FontColor=34,222,124,200
AntiAlias=1
[MeterHeadBar]
Meter=String
Group=Panel
Text=RELATIVE LENGTH
X={COL_BAR}
Y={y(258)}
FontFace=#Font#
FontSize=7
FontWeight=700
FontColor=#Dim#,180
AntiAlias=1
[MeterHeadTag]
Meter=String
Group=Panel
Text=
X={CR}
Y={y(258)}
StringAlign=Right
FontFace=#Font#
FontSize=7
FontWeight=700
FontColor=#Dim#,180
AntiAlias=1

[MeterHeadLineLog]
Meter=Shape
Group=Panel
Shape=Rectangle {CL},{y(270)},{HAIR_W},1 | Fill Color #Faint# | StrokeWidth 0

; --- the shared row pool (10 rows, filled by the Lua from the active tab) ---
'''
for j in range(1, 11):
    ry = ROW_Y0 + (j - 1) * ROW_PITCH
    mid += """[MeterLogWhen%d]
Meter=String
Group=Panel
Text=
X=%d
Y=%d
W=130
H=15
ClipString=1
FontFace=#Font#
FontSize=9
FontColor=#RowText#
AntiAlias=1
[MeterLogBack%d]
Meter=String
Group=Panel
Text=
X=%d
Y=%d
FontFace=#Font#
FontSize=9
FontColor=#Dim#,235
AntiAlias=1
[MeterLogDur%d]
Meter=String
Group=Panel
Text=
X=%d
Y=%d
FontFace=#Font#
FontSize=9
FontWeight=600
FontColor=#Dim#,235
AntiAlias=1
[MeterLogBar%d]
Meter=Shape
Group=Panel
Shape=Rectangle 0,0,0,0 | StrokeWidth 0
[MeterLogTag%d]
Meter=String
Group=Panel
Text=
X=%d
Y=%d
StringAlign=Right
FontFace=#Font#
FontSize=8
FontWeight=600
FontColor=#Dim#,200
AntiAlias=1

""" % (j, CL, ry, j, COL_BACK, ry, j, COL_DUR, ry, j, j, CR, ry + 1)

tail = rf'''; Empty-state line - full width, unclipped (the WENT DOWN column is narrow and
; would truncate the message). Shown by the Lua only when a list is empty.
[MeterLogEmpty]
Meter=String
Group=Panel
Text=
X={CL}
Y={ROW_Y0}
FontFace=#Font#
FontSize=9
FontWeight=500
FontColor=#Dim#,225
AntiAlias=1

; --- scrollbar (track + thumb) and page indicator : sized by the Lua --------
[MeterLogTrack]
Meter=Shape
Group=Panel
Shape=Rectangle 0,0,0,0 | StrokeWidth 0

[MeterLogThumb]
Meter=Shape
Group=Panel
Shape=Rectangle 0,0,0,0 | StrokeWidth 0

[MeterLogInfo]
Meter=String
Group=Panel
Text=
X={CL}
Y={y(300)}
FontFace=#Font#
FontSize=8
FontWeight=600
FontColor=#Dim#,200
AntiAlias=1
'''

io.open(OUT, "w", encoding="utf-8-sig", newline="\r\n").write(head + scale + mid + tail)
print("wrote", OUT)
print()
print("--- constants to mirror in NetWatchEngine.lua ---")
print("ORB_X, ORB_Y       =", ORB_CX, ",", ORB_CY)
print("R_OUT, R_IN        =", R_RING1, ",", R_RING2)
print("core base radius   =", R_CORE)
print("PIP_X, PIP_Y       =", PIP_X, ",", PIP_Y)
print("TRACK_X, TRACK_W   =", TRACK_X, ",", TRACK_W)
print("DAY_Y0, DAY_PITCH  =", DAY_Y0, ",", DAY_PITCH)
print("LEG_Y, LEG_X       =", LEG_Y, ",", LEG_X)
print("TAB_UY             =", TAB_UY)
print("TAB1_X/W, TAB2_X/W =", TAB1_X, "/", TAB1_W, ",", TAB2_X, "/", TAB2_W)
print("BAR_X, BAR_W       =", COL_BAR, ",", W_BAR)
print("ROW_Y0, ROW_PITCH  =", ROW_Y0, ",", ROW_PITCH)
print("panel   =", f"Rectangle {PL},{PT},{PW},<h>,12   height = infoY - {PT - 22}")
print("scrollbar x        =", SCROLL_X, "(track)", SCROLL_X - 1, "(thumb)")
print("panel dot          =", f"Ellipse {CL+4},{y(18)},4")
