# ============================================================================
#  MakeUpdate.ps1  -  builds ONE file that updates AutomationReminder anywhere
# ----------------------------------------------------------------------------
#  Double-click MakeUpdate.bat on the PC that has the version you want to
#  share. It writes  Downloads\AutomationReminder-Update-<date>.cmd  - copy that
#  single file to any other PC and double-click it there (see
#  @Resources\Update\UpdateLauncher.ps1 for what it does on the other side).
#
#  Steps: refresh @Resources\manifest.txt (so CheckInstall on the other PC can
#  verify every file), stage a copy of this folder WITHOUT per-PC / dev files,
#  zip it, and wrap  batch header + updater + info + base64 zip  into the .cmd.
# ============================================================================
$ErrorActionPreference = 'Stop'
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
Add-Type -AssemblyName System.IO.Compression.FileSystem

Write-Host "Refreshing the file manifest..." -ForegroundColor Cyan
& (Join-Path $here 'CheckInstall.ps1') -MakeManifest

$stageRoot = Join-Path $env:TEMP ("ar_make_" + [guid]::NewGuid().ToString('N').Substring(0, 8))
$stage = Join-Path $stageRoot 'AutomationReminder'
Write-Host "Staging files..." -ForegroundColor Cyan
# per-PC settings, reports, Syncthing markers, caches and old dev test scripts stay behind
robocopy $here $stage /E `
    /XF Settings.inc CheckInstall_report.txt .stfolder .stignore _taskdata.txt _taskhist.txt '*.pyc' 'test_*.py' rescan_two.py '*.sync-conflict-*' 'AutomationReminder-Update-*.cmd' `
    /XD __pycache__ .stversions /NFL /NDL /NJH /NJS /NP | Out-Null
if ($LASTEXITCODE -ge 8) { throw "staging copy failed (robocopy $LASTEXITCODE)" }
$files = @(Get-ChildItem $stage -Recurse -File).Count

$zip = Join-Path $stageRoot 'payload.zip'
[IO.Compression.ZipFile]::CreateFromDirectory($stage, $zip, [IO.Compression.CompressionLevel]::Optimal, $true)
$b64 = [Convert]::ToBase64String([IO.File]::ReadAllBytes($zip))
$b64Lines = for ($i = 0; $i -lt $b64.Length; $i += 76) { $b64.Substring($i, [Math]::Min(76, $b64.Length - $i)) }

$launcher = [IO.File]::ReadAllText((Join-Path $here '@Resources\Update\UpdateLauncher.ps1'))
$header = @(
    '@echo off',
    'setlocal',
    'title AutomationReminder update',
    'rem  Double-click to install or update AutomationReminder on this PC.',
    'rem  Keeps this PC''s own settings, backs up the old version first.',
    'set "AR_UPDATE_SELF=%~f0"',
    'powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "$t=[IO.File]::ReadAllText($env:AR_UPDATE_SELF); $m=[regex]::Match($t,''(?ms)^:::UPD:PS:::\r?\n(.*?)(?=^:::UPD:)''); & ([scriptblock]::Create($m.Groups[1].Value))"',
    'set "AR_RC=%ERRORLEVEL%"',
    'echo.',
    'if "%AR_RC%"=="0" (',
    '  echo Done - this window closes in 10 seconds. Press any key to close it now.',
    '  timeout /t 10 >nul',
    '  exit /b 0',
    ')',
    'echo Something needs attention - read the messages above.',
    'pause',
    'exit /b %AR_RC%'
)
$stamp = Get-Date -Format 'yyyy-MM-dd HH:mm'
$all = @() + $header + ':::UPD:PS:::' + ($launcher -replace "`r`n", "`n" -split "`n") +
       ':::UPD:INFO:::' + "built=$stamp" + "from=$env:COMPUTERNAME" + "files=$files" +
       ':::UPD:ZIP:::' + $b64Lines
$dl = $null
try { $dl = (New-Object -ComObject Shell.Application).NameSpace('shell:Downloads').Self.Path } catch {}
if (-not $dl -or -not (Test-Path $dl)) { $dl = Join-Path $env:USERPROFILE 'Downloads' }
$out = Join-Path $dl ("AutomationReminder-Update-" + (Get-Date -Format 'yyyy-MM-dd_HHmm') + ".cmd")
[IO.File]::WriteAllText($out, (($all -join "`r`n") + "`r`n"), [Text.Encoding]::ASCII)
Remove-Item $stageRoot -Recurse -Force -ErrorAction SilentlyContinue

$mb = [Math]::Round((Get-Item $out).Length / 1MB, 2)
Write-Host "`nUpdate file ready: $out  ($files files, $mb MB)" -ForegroundColor Green
Write-Host "Copy it to the other PC and double-click it. (Zip it first if you email it - Outlook blocks .cmd.)" -ForegroundColor Gray
Start-Process explorer.exe "/select,`"$out`""
